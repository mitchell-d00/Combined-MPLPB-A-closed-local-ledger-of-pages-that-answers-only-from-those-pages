# Intended scope, completeness and production readiness

Last reviewed: 2026-11-17.

Package role: [how this part fits Combined MPLPB](PACKAGE_GUIDE.md#evidence-and-limits). Local implemented behavior, shared-service readiness and independent semantic accuracy need separate evidence.

MPLPB is a local research system with bounded source-language rules. Its local
MCP adapter now gives compatible AI clients a standard route to the existing
reader and conversation engine. That closes an integration gap; it does not
establish unrestricted language understanding or shared-service readiness.

| Intended capability | Implemented boundary | Evidence / remaining gap |
|---|---|---|
| Humans inspect and ask about local pages | Native/browser UI, supported query contract, source inspection and revisions | Existing native, JavaScript, WebAssembly and Chromium suites. Historical source-language failures remain. |
| AI discovers and asks through standard tools | Local stdio MCP; explicitly authorized collections and host-fixed profile | MCP unit/real-subprocess tests and official Python SDK client; third-party AI application usability is not measured. |
| AI inspects evidence and uncertainty | Full original reader decisions, citations, gate, partial/ambiguity/refusal labels | Shared App parity and altered/withdrawn/contradictory-source tests; tool success is not answer support. |
| User corrects an interpretation or continues a procedure | Native conversation rules; bounded step clarification, corrections and persisted selectors | Actual SDK process restart and focused tests; arbitrary references and arbitrary prose procedures remain unsupported. |
| User adds a new topic | Existing source authoring/import paths; explicit MCP registration of leaf ledgers/native saved collections | Unfamiliar synthetic entities and native collection capture-integrity test; no independent collection-builder trial. |
| AI writes or acquires sources | Deliberately absent from this MCP connection | Use existing explicit human source-management routes. User context is not automatically authenticated or ratified. |
| Reliable local operation | Bounded request/output/source/storage sizes, error recovery, policy-scoped sessions, staged chat saves and an exclusive namespace process lock | No hard CPU timeout, OS sandbox or complete disaster-recovery product. One trusted operator/process is the declared scope. |
| An internet-facing multi-user service | Outside the declared supported deployment | Authentication, tenant isolation, quotas, egress controls, secrets, monitored operations and incident/recovery drills require deployment-specific engineering and evidence. |
| Independently validated answer quality | Not established | Pottery is inspected development data; 73/73 is authored lab-only source coverage. Live assisted-reader calibration and independent human semantic/usability review remain outstanding. |

For local MCP use, connection setup, discoverability, faithful result transport,
source inspection and bounded conversational recovery are implemented and tested.
A user must still configure a capable client and authorize the intended data.
Client-side obedience to relay instructions is a separate trust boundary: MCP
cannot prevent a model from inventing text or invoking another service.

Before widening scope, define the deployment and release criteria first. Shared
hosting needs the controls in the [threat model](PRODUCTION_THREAT_MODEL.md), not
just a passing local test suite. Consequential automated decisions require their
own source review and evaluation; a seal or test count does not authenticate truth.

See [setup and enforced MCP rules](MCP_AGENT.md), [current status](CURRENT_STATUS.md)
and [result/test index](RESULTS_AND_TESTS.md). Source tests, an extracted-ZIP test,
a candidate browser check and a postdeployment check are distinct evidence.

## Free public helper update

The [public browser helper](FREE_PUBLIC_HELPER.md) adds reviewed collection/source
building and a visible execution trace using the existing page API. The optional
pretrained model runs on compatible visitor devices; no shared AI server is
configured. Nine actual Chromium workflow checks, 33 real-engine contract checks
and eight Python asset/data checks pass locally. These do not validate live model
generation: the test environment lacks required shader-f16, and iPad/Safari neural
behavior is unverified. Free hosting/CDN limits and device memory remain material.
No fine-tuning or automatic visitor-chat training has run. This is an experimental
public interface, not a shared inference service or production-quality model claim.

## Reported iPad initialization failure

An actual user reported `exit(1)` after a 100% download. The model has not been
shown working on that device. A separate bounded loader report now preserves
available runtime evidence, distinguishes progress from readiness, and attempts
cleanup before requiring a page reload for another initialization. Authored
simulated-runtime cases validate this handling; the real pinned WebLLM constructor
and unload API are checked without weights. These are not live inference tests
or proof of the user's hardware failure cause. See [failure recovery](FREE_PUBLIC_HELPER.md#when-the-model-fails-to-initialize).

The supplied device report and execution of the actual upstream negotiation
function identified an additional concrete defect: an adapter supporting 512 MiB
was configured with only 256/128 MiB limits, below the model's 307,298,304-byte
tensor minimum. A pinned local runtime patch retains supported intermediate
capacities and checks/logs actual device limits before parameters load. This
repairs the configuration defect; full physical-device inference remains a
separate check. Model identity/cache, source ownership and delivery rules remain.

> Update 2026-11-16: The [public 52-case evidence suite](PUBLIC_EVIDENCE_TESTS.md) and [bounded expert relation path](HISTORICAL_EXPERT_PATH.md) document the current update. Prior dated measurements and preserved historical sources retain their original scope; this note does not rerun or revise them.


## Unprepared-original conversion study — 2026-11-16

See the [frozen original-record evaluation](UNPREPARED_ORIGINAL_CHALLENGE.md) and [source mapping repair](SOURCE_MAPPING_REPAIR.md). Authentic originals and randomized synthetic controls have separate frozen inputs and retained outputs. Reversible candidate mappings preserve native authority boundaries; exact quote fidelity does not verify historical meaning. Independent human historical assessment is NOT RUN. Earlier results retain their original scope.


## Source-linked reconstruction follow-up — 2026-11-16

The [prose reconstruction follow-up](PROSE_RECONSTRUCTION_FOLLOWUP.md) measures false candidate relationships, retained useful associations, missing facets and processing costs on real public records. Source-consistent developer judgments remain separate from independent human validation and deterministic answer support. Earlier results are preserved.


Targeted recovery update (2026-11-16): the [source-linked recovery study](PROSE_RECONSTRUCTION_FOLLOWUP.md#targeted-recovery-and-false-association-retention) reports retained useful associations, recovered omissions, false date-cue corrections and unresolved transfer failures. It does not establish general historical understanding or independent human validation.

## Current source-research boundary

The [solo milestone](../evaluation/solo-milestone/2026-11-17/RESULTS.md) demonstrates
one additional complete recorded-arrangement answer on22 unchanged development
questions, plus a fresh-context blinded AI assessment. It does not establish
general accuracy, independently authenticated history, delivery/execution, or a
production-readiness rating. Source integrity, finite statement support, AI
assessment and external truth remain separate. The [current status](CURRENT_STATUS.md)
and [solo workflow](SOLO_RESEARCH_WORKFLOW.md) cover diagnostics, exact evidence,
local artifact rechecks and the16 remaining AI-assessed shortcomings.
