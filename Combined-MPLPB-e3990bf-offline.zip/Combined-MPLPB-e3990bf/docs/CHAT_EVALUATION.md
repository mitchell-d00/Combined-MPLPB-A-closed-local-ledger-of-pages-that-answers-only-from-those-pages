# Synthetic conversational evaluation

Last reviewed: 2026-11-17. See [current status and result-to-test index](CURRENT_STATUS.md). Dates and numeric results in historical validation sections retain their original scope; this review is not a rerun or independent certification.

Package role: [how this part fits Combined MPLPB](PACKAGE_GUIDE.md#conversation-and-resources). This guide covers bounded conversation or reference routing; context and source authority remain distinct.

This is developer-authored regression evidence, not independent human evaluation or a fluency rating.

## Reproduce

```
python -m unittest discover -s tests -q
python -m tools.evaluate_context_matrix --output NEW_CONTEXT_MATRIX.json
python -m tools.evaluate_conversation --scenarios evaluation/conversation/expanded-scenarios.json --output NEW_EXPANDED_RESULTS.json
```

The context matrix checks 20 subjects × 8 personal-memory question forms × 2 modes, plus 40 forgetting checks: 360 checks. Each requires the corrected value, absence of the old value, user-declaration authority and no fabricated source. Each scenario has an isolated save profile; transcript integrity is checked. The runner exits unsuccessfully when an expectation fails. Historical retained result: 360/360 (see the run metadata in the linked artifact).

The phrasing ablation tests the memory router with normalization disabled and enabled: 80/160 versus 160/160 recognized questions. It is a controlled router comparison, not a historical full-system baseline. See `evaluation/conversation/phrasing-ablation.json`.

Generated unit checks also exercise 990 arithmetic expressions and wording variants, 40 syllogisms including invalid converses, and 160 memory paraphrases. These are subcases inside test methods, not 1,190 separately counted unittest methods.

The expanded replay records 220 turns across 28 scenarios in both modes: greetings, emotions, listening preference, source topics, arithmetic, explicit-premise reasoning, brainstorming, goals, and source boundaries. Its outputs are observations, not automatically graded fluency successes. Novel-topic brainstorming preserves the chosen topic and option but repeats a finite family of transformations. Some source extracts retain awkward imported wording; dictionary senses may require disambiguation. These remain limitations.

## Changes motivated by runs

* Normalize curly apostrophes in personal declarations.
* Recognize polite memory questions without expanding factual ownership rules.
* Apply correction and forgetting order reproducibly, including user-defined meanings.
* Explain missing evidence directly in Serious mode instead of asking the user to repeat an already specific question.
* Isolate evaluation save profiles so the session capacity limit is tested separately from language behavior.

## Independent protocol

Freeze a commit, rule configuration and source snapshots before evaluation. Have evaluators outside the project select unfamiliar corpora and author questions without inspecting the rules. Include answerable, unanswerable, ambiguous and misleading-overlap questions; paraphrases, corrections and multi-turn topic shifts; both conversation modes and zero loaded collections. Separate tuning examples from a held-out set.

Two independent reviewers should label answerability, citation support, scope compliance, memory correctness and conversational relevance; reconcile disagreements without changing the frozen run. Publish every prompt, response, source identifier and adjudication, including failures. Report unsupported-answer rate and abstention precision alongside coverage; report conversational quality separately. Synthetic passing counts cannot replace this evaluation.

## Historical context behavior validation

The implementation passed 555 regression tests, 240/240 behavior scenarios,
the existing 1,000-response audit plus 250 confirmation calls, 360/360 context
cases and 78/78 fixed conversation turns. These developer-authored checks cover
finite cases; they are not independent validation or proof of general language
understanding. Historical reader failures remain limitations.

Run `python -m tools.evaluate_conversation_repairs --output behavior-results.json`
and `python -m unittest discover -s tests -q`. The
[report](../evaluation/conversation-repairs/results.json) contains conversations,
expected reactions, traces, source identifiers and evaluated source hashes.
See the [class table](../evaluation/conversation-repairs/README.md) for guards.

Choose a new output filename for each replay. Preserve committed historical reports; a current run is separate evidence tied to its own revision.

> Update 2026-11-16: The [public 52-case evidence suite](PUBLIC_EVIDENCE_TESTS.md) and [bounded expert relation path](HISTORICAL_EXPERT_PATH.md) document the current update. Prior dated measurements and preserved historical sources retain their original scope; this note does not rerun or revise them.
