# Checked documentary assertions and question composition

Last reviewed: 2026-11-17.

Package role: [how this part fits Combined MPLPB](PACKAGE_GUIDE.md#documentary-research). This guide covers documentary inspection; source assertions, candidate relations and historical truth remain distinct.

Strict answers now have a bounded documentary path after existing strict grammars fail. `documentary.py` proposes exact source units and decomposes up to four question obligations. `documentary_verify.py` reloads current eligible bytes with the **complete original question and delivery profile**, independently locates full source units and derives typed source assertions. Extractor fields, graph edges, citations alone and model approval cannot issue certificates.

The first contract covers plain named-subject past-tense clauses (appointment, sending/receiving, writing, surveying, publication, revision, cancellation and directives) and first-person requests in ordinary correspondence. Correspondence must have an original writer TO addressee heading and an unquoted opening statement. Told/asked/instructed/requested/ordered and send/deliver/forward/post forms can retain literal objects, delivery methods, conditions and hopes. I/you/my bindings apply only to that documentary appearance. The heading date has unresolved documentary role; it is never silently an instruction, dispatch or receipt date. Conditional delivery, unclear qualification scope and following notes remain visible.

A certificate establishes a **source-attributed assertion within this finite grammar**. It does not authenticate authorship, resolve a historical person/event identity, prove that a reported instruction occurred, or establish dispatch, receipt, fulfillment or independent historical truth. Ordinary quotation remains separate from this typed support. Candidate prose/relationship graphs retain their non-authority contract.

For plain who-action questions, the requested literal argument must match the checked assertion. The checker scans eligible units for competing, qualified, unparsed, possibly corrective or referential evidence. Unknown scope, unresolved identities/references, incomplete scans or budget omissions prevent a complete answer. Opposed source statements are presented without claiming they describe the same underlying event or establish a historical contradiction. Temporal differences require clarification. Multiple appearances remain separate witnesses, not independent corroboration or an event merge.

Composition joins independently checked answers to separate question obligations; it does not invent links between them. `supported_answer` requires every obligation to pass, complete applicable checking and sufficient display budget. `partial_answer` retains checked claims plus exact missing obligations; its overall `answer_supported` stays false. Each checked claim separately records `source_support_established`, the kernel version, evidence/meaning digest, exact citations and `historical_truth_independently_verified:false`. Unparsed alternatives stay unverified. Reported instructions remain partial for questions about actual arrangement/execution and carry an explicit correction/cancellation-review limitation.

The path is read-only, preserves revision/correction/serving gates, and never recursively asks shortened questions that lose original exclusions. Source or policy changes discard claims, quotes and documentary metadata at the existing final gate. Known HTML quotation/chrome ranges and qualified headings constrain support without making ordinary navigation invalidate a whole document. HTML titles and layout headings alone never supply answer facts. Original letter headings in canonical source text are checked explicitly for printed party/date roles.

Limits: four obligations, 12 proposals, 200,000 scan characters, 1,000 source units, 64 parsed action assertions, and the caller's passage/quote display budget. Exceeding a limit yields explicit partial/abstention output. Existing strict-first, assisted-mode, exact-field and scoped-correction contracts remain in force. The two new modules use the existing answer package and standard library, so the browser runtime can load them without the specialist-work package.

This is a finite parser and proof contract, not general entailment or historical understanding. It conservatively rejects many modifiers, voices, names, quotations and indirect references. Natural-language ambiguity and scope outside the implemented grammar still require independent semantic review. Typed source support is not a scientific accuracy score; unknown precision/recall and human times remain null.

Tests include independently varied fictional wording/names/objects/dates, source changes, original-question exclusions, restricted references, negative/conditional/quoted statements, incomplete composition and budgets, directives versus execution, source corrections, ambiguous identities/time and exact original-byte round trips. `tests/test_documentary_originals.py` uses unchanged development questions and original imports, not hidden answer fields. `tests/documentary-render.cjs` and the real WebAssembly suite exercise result/citation rendering and composition. Browser and CI paths run the new rendering control.

Reproduce the frozen original studies with their existing seals and unchanged runner, then run `python -m tools.compare_documentary_answers CORPUS BEFORE_RUN AFTER_RUN --output NEW_DIRECTORY` from the exact updated implementation. The postprocessor reimports originals, reruns the kernel against every accepted certificate, verifies meaning/proof digests and reverse maps all citations to original bytes. It prepares blank human-review/adjudication sheets without assigning accuracy. Full independent review and genuinely unseen evaluation remain NOT RUN.


Final extracted implementation `6acf45a9f77213953f8236379236c96662442153` passed 1,068 Python tests, prepared public controls, actual WebAssembly and Chromium UI checks. [Retained frozen comparisons](../evaluation/documentary-assertions/RESULTS.md) show two checked partial source answers versus zero before across 22 unchanged questions; full historical supported answers remain zero. The earlier plan-heading false acceptance and fix are retained. Independent human review and unseen evaluation are NOT RUN.


Reconstruction update (2026-11-17): [documentary research mode](HISTORICAL_RECONSTRUCTION_ENGINE.md) adds source-unit/layer inspection, literal relationship checks, exact paragraph comparisons and candidate graphs. [Review rules](HISTORICAL_TRUTH_RULES.md) keep synthetic fixture truth, human assessments and real historical truth separate. Final new measurements are retained separately; earlier historical reports remain unchanged.


Kernel v3 [source-framed comparison completion](HISTORICAL_RECONSTRUCTION_ENGINE.md#completing-literal-source-comparisons) independently checks body-role witnesses, source/work references, topic boundaries and both word operations. [The final unchanged-question replay](../evaluation/reconstruction-engine/2026-11-17/RESULTS.md) yields one complete source-relative comparison and two partials, not independently verified historical truth.

## Kernel v4 recorded-arrangement completion

The [solo rule](SOLO_RESEARCH_WORKFLOW.md#complete-recorded-arrangement-answers)
can complete a finite question about a named writer's recorded request and dated
letter. The checker independently binds original names, recipient/possessive
references and item wording, then requires the printed heading, complete instruction
and complete bounded local-letter witness. Delivery, acceptance, execution and
external historical truth remain unverified. Earlier partial-only results above
describe their measured revisions; the [new unchanged-question replay](../evaluation/solo-milestone/2026-11-17/RESULTS.md)
has2 complete source answers and1 partial. Additional obligations or missing
witnesses still prevent completion.
