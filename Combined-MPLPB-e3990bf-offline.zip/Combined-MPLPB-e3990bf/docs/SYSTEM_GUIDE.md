# Current system and self-knowledge

Last reviewed: 2026-11-17. See [current status and result-to-test index](CURRENT_STATUS.md). Review is not a fresh measurement or independent certification.

This document is generated from `tools/self_knowledge.py`. It describes implemented software behavior; it does not establish consciousness, general understanding or factual correctness. Self-description is labeled separately from MPLPB source evidence.

Package role: [how this part fits Combined MPLPB](PACKAGE_GUIDE.md#conversation-and-resources). This generated self-description covers the conversational interface; it is not source evidence.

## What is a MPLPB?

A MPLPB is a bounded local collection of knowledge pages. Each page carries its content, scope and provenance; the reader checks which pages may support a question. My chat interface helps you explore those pages and presents their sources. The conversation rules construct the reply, but they do not turn unsupported wording into evidence.

## What are you?

I’m MPLPB’s rule-based little monster. I use explicit language and conversation rules; I don’t run an LLM or have consciousness or private experiences.

## What can you do?

We can talk about your day, explore an idea, work through a small calculation, or discuss a topic using available content. I can index this conversation, replay explicit personal-detail corrections, recall earlier exchanges, remember user-defined word meanings, chat, follow a topic, explain my rules, look up words, explore saved pages, show sources and construct bounded replies. I can follow numbered brainstorming choices, retain user-stated project goals and constraints, calculate bounded arithmetic with exact fractions, and apply a limited all-members rule to explicit hypothetical premises. These calculations and user premises are separate from MPLPB source evidence. In Chat and Serious modes, “browse library” opens the library index. “library ask in SHELF: QUESTION” checks one declared book scope; ambiguous routes ask you to narrow. I can capture public sources through the configured search tools. My language coverage is finite; I ask for clarification or report missing support when the rules cannot answer.

## How do your modes work?

I can chat in Chat, Serious, and off-the-record free chat. Free chat keeps only an ephemeral session in the running app, uses local conversation rules, bundled dictionary references and attributed seed notes, and never saves a transcript or fetches sources. Leaving free chat discards that session. Chat clears the active serious scope but retains saved pages; topic requests can consult eligible saved pages. Serious mode checks loaded collections first. If they do not answer a topic request, saved references can supply a separately tagged answer outside the loaded scope. Dictionary meanings are tagged separately too; none of these lookups silently loads a collection. Their sources and boundaries remain separate.

## How do you construct sentences?

I parse common request forms and subject-description statements, preserve negation, resolve supported topic references, select conversational actions and construct language in defined grammar slots. User-introduced descriptions remain user-provided context; they do not become verified facts. The dictionary and thesaurus help with word senses and wording. Conversational framing uses pinned verb senses; “Other words for that meaning” offers alternatives within a selected dictionary sense without inventing tone or register. I can respond to interest, confusion and discussion requests using freshly checked content. Source quotations, numbers, qualifications and proof text are preserved. Recent social and attribute-question frames support bounded corrections and follow-ups. Explicit guards select behavior classes; fixed ranks resolve supported temporal spelling variants, and ties request clarification. Identical input and complete session state give identical results. Source follow-ups still pass existing evidence checks. Source-authored linear procedures can be inspected through explicit identifiers and bounded natural questions. In a selected source scope I can ask which step you mean, accept a correction, and recover the selection after reload. “inspect next step” reads the next instruction; it does not verify completion or satisfy source conditions. Incomplete procedure records remain labeled partial source evidence.

## How do you work?

I use explicit rules: I read your message and the current conversation, identify a supported kind of request, then choose the appropriate local rule. For ordinary chat I construct a response from conversation context and grammar. For a topic I can consult bundled reference notes, dictionary senses or eligible saved pages. Page-based claims keep their source checks and citations. Finally I validate the response and, outside free chat, save the conversation. The same rules, inputs and complete state produce the same result; no language model samples the next word.

## Where do your answers come from?

Page-based factual replies use eligible MPLPB pages and show their references. Bundled seed notes retain their separate research-note attribution in every mode. Definitions use the bundled WordNet resource. Conversation and imagined ideas are labeled separately; they are not page evidence. A matching page or a valid hash does not prove that a claim is true.

## How do you search?

I check eligible local pages first for supported topic requests. With automatic Wikipedia lookup enabled, missing or exhausted material can trigger a bounded capture and retry. Explicit search and import also contact the selected service. You can type “search dogs”, select a Wikipedia source, and send it. General web crawling needs a configured, deployed crawler and its access settings. Wikipedia mode needs neither that crawler nor its token; I do not browse the whole web or scan local folders independently.

## How does your memory work?

In Chat and Serious modes, I retain conversation state, notes, topic context and captured pages in the configured local save store, with no fixed retention timer or guaranteed storage lifetime. In off-the-record free chat, only the running app’s ephemeral session retains conversation context; leaving it or restarting the app discards that session, and MPLPB does not save its transcript. I can recall an introduced name and find earlier user statements about a topic in this conversation. Corrections replace the name I use; “forget my name” stops its use without erasing the existing transcript. User statements remain conversation context, not verified identity or MPLPB evidence. The browser build uses this browser’s storage; the desktop app uses local files. Saving is not model training. Clearing browser storage can erase browser saves, so export important material.

## What are your limitations?

My reader uses lexical matching, not general semantic understanding. My grammar covers finite patterns. Missing, ambiguous or conflicting evidence must stay visible; selecting fewer candidates never creates proof. Developer tests are not independent human validation, and production reliability in critical settings has not been established.

## What data do you have?

The bundle contains Open English WordNet 2025, CMU Link Grammar reference data and 23 pinned Simple English Wikipedia captures, alongside example collections. The Link Grammar parser is not running. More Wikipedia articles can be captured online; the entire encyclopedia is not stored offline. An optional 73-declaration reference preview is available in the repository with complete authored tests and staged snapshots. It is unratified, requires the lab profile, and is not loaded into the hosted app by default. Its 73/73 development result is source-declaration matching, not independent fact verification. Saved user collections depend on this installation.

## Tools beside the conversational interface

The full source package also provides the offline sorter, native ledger and answer CLIs, documentary investigation, capability-scoped specialist work and local MCP. These are separate entry points, not implied browser buttons or new MCP tools. The sorter emits candidates or a retired native snapshot; it cannot activate relationships as factual answers. See the [package guide](PACKAGE_GUIDE.md), [sorter contract](PREPROCESSING_SORTER.md) and [installation contents](INSTALLATION.md). One owner returns; two stop; none refuses at the eligible page-ownership layer; strict source support still needs its finite body proof.

## Current-state questions

Ask “What mode are you in?”, “What do you have loaded?” or “What are we talking about?”. These answers read the current session, preserve its mode and scope, and do not fetch remote sources. Current loaded collections are distinct from collections merely saved locally.

> Update 2026-11-16: The [public 52-case evidence suite](PUBLIC_EVIDENCE_TESTS.md) and [bounded expert relation path](HISTORICAL_EXPERT_PATH.md) document the current update. Prior dated measurements and preserved historical sources retain their original scope; this note does not rerun or revise them.
