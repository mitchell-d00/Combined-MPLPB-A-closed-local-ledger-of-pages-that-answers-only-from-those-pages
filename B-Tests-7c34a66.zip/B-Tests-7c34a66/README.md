# B-Tests — MPLPB and OOCC/CAD comparative experiments

**The 30 fresh AI sessions compared two governance prompts.** One used
Benjamin Gelhaus’s published OOCC/CAD instructions. The other used a
strong conventional governance prompt prepared by B-Tests. Combined
MPLPB ran separately in native before-and-after tests of two versions of
Mitchell D. McPhetridge’s code. The native probes verified effects with
adapter marker files and ledger event counts.

**Native Gelhaus OOCC/CAD and M6 were not run in B-Tests.** Gelhaus’s later
public MPLPB benchmark package includes a reproduction script with fixture
and query code. Its inspected engine imports are McPhetridge’s MPLPB
writer, answer pipeline, and reader profiles. The driver prepares and counts
benchmark cases. MPLPB supplies the code that writes the ledger and decides
which answers are supported. The package supplied no
runnable native OOCC controller or M6. The cited OOCC repository returned
404 when checked again on November 23, 2026.
[What was tested and who wrote what](docs/COMPARISON_SCOPE.md) ·
[Machine-readable comparison scope](research/comparison-scope.json)

## Find a test or experiment

The [test and archive index](docs/TEST_INDEX.md) lists suites, runners, evidence,
and proposed tests. AI readers can start with [test-index.json](research/test-index.json)
and search the [full file and case inventory](research/test-inventory.jsonl).
GitHub Actions refreshes the index after changes reach `main`.

## Research practice

B-Tests is part of a distinctive, independently developed approach to making AI
research inspectable and reproducible. The strongest evidence for that
description is the record we leave when a test fails. We keep the tested
revision, inputs, commands, and logs alongside any rerun so reviewers can see
what changed. In the PR #46 replay, the initial socket-setup failures and the
successful retries with the same code are both preserved.
[PR #46 replay and logs](evaluation/mplpb-updates/3df2c6e22f0ef454f3ee67b88d43402a42f63443/RESULTS.md)

## Testing OOCC — explicit comparison ledger, 20 November 2026

**Mitchell D. McPhetridge, Testing OOCC: Claims, Required Tests, and a Roadmap to Verified Behavior (v1.4).** [MD](docs/paper/TESTING_OOCC.md) · [TXT](docs/paper/TESTING_OOCC.txt)
· [PDF](docs/paper/TESTING_OOCC.pdf) · [New reproducible results](evaluation/public-claims/2026-11-20/RESULTS.md)
· [Mitchell paper archive and original source paths](docs/papers/archive/README.md).

The revision adds [34 source-linked claim/test families](docs/OOCC_CLAIMS_AND_REQUIRED_TESTS.md), a [machine-readable roadmap](research/oocc_claim_tests_v1.json), and McPhetridge's engineering recommendations. Each entry separates the attributed claim, current evidence, required comparison, adversarial cases, metrics, prerequisites and proposal credit. Gelhaus's already proposed experiments are credited; this roadmap is **not 34 completed tests or 34 demonstrated defects**. Native OOCC and new model trials remain **NOT_RUN**. The [first edition](docs/papers/archive/testing-oocc-v1.0/TESTING_OOCC.md) and its hashes are preserved.

[Revision verification and exact commands](evaluation/public-claims/2026-11-20/PAPER_V1_3.md). The paper, catalogue and archive can be checked with `python -m tools.verify_oocc_claim_roadmap`; this verifies artifact consistency, not semantic correctness.

**OOCC checkpoint counts are author-reported, not independently reproduced here.** The supplied papers can be inspected; the underlying checkpoint databases, verifiers and retrieval runs were not executed by this review. No standalone public runnable packet for those checkpoints was obtained. The public MPLPB paraphrase replication is a different experiment. A reported pass, a published artifact and an independently reproduced result are separate evidence states. See [checkpoint attribution and verification limits](docs/paper/TESTING_OOCC.md#71-checkpoint-claims-and-verification-status).

[M6 attribution correction and preserved-edition erratum](docs/paper/TESTING_OOCC_ERRATA.md).

**Authorship:** MPLPB, B-Tests and MPLPB’s pre-existing native test machinery were built by Mitchell D. McPhetridge. Gelhaus reports benchmark selections and analysis; running upstream tests does not transfer authorship. A script bundled in his package does not establish that he authored a separate driver or test framework. The later public driver imports MPLPB’s own writer, strict answer pipeline and profiles. According to McPhetridge’s clarification, M6 is an additional component Gelhaus adds; it is absent from the supplied ZIP. Its internal behavior and original execution role cannot be independently established from that package. McPhetridge’s [first response, PDF pages 2 and 7](docs/papers/archive/field-access-response/response.pdf), already states that M6 was not included. It is not McPhetridge’s private M6. [Exact attribution and package evidence](docs/paper/TESTING_OOCC.md#131-attribution-mcphetridges-machinery-gelhauss-benchmarks) · [Code/import audit](evaluation/public-claims/2026-11-20/attribution-audit.json).

The table below identifies what is compared with what. A source discussion,
reference-program check, model response and native effect are different evidence
units. **Our CADLab is not Ben's OOCC controller.** A mocked or prewritten result
is not a model observation. No missing native OOCC arm receives an invented zero.

| Comparison | Exact objects/arms | What was measured / status |
|---|---|---|
| Published-instruction model trials (retained earlier studies) | Selected published CAD instructions versus capable conventional governance, matched sources and base model within each recorded condition | Recorded model answers and handoffs; original model/session limitations and dated denominators remain in their reports. Not native OOCC enforcement. |
| Independent CAD reference controls | B-Tests `oocc_lab.engine.CADLab` versus authored structured-source and permission expectations | Behavior of our program; never credited as tests of Gelhaus's implementation. New public-claims run4/4 controls. |
| Native MPLPB before/after (retained) | Actual pinned MPLPB revisions, same local source/task seam fixtures | Real adapter markers and event counts. Historical/current pins differ across dated reports; they are not silently combined or described as OOCC arms. |
| Native MPLPB current, new C4 | Actual61cc7c04ebdfa84c8d783e005c6e7857c07600b2 versus the seven seam criteria and independent local readbacks |7/7 criteria met; one real allowed control,6 expected denials. Not an unconstrained language or historical-truth evaluation. |
| Sorter modes (retained) | `compare` versus `not-compared` on identical source bytes and recorded target revision | Same observations, additional non-authoritative review edges; separate snapshot/reader profile checks. Not event-identity accuracy. |
| Mixed-dump/d100 users (retained) | Designated original ledgers versus processed candidate dumps/workspaces, per recorded user/profile/budget | Native decisions, source maps, candidate preservation and no candidate promotion. Web topics are fixture metadata, not factual evidence. |
| Public-paper reader probes (retained) | Older strict reader against bounded extracted public-paper text | Whole-page selection/withholding at the recorded pin. A returned page or absent support field is not a supported proposition. |
| New C1 numeral probes | Decimal powers of ten versus equivalent Python expressions |512 sampled counterexamples to a broad decimal-minimality inference; byte counts, not token/latency data or512 OOCC failures. |
| New C2 encoding probes | Repeated referent text versus dictionary plus handles |15/20 indexed cases cheaper,5 more expensive; explicit encoding assumptions and definition cost. |
| New C5 prepared instruction comparison | CAD pages3,4,7 versus conventional instructions, identical future model and task |NOT_RUN. Five authored source questions per arm; instruction lengths differ and are recorded. Packets/scorer ready; no generated responses masquerade as measurements. |
| Native OOCC versus native MPLPB, C6 | Gelhaus's version-pinned controller and actual storage/executor versus native MPLPB under matched operations |NOT_RUN. Requires authorized runnable controller, adapter, current permissions and independent effect readbacks. |

[Exact comparison metadata](evaluation/public-claims/2026-11-20/comparisons.json)
· [Ten-paper source hashes](evaluation/public-claims/2026-11-20/sources.json)
· [Prior supplied artifacts and duplicate map](evaluation/public-claims/2026-11-20/prior-materials.json).
New model/human accuracy remains unmeasured. The existing observations below retain
their own dates: older “current” labels are not automatically updated to61cc7c0.
The [Section19 author clarification](evaluation/witness-section19/AUTHOR_INTENT_2026-11-20.md)
identifies the old witness ZIP as Mitchell's test-design scaffold, separate from
the revised paper, later filesystem pilot and native runs. Scripted examples are
credited as design rather than counted as target performance.
The new critique cites Ben's explicit limits and his acknowledgments of Mitchell's
work; it does not claim his entire project is merely one prompt or that every
unimplemented proposal failed an operational test.

### MPLPB limits retained in this comparison

The new native pin is61cc7c0, not the older “current” revisions in dated reports.
Its source-grounded alias iteration increased unchanged expanded-stress complete
matches168→189/420 while preserving580 expected refusals. Its retained historical
replay is3 native complete,2 partial,3 conflicts and14 abstentions out of22; those
are not independently adjudicated historical answers. The separate4096-case D%
study reports657/1262 complete key matches and2834/2834 expected refusals. These
populations and metrics are distinct and are not pooled or used to claim a global
OOCC/MPLPB winner. These are linked MPLPB development measurements, not extra
new B-Tests model trials or independent accuracy certification.
[Alias evidence](https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/61cc7c04ebdfa84c8d783e005c6e7857c07600b2/evaluation/field-aliases/2026-11-20/REPORT.md)
· [Known-weakness study](https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/61cc7c04ebdfa84c8d783e005c6e7857c07600b2/evaluation/dpercent-known-weaknesses/2026-11-20/REPORT.md).

## What the testbench has tested

The [Executable Gates comparative tests](comparative-tests/executable-gates/REPRODUCTION.md)
pair seven native MPLPB dispatch controls and variants with a local Git comparison
of a README rule and the same rule enforced by a pre-receive hook. The package
retains the paper, original probes, and reproduced marker, event, and server-state
readbacks. The measurements cover the named local fixtures.

The [dispatch enforcement follow-up](comparative-tests/dispatch-enforcement/README.md)
adds 28 controls across Python, seat RPC, loopback HTTP and the stock CLI. It
reports the effect and event history separately. Complete mediation under
adversarial conditions remains unestablished.

B-Tests supplies the test cases, published instructions, fresh-session procedures,
scoring code and retained logs needed to examine Ben's published OOCC/CAD ideas.
**I have the testbench; I do not have Ben's private system to put on it.** His papers
refer to private controller components and primary records that have not been
available to this evaluation. Testing that system requires its exact runnable
version, setup, authorized source access, adapter and independently checked state
readbacks. Those native-system tests remain **NOT_RUN**.

The **30 fresh AI sessions** compared Gelhaus’s published CAD governance
instructions with B-Tests’ strong conventional governance prompt. The cases tested false approved maps,
contradictory sources, archive discovery, failed-work history, permissions, receipts,
unsupported relationships, compressed handoffs, false originals and a simulated
human export. Both instruction treatments corrected accessible contradictions and
rejected unsupported relationship expansion. Specific output/budget failures and
results favorable to CAD are retained. These runs did not establish a consistent
CAD advantage over the tested conventional instructions.

We also executed **MPLPB's actual program**: native source and permission checks,
real local action controls, the sorter and public evidence probes. A valid control
really invoked a local executor; invalid cases were blocked and checked through
effect files and event counts. These checks execute through guarded software
interfaces, without relying on a model agreeing to follow a prompt. MPLPB packages
its bounded rules and verification for supported runtimes without requiring a
particular AI provider or conversation.

In plain language: **we tested how AI follows the published instructions and how
MPLPB's software enforces its checks. We have not tested Ben's private controller.**
The [recorded instruction results](docs/CRITICAL_BENCHMARK_RESULTS.md),
[archive discovery](docs/UNFLAGGED_DISCOVERY.md),
[handoff propagation](docs/ARCHIVED_PROPAGATION.md),
[human export](docs/SINGLE_PROJECT_HUMAN_EXPORT.md) and
[native software results](evaluation/mplpb-updates/ccbb5804eb47f78c2338d57c142ad087b47be710/RESULTS.md)
show the exact scope and outcomes. A written refusal and a verified blocked
operation are different observations.

## Use B-Tests with another system

B-Tests measures how a system deals with originals, candidate material,
competing claims, corrections, permissions, and incomplete handoffs. Give
each target the same source records, task, allowed operations, and budget.
Pin the software revision or record the model, instructions and tool access.
Run each prompt treatment in a fresh session with only its assigned packet.

| Target | How to run it | What the result can establish |
|---|---|---|
| MPLPB or another runnable system | Use its native interface. The supplied runner calls MPLPB directly. For another system, write an adapter that submits the same task and retains native decisions, citations, and state readbacks. | Source selection and proof behavior. Where the adapter observes the executor independently, it can also establish that an authorized effect occurred or that a prohibited one was blocked. |
| OOCC/CAD or standard governance prompts | Use published CAD instructions or ordinary governance instructions with the same base model, packet, tools, and budget. Save the full response and available tool traces. | How the model applied the instructions, cited evidence, disclosed uncertainty, and requested or declined actions. |
| A runnable OOCC controller | Pin the controller release and run the same tasks through its own storage and executor. Record current permissions, decisions, receipts, and independently checked effects. | Native behavior of that exact controller. Report unavailable native interfaces or checks as `NOT_RUN`. |

The d100 generator in [the randomized protocol below](#repeatable-d100-test-with-100-web-sourced-topics)
provides **25 individually assigned synthetic users**, each with a separate
source collection and four topics. The five scripted mixed-dump users provide
a readable starting point for checking specific cases. For a fresh comparison,
have the evaluator prepare the packets and keep the seed, scoring key,
and other conditions outside each target’s access. Give a target only its
assigned packet. The native d100 runner passes MPLPB source paths and questions
without exposing the operator key through its interface. The published run
is replayable development evidence.

For each case, record the returned or withheld answer, exact citations,
candidate links, statuses and, if applicable, the observed effect. Use
the same acceptance criteria across arms. Mark a capability outside a
target’s declared scope explicitly and distinguish it from an executed
failure. Freeze source bytes and expected results before testing, retain
command receipts and negative attempts, and check effects through a
separate readback. Report candidate discovery, supported answers, and
enforced actions as separate outcomes. Use independent unseen source
selection and blind human scoring for claims about historical accuracy.
[Comparison protocol](PROTOCOL.md) · [Fresh-model packet procedure](#repeat-with-any-ai)

## Ben's native MPLPB run — 14 November 2026

In [Beyond Guarded Retrieval](https://www.academia.edu/181013727/Beyond_Guarded_Retrieval_A_Source_Bounded_Evaluation_of_Combined_MPLPB_and_a_Roadmap_for_Historical_Reconstruction),
Benjamin Gelhaus evaluated Combined MPLPB 2.1.0rc1 at pinned commit
[`257e54a51edac272eb6b2441457f38a40485ee4d`](https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/tree/257e54a51edac272eb6b2441457f38a40485ee4d).
Gelhaus selected and ran 58 tests from the native MPLPB regression harness I
built and published with the release. For his evaluation probes he used the
unchanged writer, validator, strict-answer interface, provenance/source bundle
and passage ranking. He designed the evaluation and reported the results.

**All 58 selected native regression tests passed.** His reported retrieval results
included **31/49** exact-phrase targets in the top five and **40/42**
communication-header targets ranked first. The linked paper documents the runs.

**Thank you, Ben, for running MPLPB and publishing the results.**

I’m looking for more people willing to run MPLPB and repeat the public tests.
[Follow the pinned run instructions](evaluation/mplpb-updates/ccbb5804eb47f78c2338d57c142ad087b47be710/RESULTS.md#repeat)
and [share your results in an issue](https://github.com/mitchell-d00/B-Tests/issues/new),
including the exact commit, commands, output logs and any failures you find.

## Two projects I was working on before Ben's critique

In my May 2026 self-review, I revisited and withdrew the completion claims in
my own research account. *The Residual of Logic* traces how that self-correction
led to a software question about preserving the ability to reject stale claims
after recovery. [Self-review account](https://github.com/mitchell-d00/mplpb-residual-experiment/blob/1ec160051ba306ce61d74ba3186f0aa5873694c5/paper/The_Residual_of_Logic.md#2-the-research-arc-the-method-corrects-its-writer)

I was already working on both projects on **10 November 2026**, the day I made
the Combined MPLPB commit Ben later tested. GitHub records that commit at
**15:17:53 UTC**. Both projects have public commits and recorded runs on
**11 November 2026**, before Ben's paper dated **14 November 2026**.

- **MPLPB Residual Experiment** tested whether the ledger still enforces
  ownership, eligibility and refusal after recovery. The pilot started at
  **13:05:28 UTC** on November 11 and used the same Combined pin Ben tested.
  [Repository](https://github.com/mitchell-d00/mplpb-residual-experiment) · [Pinned run record](https://github.com/mitchell-d00/mplpb-residual-experiment/blob/1ec160051ba306ce61d74ba3186f0aa5873694c5/results/pilot-1/environment.json)
- **Portable Evidence Runtime** tested offline transfer of a package containing
  records, rules and a verifier. Its November 11 record shows **15/15 synthetic
  cases passed** at **14:59:48 UTC**.
  [Repository](https://github.com/mitchell-d00/portable-evidence-runtime) · [Pinned run record](https://github.com/mitchell-d00/portable-evidence-runtime/blob/4fdc20193c01f82baea0598b4c7d8ef3040772d5/experiment/results/synthetic_run.json)

[Timeline through November 18, including the response to Ben’s critique](docs/RESPONSE_TO_BEYOND_GUARDED_RETRIEVAL.md#exact-chronology)

## MPLPB then and now

**Then.** Ben tested Combined MPLPB 2.1.0rc1 at [`257e54a`][mplpb-ben-pin].
It already had sealed sources, integrity and lineage checks, supersession,
profile eligibility, passage ranking, finite source-body proof, an evidence
graph and a specialist work coordinator. Ben used the upstream harness and
reported 58/58 selected regressions passed. His source-location and
historical-question results describe that exact release.
[Ben's results by experiment](docs/GELHAUS_EXTERNAL_EVALUATION.md)

**Now.** As of 18 November 2026, Combined main is [`bbf6690`][mplpb-now-pin].
The [pinned Git comparison][mplpb-pin-diff] spans 79 commits. The merged PRs
below show which capabilities were added, which existing behavior was extended,
and where an observed defect was repaired.

### What changed after Ben’s pin

| Combined PR | Added or changed |
|---|---|
| [#40][mplpb-pr40] | The work coordinator now rechecks finite source-body support before handoff, dependency use and dispatch. Direct evidence is required and contradictory or claim-only dependencies stop downstream work. Prior assessments and failed attempts remain in history. [Source-support checker][mplpb-work-support] |
| [#41][mplpb-pr41] | Added an opt-in documentary investigation with documentary, chronology and separately parsing verification roles. It follows explicit, bounded references with citations and stop reasons, retains separate event appearances and body variants, and adds explicit scoped correction that preserves the predecessor and unaffected text. Added the published 52-case evaluation. [Investigation code][mplpb-investigation] |
| [#42][mplpb-pr42] | Added the original-record study runner with pinned inputs, sealed question and gold commitments, isolated execution, source-cited reviewer submissions and adjudication. This gives an outside evaluator a runnable protocol on unchanged originals. [Study protocol][mplpb-study] |
| [#43][mplpb-pr43] | Added exact ID/hash and unique body-field routing, distinct diagnostic reasons and conflict retention under display budgets. Separated declared event IDs, repeated event keys and source appearances. Added field/time correction windows, read-only as-of views, up to two source-quoted relation steps, separation of receipts from claim support, and optional operator-time recording. [Scoped evidence contracts][mplpb-scoped] |
| [#44][mplpb-pr44] | Extended gated passage discovery for ordinary prose and reverse mapping to original bytes. Improved candidate dates and relations, retained unresolved links, and published raw-original transfer tests, omissions and failed attempts. [Prose recovery report][mplpb-prose] |
| [#45][mplpb-pr45] | Added a fresh-source documentary assertion checker and compound-question handling. Each checked part carries quotes, qualifications and provenance. Missing obligations and contrary evidence stay visible, including in the browser. [Documentary verifier][mplpb-doc-verify] |
| [#46][mplpb-pr46] | Added checked literal wording comparisons and proof of limited arrangements explicitly recorded in the source. Added source-unit inspection, candidate graphs, typed historical review, clearer refusals, bounded parsing reuse, native local-artifact storage checks and raw crawler identity rehashing. [Reconstruction engine][mplpb-reconstruction] |
| [#47][mplpb-pr47] | Added the offline dual-mode sorter, source-anchored candidate graphs and verified retired-ledger export that the pre-sorter reader can open. Published the technical paper and reproduction tooling. [Sorter code][mplpb-sorter-code] |
| [#48][mplpb-pr48], [#49][mplpb-pr49] | Revised the sorter paper front matter and consolidated the package, installation and authority guides. The reader’s proof rules remained in place. [Package guide][mplpb-package] |
| [#50][mplpb-pr50] | Fixed a sorter defect where quoted or fenced identifier headers could create false occurrence boundaries and enter primary identity clusters. Embedded headers retain their spans and review annotations. [Before/after report][mplpb-header-report] |
| [#51][mplpb-pr51] | Added the optional strict-first local narrator for Ollama, llama.cpp and local OpenAI-compatible endpoints. An accepted rendering preserves the checked answer, and a fresh source and policy check runs before it is returned. Refusals, conflicts and partials bypass narration. [Narrator code][mplpb-narrator] |
| [#52][mplpb-pr52] | Added the candidate review workspace, strict passage admission, and installed-runtime byte mapping. The workspace compares processed documents with eligible originals and preserves exploration at a separate budget. [Fresh B-Tests results](evaluation/mplpb-updates/bbf6690d69b32d16969cc10e5ce9d380427ead40/RESULTS.md) |

### How the sorter works

The sorter runs offline on UTF-8 text and Markdown. It records occurrences,
headers, dates, references, correction cues and other observations with the
original file hash and exact character and byte spans. PDF and image sources
need text extraction first. [Sorter guide][mplpb-sorter-guide]

| Mode | Output |
|---|---|
| `not-compared` | Source observations and textual links such as containment or co-occurrence. These let a reviewer see what each source says in context. |
| `compare` | The same sources, nodes, spans and observation edges, plus review edges for possible duplicates, different bodies under the same identifier, possible corrections and explicit references. Ambiguous or missing reference targets stay unresolved. |

The earlier fixture retained **176 identical nodes** and **264 observation
edges**, with **77 review edges** added in compare mode. A verified graph can
be stored as a sealed, retired, machine-origin snapshot. The unchanged
pre-sorter reader showed the snapshot for inspection and withheld it from
answers under lab, internal and external profiles. Candidate links carry no
answer support. In a later defect probe, classifying embedded headers first
changed **three occurrence partitions to two** and removed the quoted example
from the primary identity cluster while preserving its text. [B-Tests sorter
rerun](evaluation/mplpb-updates/ccbb5804eb47f78c2338d57c142ad087b47be710/RESULTS.md#native-sorter-evidence)
· [Header-scope regression][mplpb-header-report] · [Technical paper](docs/papers/README.md)

### Mixed-dump sorter tests with five synthetic users

Each scripted user builds a separate native MPLPB ledger from explicitly
designated originals, sorts a mixed processed dump in both modes, and builds
and replays candidate workspaces at normal and tiny exploration budgets.
The five cases cover one owner with support, competing owners, no owner,
one owner without support after withdrawal and profile filtering, and
topic-only review of real MPLPB documentation alongside synthetic notes.

The runner checks that both modes preserve the same source observations,
candidate classification never transfers approval, original and processed
byte spans replay, and exploration charges leave the strict decision intact.
Every input gets a source-map entry, including CSV and JSON files outside
the sorter’s input formats and extracted statements absent from the
display. In the mailbox fixture the CRLF export yields a wording-review
candidate, and a separate literal copy yields an exact-match candidate.

From B-Tests, point at a clean Combined checkout at `bbf6690d69b32d16969cc10e5ce9d380427ead40`
and use a fresh output directory:

```sh
python -m research_lab.sorter_mixed_users --mplpb-root ../combined --out /tmp/mplpb-mixed-users
```

The output includes each ledger, both sorter graphs, candidate workspaces,
source maps, and command receipts. [Synthetic user fixtures](fixtures/sorter_mixed_users.json) ·
[Five-user results](evaluation/mplpb-updates/bbf6690d69b32d16969cc10e5ce9d380427ead40/mixed/summary.json)

### Repeatable d100 test with 100 web-sourced topics

Prepare a fresh batch, then run all 25 scripted users against the frozen
Combined MPLPB revision. Each of five sets assigns five roles and gives each
user four different topics in a separate native ledger.

```sh
OUT=/tmp/mplpb-d100-batch
python -m research_lab.sorter_random_batches prepare --out "$OUT"
python -m research_lab.sorter_random_batches run --out "$OUT" --mplpb-root ../combined
```

Omitting `--seed` draws a new seed. Pass the recorded seed to `prepare` with
a new output directory to reconstruct the same packets and dice rolls.
`--revision` on `prepare` pins a different Combined commit before generation.
The runner records d100 rolls for topic selection, role assignment, case and
actor order, file types, layouts, profiles, and exploration budgets.

The frozen [web topic catalog](fixtures/sorter_web_topics.json) retains names
and URLs selected from [Wikipedia’s Level 3 topic index](https://en.wikipedia.org/wiki/Wikipedia:Vital_articles/Level/3?oldid=1386325940).
The topics name fictional exercises. Wiki pages supply topic metadata, and the
exercise’s designated originals supply its evidence. Sampling draws across
11 sections and filters titles to the finite test grammar. Each user runs one
supported case, one competing-owner case, one processed-only case and one
insufficient-original case in randomized order.

Use `packets/` as the test input. Keep `operator-key.json` with the evaluator.
MPLPB receives the packet sources and question. The runner compares its
outputs with the expected results and retains source maps and command receipts.
This exercises new randomized inputs under controlled synthetic conditions.
An outside custodian and independent reviewers are still needed to evaluate
historical reconstruction on unseen original records.
[100-case results](evaluation/mplpb-updates/bbf6690d69b32d16969cc10e5ce9d380427ead40/d100/summary.json) ·
[Recorded d100 rolls](evaluation/mplpb-updates/bbf6690d69b32d16969cc10e5ce9d380427ead40/d100/d100-rolls.json)

A November 19 follow-up ran **five fresh d100 seeds** against the same
Combined pin. **500/500 cases and 500 workspace replays passed** across
125 separately built ledgers. The run retains each seed, frozen packet
and dice hashes, per-case outcomes, and replay receipt digests.
[Seeds, evidence, and five-batch rerun commands](evaluation/mplpb-updates/bbf6690d69b32d16969cc10e5ce9d380427ead40/d100-repeat-2026-11-19/RESULTS.md)

### Ben’s criticism and my response in code

| What Ben measured or asked for | What I implemented | What the evidence establishes |
|---|---|---|
| **P0 · Make refusals and retrieval gaps legible.** The existing contract already separated several answer states, but a user needed to distinguish unsupported grammar, absent eligible evidence, conflict, insufficient support and budget exhaustion. | Added more specific native diagnostic categories and bounded investigation stop reasons. [#43][mplpb-pr43] · [#46][mplpb-pr46] | Public controls exercise those failure categories. Cross-adapter consistency and whether the labels improve operators’ decisions still need measurement. |
| **P1 · Improve access to the right original passages.** Exact phrases reached the expected source in the top five on **31/49** queries, even though rich communication headers ranked it first on **40/42**. Analyst notes could displace originals at rank one. | Exact ID/hash and body-field routing, conflict retention, source-layer inspection, gated prose search and mapping back to original spans. [#43][mplpb-pr43] · [#44][mplpb-pr44] · [#46][mplpb-pr46] | Zero/one/multiple-match and contradiction controls pass. The prose recovery run located **18/23** reference spans on a different development set. Ben’s 515-page comparison still needs the authorized originals or a matched replacement. [Prose recovery report][mplpb-prose] |
| **P1 · Separate appearances from communication identity.** One message can appear in several places, equal subjects can refer to distinct messages, and matching headers can accompany conflicting bodies. | Separate source occurrences and event candidates, explicit identifier namespaces, body-variant review, and sorter scope checks for quoted or forwarded headers. [#41][mplpb-pr41] · [#43][mplpb-pr43] · [#50][mplpb-pr50] | Public controls and the repaired sorter probe demonstrate these distinctions on the tested inputs. Unseen event-identity precision and recall remain open. |
| **P2 · Keep partial corrections and time provenance.** A later correction can change one claim while earlier text remains historically relevant. | Exact-span scoped corrections preserve predecessor text and unaffected fields. Field/time windows and read-only as-of views retain historical inspection without authorizing current work on retired sources. [#41][mplpb-pr41] · [#43][mplpb-pr43] | Public controls cover partial corrections, ambiguous spans, stale bases and scoped history. Uncertain dates and real partial retractions need independent scoring. |
| **P2 · Reconstruct justified relationships from originals.** The old strict grammar abstained on **57** event-question forms. A supplied graph or plausible bridge leaves historical reconstruction unmeasured. | Opt-in source-quoted relation exploration stops at missing bridges. Separate documentary proofs check particular source assertions, wording comparisons and recorded arrangements with citations, qualifications and missing obligations. [#41][mplpb-pr41] · [#43][mplpb-pr43] · [#45][mplpb-pr45] · [#46][mplpb-pr46] | On **22 unchanged development questions**, native complete source support moved **0 → 1 → 2** across the reported reconstruction stages. The latest fresh-context AI assessment rated **2 complete correct, 4 correct refusals and 16 errors or over-refusals**. Independent human scoring and general historical reconstruction remain open. [Solo evaluation][mplpb-solo] |
| **Appendix A · Preserve authority and distinguish operational receipts.** A stored, sent or narrated claim supplies no proof of delivery, acknowledgment or completion. | Recheck source bodies before downstream work, keep storage and host receipt types distinct, and require strict proof before optional narration. [#40][mplpb-pr40] · [#43][mplpb-pr43] · [#46][mplpb-pr46] · [#51][mplpb-pr51] | At the old pin a contradictory component-status claim and a claim-only chain both reached the executor. The repaired pin blocked both and still ran the direct-source positive control. Independent external delivery, READ/ACK and completion trials remain open. [Paired native probes](docs/MPLPB_NATIVE_COMPARISON.md#seven-paired-boundary-probes) |
| **P3 · Measure scale, missed evidence and review effort.** Compare budgets, coverage, false bridges, compute and human labor. | Added source/hop/discovery limits, explicit stop reasons, bounded immutable parsing reuse, workload metrics and optional operator time. The study harness preserves pinned inputs, receipts and reviewer disagreements. [#41][mplpb-pr41] · [#42][mplpb-pr42] · [#43][mplpb-pr43] · [#46][mplpb-pr46] | A matched solo replay recorded lower worker CPU on that workload. Repeated scaling on matched corpora and actual human review and correction times remain open. [Solo evaluation][mplpb-solo] |

The [same 52 public software controls][mplpb-public-baseline] recorded **10 passes
and 42 capability gaps** at Ben’s pin and **52/52** at the fixed PR41 implementation.
The gaps describe missing or unimplemented capabilities in that developer suite.
At the subsequent narrator implementation freeze, the [upstream report][mplpb-narrator-report]
records **1,219 native tests** and **52/52 public controls** passing. These
measurements cover software behavior. The 22-question study measures a separate,
much narrower reconstruction result. [Full acceptance matrix](docs/RESPONSE_TO_BEYOND_GUARDED_RETRIEVAL.md#requirement-by-requirement-map)

### What would narrow the remaining criticism

1. **Replay Ben’s released synthetic benchmark on both pins.** Obtain and
   hash-check his named public companion archive. Run its original probes at
   `257e54a` and `6350988` using the same corpus, questions and machine budgets.
   Report source-location recall, refusals, occurrence/body collisions, scoped
   corrections and false bridges. Record missing interfaces and any harness
   adaptation explicitly. [Companion archive and replay limits](docs/GELHAUS_EXTERNAL_EVALUATION.md#what-is-public-and-what-remains-reproducible-only-in-part)
2. **Run a blinded historical evaluation on unseen originals.** An outside
   custodian freezes the source bytes and hidden questions. Two independent
   reviewers score exact citations, distinct events, corrections, qualifying
   language, justified relationships and appropriate refusals against a
   predeclared rubric. Compare the old strict reader, current strict reader,
   and current reader with sorter-assisted discovery under matched budgets.
   In the sorter arm, reviewers use candidate links to locate originals and
   the reader checks the originals under the same authority rules. Keep labels
   and expected links out of the input corpus. [Existing study protocol][mplpb-study]
3. **Measure whether the sorter saves reviewers work.** Compare manual review
   with sorter-assisted review on the same task types. Time source location,
   adjudication and re-entry after an interruption. Report missed originals,
   false identity groups and bridges, reviewer disagreement, bytes read,
   CPU and memory. Preserve corpus sizes, repeated-run variation and regressions
   after withdrawal or correction. [Current sorter limits][mplpb-sorter-guide]

[mplpb-ben-pin]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/tree/257e54a51edac272eb6b2441457f38a40485ee4d
[mplpb-now-pin]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/tree/bbf6690d69b32d16969cc10e5ce9d380427ead40
[mplpb-pin-diff]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/compare/257e54a51edac272eb6b2441457f38a40485ee4d...bbf6690d69b32d16969cc10e5ce9d380427ead40
[mplpb-pr40]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/40
[mplpb-pr41]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/41
[mplpb-pr42]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/42
[mplpb-pr43]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/43
[mplpb-pr44]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/44
[mplpb-pr45]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/45
[mplpb-pr46]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/46
[mplpb-pr47]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/47
[mplpb-pr48]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/48
[mplpb-pr49]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/49
[mplpb-pr50]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/50
[mplpb-pr51]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/51
[mplpb-pr52]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/pull/52
[mplpb-work-support]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/mplpb_work/source_support.py
[mplpb-investigation]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/mplpb_work/investigation.py
[mplpb-study]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/docs/ORIGINAL_RECORD_STUDY.md
[mplpb-scoped]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/docs/SCOPED_EVIDENCE_EXTENSIONS.md
[mplpb-prose]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/ff386a6f22b00d703d91665d5efc4ab284a34bf5/evaluation/unprepared-originals/2026-11-16-recovery/REPORT.md
[mplpb-doc-verify]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/mplpb_answers/documentary_verify.py
[mplpb-reconstruction]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/docs/HISTORICAL_RECONSTRUCTION_ENGINE.md
[mplpb-sorter-code]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/mplpb_work/sorter.py
[mplpb-package]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/docs/PACKAGE_GUIDE.md
[mplpb-header-report]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/evaluation/preprocessing-sorter/2026-11-17-header-scope/REPORT.md
[mplpb-narrator]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/mplpb_answers/local_narrator.py
[mplpb-sorter-guide]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/docs/PREPROCESSING_SORTER.md
[mplpb-solo]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/evaluation/solo-milestone/2026-11-17/RESULTS.md
[mplpb-public-baseline]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/4fe099ca14175399f58369efcc39153c203a5677/evaluation/historical-experts/final-comparison.json
[mplpb-narrator-report]: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/evaluation/general-reader/2026-11-17-local-narrator/REPORT.md

## Latest B-Tests native rerun — 18 November 2026, PR52

At `bbf6690`, **1,267 native tests**, seven additional native checks, all
seven work-boundary probes, the clean installed-wheel check, and **52 public
evidence controls** passed. All 22 historical outcomes, exact citations, and
missing-information lists matched the baseline. Five source-linked workspace
replays reproduced 39 processed passages, 15 exact-match candidates, and
49 wording-review candidates.

B-Tests also ran **five mixed-dump users** and **100 d100 cases across
25 separately built ledgers**. Each scripted d100 case matched its expected
ownership and support decision. The report links the previous attempts,
all final source maps, workspace results, and replay checks.
[PR52 run evidence](evaluation/mplpb-updates/bbf6690d69b32d16969cc10e5ce9d380427ead40/RESULTS.md)

## Earlier B-Tests native rerun — 17 November 2026, PR49

Current Combined pin **ccbb5804eb47f78c2338d57c142ad087b47be710** passed
**1,186 native tests**, seven additional checks, seven B-Tests boundary probes,
ten applicable legacy query contracts and52 public-evidence controls. The sorter
kept176 identical nodes across modes, added77 review edges and exported a snapshot
that the unchanged pre-sorter reader withheld under all three profiles.

[Requirement-by-requirement response to Ben](docs/RESPONSE_TO_BEYOND_GUARDED_RETRIEVAL.md)
marks already-present, partial, newly added and still-open portions separately from
software PASS and independent acceptance. [Exact fresh results and commands](evaluation/mplpb-updates/ccbb5804eb47f78c2338d57c142ad087b47be710/RESULTS.md)
include reproductions of both November 11 experiments. Combined later merged the
optional strict-first narrator in PR51. Its separate upstream report records
1,219 native tests at the frozen implementation revision. [Upstream validation](https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/6350988a2f64d8e5fa53bd187d368f4397bf4f4c/evaluation/general-reader/2026-11-17-local-narrator/REPORT.md)

**Substantial implementation coverage is demonstrated; independent historical
accuracy and general reconstruction remain unestablished.** Inspection, graph
packaging and human promotion do not establish source support or historical truth.
Only B-Tests was edited. No new OOCC/CAD sessions or private controller trials ran.

[Sorter paper and response paper: MD/TXT/PDF](docs/papers/README.md) ·
[Ben's original paper](https://www.academia.edu/181013727/Beyond_Guarded_Retrieval_A_Source_Bounded_Evaluation_of_Combined_MPLPB_and_a_Roadmap_for_Historical_Reconstruction)

## Earlier PR46 rerun — 17 November 2026

Updated main [`3df2c6e22f0ef454f3ee67b88d43402a42f63443`](https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/tree/3df2c6e22f0ef454f3ee67b88d43402a42f63443)
passed **1,157 native tests**, seven additional checks, seven work-boundary probes,
ten applicable legacy source-query contracts and the 52-case public-evidence
suite. The 12 public-paper reader outputs are unchanged from PR #43.

Component suites passed with their required environment permissions. Initial
Networked/Image socket-setup failures and unchanged-code successful retries are
both retained. No MPLPB source files were changed and no new OOCC/CAD model
sessions were run.

[Versioned report, logs, exact commands and limitations](evaluation/mplpb-updates/3df2c6e22f0ef454f3ee67b88d43402a42f63443/RESULTS.md).
The earlier results below retain their original versions and dates.

## Earlier native MPLPB results — 16 November 2026

The full unmodified MPLPB checkout at
[`cc21ce300b5ec228c07fc77a149804fba6c89792`](https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/tree/cc21ce300b5ec228c07fc77a149804fba6c89792)
passed **887 Python tests and seven additional native checks**. Bundled components
also passed: **Swarm 145, Networked 61, Smart Local 52 and Image 93**, plus
adoption checks. The component checker repeated the Combined 887; that repeat is
not additional coverage. No target code was modified.

Seven paired native probes used the current version and the older
`257e54a51edac272eb6b2441457f38a40485ee4d` pin identified by Ben. The older version
allowed a contradictory claim and claim-only chain to invoke a real local executor;
the current version blocked both. Current results: **7 PASS**. Historical results:
**5 PASS, 2 FAIL against these probe criteria**. Valid controls really executed;
blocked cases were checked through effect files and separate database readback.
These are not reproductions of Ben's unavailable private benchmarks.

[Native results, blockers and exact rerun commands](docs/MPLPB_NATIVE_COMPARISON.md) ·
[Raw logs and hashes](evaluation/mplpb-native) ·
[Dated ecosystem and all repository links](docs/MPLPB_CHRONOLOGY.md)

An initial restricted-environment run failed because localhost sockets were denied;
its logs remain. The unchanged full suite passed after that environment restriction
was removed. A finite source checker is not a general factual truth guarantee.
Native authored-suite counts are not comparable performance scores against AI
session counts.

## Current benchmark — 16 November 2026

The first frozen condition contains **64 synthetic records, ten projects, 5,120
planning-relation appearances and 119 questions**. Two real fresh AI sessions
received matched original evidence: published CAD instructions versus strong
ordinary source governance. It includes false approved maps, copied evidence,
numeric acceptance thresholds, limited corrections, revoked grants, failed work,
misleading causal bridges and stale completion receipts. Positive controls require
supported successes and one permissible local release.

| Observed criterion | CAD instructions | Conventional governance |
|---|---:|---:|
| Correct values on requested questions | 119/119 | 119/119 |
| Appropriate local action selection | PASS: P7 only | PASS: P7 only |
| Handoff at most 900 characters | PASS: 881 | PASS: 900 |
| Extra unrequested question | FAIL: added Q120 | None |
| Frozen source-ID-set matches | 108/119 | 109/119 |
| Original overall score | FAIL | FAIL |

The source-set score is overstrict: histories directly state that old callbacks
do not verify current tasks, but the key also requires a policy ID. CAD also cites
the current revocation without the former grant. Those original scores are retained;
they are **not eleven and ten false factual answers**. All cited quotes match supplied
originals. Semantic interpretation of equivalent source routes is an unblinded
review, not independent adjudication.

The central false-approved-interpretation failure was **not observed** in this
condition. Neither OOCC/CAD superiority nor equivalence to conventional governance
is established by one matched pair. A larger generated corpus can still contain
simple templates. Matching dimensions Ben reports does not establish equal
measurement difficulty without his private fixtures and scoring records.

[Benchmark protocol and repeat instructions](docs/CRITICAL_BENCHMARK.md) ·
[Current results and blockers](docs/CRITICAL_BENCHMARK_RESULTS.md) ·
[Retained inputs, answers, key and hashes](evaluation/critical-bench-1) ·
[Claim matrix](docs/OOCC_CORRECTION_EVALUATION.md)

## Unflagged archive discovery

A further [four-session discovery test](docs/UNFLAGGED_DISCOVERY.md) gave no warning that an approved map was wrong. Both treatments searched the archive, found the current original, contested the wrong claim and selected no release; both also selected release on the valid control. A separate filesystem monitor observed current-original access in all four sessions. CAD had one literal action-string mismatch, with the correct decision by meaning.

This discovery condition did not test a false original without contrary evidence. The later [archival propagation](docs/ARCHIVED_PROPAGATION.md) and [single-project human export](docs/SINGLE_PROJECT_HUMAN_EXPORT.md) conditions address bounded parts of that concern, with results below.

## False originals and a single-project human export

The [three-stage propagation run](docs/ARCHIVED_PROPAGATION.md) used one false
original, no contrary observation, 10/100/1,000 promoted descendants and fresh
sessions. Both treatments retained one evidence root, rejected unsupported
expansion and causal edges, and acknowledged unverified outside-world status.
Both continued requesting local P0 release from the wrong inherited report.
The conventional final handoff exceeded 400 characters at 410; CAD used 384.
This tests bounded propagation, not detection of an unobservable truth.

The [single-project human-export pair](docs/SINGLE_PROJECT_HUMAN_EXPORT.md) removed
the original and lineage entirely. Both treated the export as inherited and marked
generation unknown. **CAD deferred release pending validation evidence; the
conventional session requested release relying on the export.** That is an observed
difference in one pair, not a general superiority finding or native enforced block.
The task explicitly requested evidence classification. No real release occurred.

The **30 prompt-treatment target sessions across five conditions** include dependent
handoff stages. These are authored development experiments, not thirty independent
projects, independent validation or proof against all inherited-error reinforcement.

## Paper and public-work comparison

**The Witness Inside the Machine**, by Mitchell D. McPhetridge, is revised around
the live self-assessments, the outside judge, and the 140-case planted benchmark.
The outside judge detected 22 of 22 failures in the retained live runs and
accepted both correct refusals. The model-judge replay left the causal effect
of evaluator separation open.
[Markdown](docs/paper/THE_WITNESS_INSIDE_THE_MACHINE_REVISED.md) ·
[PDF](docs/paper/THE_WITNESS_INSIDE_THE_MACHINE_REVISED.pdf) ·
[Earlier results and replay commands](evaluation/witness-section19/RESULTS.md) ·
[Live evaluator-independence replication](evaluation/witness-section19/live/README.md) ·
[November 22 research archive](evaluation/witness-section19/research-archive/README.md) ·
[Download the November 22 experiment package](evaluation/witness-section19/research-archive/witness-research-package-2026-11-22.zip)

**Probabilistic Prompts and MPLPB Deterministic Contracts**, by Mitchell D.
McPhetridge, 18 November 2026, uses the 8 a.m. light switch to explain
how B-Tests measures instruction following and independently verifies
permitted and withheld effects.
[Markdown](docs/paper/PROBABILISTIC_PROMPTS_AND_MPLPB_CONTRACTS.md) ·
[TXT](docs/paper/PROBABILISTIC_PROMPTS_AND_MPLPB_CONTRACTS.txt) ·
[PDF](docs/paper/PROBABILISTIC_PROMPTS_AND_MPLPB_CONTRACTS.pdf)

**MPLPB Mixed Dump**, by Mitchell D. McPhetridge, 18 November 2026, documents
the development from the early B-Tests runs through candidate review, reader-owned
passage admission, and 100 reproducible mixed-dump cases.
[Markdown](docs/paper/MPLPB_MIXED_DUMP.md) · [TXT](docs/paper/MPLPB_MIXED_DUMP.txt) ·
[PDF](docs/paper/MPLPB_MIXED_DUMP.pdf)

**MPLPB and OOCC/CAD: Comparative Experiments**, by Mitchell D. McPhetridge, research draft
16 November 2026: [Markdown](docs/paper/WHEN_THE_MAP_BECOMES_THE_AUTHORITY.md) ·
[TXT](docs/paper/WHEN_THE_MAP_BECOMES_THE_AUTHORITY.txt) ·
[PDF](docs/paper/WHEN_THE_MAP_BECOMES_THE_AUTHORITY.pdf).
The [build instructions](docs/paper/BUILD.md) regenerate TXT/PDF from Markdown.

The paper reports the observed seams, including results favorable to CAD, and
addresses the supplied *Beyond Guarded Retrieval* excerpt against the
[focused current MPLPB source review](docs/MPLPB_PUBLIC_SOURCE_REVIEW.md).
The initial 48-file source review was followed by complete-checkout native
execution. Neither is an exhaustive semantic audit. Enforced finite contracts and successful instruction following remain
separate evidence levels.

## Repeat with any AI

An operator prepares a new local study, then gives each fresh AI only its own
assigned packet directory. Keep outcome keys, other treatments and repository
results away from the target. Follow the packet’s `ENTRY.txt`, retain the complete
conversation and save the untouched JSON answer.

```sh
python -m research_lab.critical_bench prepare \
  --root evaluation/blind-private-runs/my-study \
  --seed 20261116 --pages 64 --relations 5120

python -m research_lab.critical_bench submit \
  --root evaluation/blind-private-runs/my-study --packet ASSIGNED_PACKET_ID \
  --response answer.json --transcript original-transcript.txt
```

Use a new directory for every condition. `--pages 515` and
`--relations 100`, `1000` or `10000` prepare separate scale conditions; **they have
not yet received model executions here**. Same-seed replay is a public development
test, not an untouched holdout. Public links cannot prove a fresh session or enforce
isolation. Record truncation, unavailable sources and interventions explicitly.

## Verify retained results and the harness

```sh
python -m unittest discover -s tests -v
python -m research_lab.critical_bench replay
python -m research_lab.agent_replay
python -m research_lab.discovery_bench replay --root evaluation/discovery-1
python -m research_lab.propagation_bench replay --root evaluation/propagation-1
python -m research_lab.human_export_bench replay --root evaluation/human-export-1
python -m research_lab.native_evidence
```

The local suite passes **123 tests**. Public evidence is retained as inspectable UTF-8 JSON and JSONL. Replay verifies
original input hashes; optional lossless gzip input remains supported. Replay recomputes retained scores and file
transfers; it makes **zero new model requests**. Unit-test passes are not target
passes. Submitted local state/effects are saved before evaluation, without a hidden
truth guard rewriting the model’s choices. A selected local release is not a
verified external operation.

## Retained earlier work and remaining limits

The earlier 16-session run is retained as a
[historical simplified instruction check](docs/HISTORICAL_SIMPLIFIED_CHECK.md).
Its two- or three-source fixtures and repeatedly supplied originals were too
simple to establish independent or live-system validation. Both arms corrected
false approved claims and respected revocation; each exceeded one final compression
limit. The original strict scores and their defects remain available.

Earlier HTTP experiments returned no usable model completion and retain their
`NOT_RUN` classifications in the [execution history](docs/OOCC_CORRECTION_RESULTS.md).
The native kill-condition runner remains **38 NOT_RUN** because Ben’s live adapter
and independent readbacks are unavailable. Missing access is not an architectural
failure. Functional Layers forecasting, human learning, summary-only recovery,
long handoff chains and native enforcement remain unresolved. The
[existing compression/handoff protocol](docs/BLIND_HANDOFF_EXPERIMENT.md) and API
runners remain available; unavailable transport must not be reported as a model
answer.

The benchmark applies source pins, negative controls, per-case evidence and explicit
limits drawn from [MPLPB’s evaluation methods](https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/blob/main/evaluation/README.md).
Updated MPLPB findings concern the pinned native suites and seven authored probes;
they do not establish a general accuracy or workflow advantage. Private correspondence, original supplied
PDFs and unused private outcomes are excluded from publication. Exhaustive reading
and claim extraction across every supplied book is not claimed.
