Message-ID: NOTE-30047-NEXT
Subject: Depot notice

The porter said this corrects NOTE-30047: nine crates.
