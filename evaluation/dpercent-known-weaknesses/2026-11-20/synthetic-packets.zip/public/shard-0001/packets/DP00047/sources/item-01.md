Message-ID: NOTE-30047
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
