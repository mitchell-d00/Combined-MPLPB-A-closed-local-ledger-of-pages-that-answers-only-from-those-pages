Message-ID: NOTE-30124
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
