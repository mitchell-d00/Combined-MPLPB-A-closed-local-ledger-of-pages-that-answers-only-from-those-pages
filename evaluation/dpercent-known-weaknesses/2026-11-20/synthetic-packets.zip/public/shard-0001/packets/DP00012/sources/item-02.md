Message-ID: NOTE-30012-NEXT
Subject: Depot notice

This notice corrects NOTE-30012: nine crates.
