# Archival transcript

Written January 31, 1842.

In my letter of January 28, 1842, the count should read
fourteen crates. The destination remains the east depot.
