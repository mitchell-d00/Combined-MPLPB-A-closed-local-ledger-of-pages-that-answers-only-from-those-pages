# Archival transcript

Written January 28, 1842.

This letter was written on January 28, 1842. The
consignment contains twelve crates for the east depot.
