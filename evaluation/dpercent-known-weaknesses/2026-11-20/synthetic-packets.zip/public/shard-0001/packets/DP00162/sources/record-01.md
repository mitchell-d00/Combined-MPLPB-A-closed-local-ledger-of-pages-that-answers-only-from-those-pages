Subject: Archive notice
Documentation example, not an independent record.
```text
Record-ID: ARCH-10162
Dispatch Date: 1848-03-02
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Entry copied by Edda Marén.
```
