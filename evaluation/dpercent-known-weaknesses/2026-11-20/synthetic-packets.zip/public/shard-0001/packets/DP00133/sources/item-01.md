Message-ID: NOTE-30133
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
