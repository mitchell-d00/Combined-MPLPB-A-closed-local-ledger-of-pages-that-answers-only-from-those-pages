Message-ID: NOTE-30027
Subject: Depot notice

Twelve crates arrived. Émile read the entry.

Message-ID: NOTE-30027-NEXT
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
