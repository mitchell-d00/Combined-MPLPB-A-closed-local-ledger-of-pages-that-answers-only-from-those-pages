# Archival transcript

Written January 04, 1843.

Mina Cole wrote the canal register.
