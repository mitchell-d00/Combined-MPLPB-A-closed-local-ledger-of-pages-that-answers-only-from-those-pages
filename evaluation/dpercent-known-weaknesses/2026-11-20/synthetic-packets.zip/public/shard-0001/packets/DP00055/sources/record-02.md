# Archival transcript

Written January 04, 1843.

Noel Ash wrote the canal register.
