Message-ID: NOTE-30178-NEXT
Subject: Depot notice

NOTE-30178 is hereby corrected by this notice: nine crates.
