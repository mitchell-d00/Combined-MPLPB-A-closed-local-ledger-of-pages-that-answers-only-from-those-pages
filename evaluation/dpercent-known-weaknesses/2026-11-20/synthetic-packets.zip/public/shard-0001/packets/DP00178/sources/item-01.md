Message-ID: NOTE-30178
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
