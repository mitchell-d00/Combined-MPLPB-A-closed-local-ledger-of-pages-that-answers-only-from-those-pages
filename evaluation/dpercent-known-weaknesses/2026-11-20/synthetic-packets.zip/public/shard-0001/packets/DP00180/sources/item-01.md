Message-ID: NOTE-30180
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
