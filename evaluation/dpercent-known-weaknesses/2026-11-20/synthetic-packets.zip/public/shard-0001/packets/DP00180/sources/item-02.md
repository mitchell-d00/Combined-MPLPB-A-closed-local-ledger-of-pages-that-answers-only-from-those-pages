Message-ID: NOTE-30180-NEXT
Subject: Depot notice

This notice does not correct NOTE-30180.
