Message-ID: NOTE-30126
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
