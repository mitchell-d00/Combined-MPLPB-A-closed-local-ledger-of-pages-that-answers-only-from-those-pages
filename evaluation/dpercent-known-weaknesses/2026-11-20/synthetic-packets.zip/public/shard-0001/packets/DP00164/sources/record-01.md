May Reed asked Tess Rowan to send the harbor report.
