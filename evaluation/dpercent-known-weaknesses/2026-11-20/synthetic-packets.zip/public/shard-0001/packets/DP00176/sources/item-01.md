Message-ID: NOTE-30176
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
