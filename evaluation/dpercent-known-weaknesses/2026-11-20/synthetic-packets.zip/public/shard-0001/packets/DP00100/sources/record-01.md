# Register

Documentation example, not an independent record.
```text
Record-ID: ARCH-10100
Custody Location: East vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Résumé — 東京.
```
