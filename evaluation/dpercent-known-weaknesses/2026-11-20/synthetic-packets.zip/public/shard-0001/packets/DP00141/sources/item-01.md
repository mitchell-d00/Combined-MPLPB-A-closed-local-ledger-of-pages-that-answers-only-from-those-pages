Message-ID: NOTE-30141
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
