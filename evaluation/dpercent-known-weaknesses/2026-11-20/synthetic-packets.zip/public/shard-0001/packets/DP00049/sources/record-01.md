Subject: Archive notice
Documentation example, not an independent record.
> Record-ID: ARCH-10049
> Custody Location: East vault
> Other Label: untouched
> Subject: Archive notice
> 
> Clerk wrote this entry. Entry copied by Edda Marén.
