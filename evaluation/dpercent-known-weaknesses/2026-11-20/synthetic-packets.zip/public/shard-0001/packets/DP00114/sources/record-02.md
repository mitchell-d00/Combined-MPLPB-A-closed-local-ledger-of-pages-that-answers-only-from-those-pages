Record-ID: ARCH-10114-OTHER
Dispatch Date: 1848-03-05
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Résumé — 東京.
