Message-ID: NOTE-30147
Subject: Depot notice

Nine crates arrived. Clerk copied this entry.
