Message-ID: NOTE-30147
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
