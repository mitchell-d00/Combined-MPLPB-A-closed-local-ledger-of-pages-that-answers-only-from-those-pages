Record-ID: ARCH-10021
Dispatch Date: 1848-03-02
Other Label: untouched
Subject: Archive notice

Different documentary body: amendment to an unrelated claim. Different documentary body: amendment to an unrelated claim.
