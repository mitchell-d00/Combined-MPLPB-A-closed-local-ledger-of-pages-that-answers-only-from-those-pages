Message-ID: NOTE-30145-NEXT
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
