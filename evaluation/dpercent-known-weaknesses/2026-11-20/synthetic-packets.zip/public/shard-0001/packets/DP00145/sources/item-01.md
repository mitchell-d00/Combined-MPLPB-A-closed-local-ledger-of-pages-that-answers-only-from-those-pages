Message-ID: NOTE-30145
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
