Record-ID: ARCH-10154 Custody Location: East vault Other Label: untouched Subject: Archive notice  Clerk wrote this entry. Entry copied by Edda Marén.
