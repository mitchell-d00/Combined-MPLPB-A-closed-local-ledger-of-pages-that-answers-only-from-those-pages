Message-ID: NOTE-30135-NEXT
Subject: Depot notice

This notice corrects LOST-900: nine crates.
