From: Mira Vale
To: Mina Cole
Date written: January 14, 1842
Subject: Archive notice
Message-ID: MAIL-10040

This record was written on
January 14, 1842. I recorded an
idea about the museum
catalogue.
