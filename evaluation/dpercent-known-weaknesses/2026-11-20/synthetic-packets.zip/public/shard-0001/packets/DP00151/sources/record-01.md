Record-ID: ARCH-10151
Custody Location: East vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Clerk wrote this entry.
