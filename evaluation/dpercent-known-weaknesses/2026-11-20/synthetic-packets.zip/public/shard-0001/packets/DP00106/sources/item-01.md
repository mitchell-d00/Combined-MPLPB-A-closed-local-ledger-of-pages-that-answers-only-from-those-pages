Message-ID: NOTE-30106
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
