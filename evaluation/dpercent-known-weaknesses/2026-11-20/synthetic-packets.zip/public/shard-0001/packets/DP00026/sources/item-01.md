Message-ID: NOTE-30026
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
