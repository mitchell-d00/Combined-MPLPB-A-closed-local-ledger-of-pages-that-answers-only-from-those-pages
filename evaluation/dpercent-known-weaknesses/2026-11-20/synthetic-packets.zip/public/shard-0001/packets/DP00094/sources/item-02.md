Message-ID: NOTE-30094-NEXT
Subject: Depot notice

This notice corrects NOTE-30094: nine crates.
