Message-ID: NOTE-30094
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
