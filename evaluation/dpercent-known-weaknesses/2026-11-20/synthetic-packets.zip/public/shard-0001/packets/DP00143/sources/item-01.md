Message-ID: NOTE-30143
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
