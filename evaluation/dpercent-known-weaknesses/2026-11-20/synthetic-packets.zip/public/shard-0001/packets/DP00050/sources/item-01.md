Record-ID: NOTE-30050
Local Time: 14:20

Zoë copied the note — 東京.
