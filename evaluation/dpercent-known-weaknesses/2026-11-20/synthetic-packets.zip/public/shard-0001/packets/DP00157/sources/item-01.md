Message-ID: NOTE-30157
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
