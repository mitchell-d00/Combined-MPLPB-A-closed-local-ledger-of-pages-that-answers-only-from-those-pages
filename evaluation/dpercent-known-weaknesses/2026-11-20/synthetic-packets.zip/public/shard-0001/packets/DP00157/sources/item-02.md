Message-ID: NOTE-30157-NEXT
Subject: Depot notice

If approved, this notice corrects NOTE-30157: nine crates.
