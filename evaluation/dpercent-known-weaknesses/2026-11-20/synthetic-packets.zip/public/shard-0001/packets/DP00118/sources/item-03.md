# Documentation
Example only; not another communication.
```text
Message-ID: NOTE-30118
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
```
