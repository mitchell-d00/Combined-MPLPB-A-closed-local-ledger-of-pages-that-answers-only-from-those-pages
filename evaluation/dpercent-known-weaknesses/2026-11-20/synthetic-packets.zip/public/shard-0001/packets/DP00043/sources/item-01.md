Message-ID: NOTE-30043
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
