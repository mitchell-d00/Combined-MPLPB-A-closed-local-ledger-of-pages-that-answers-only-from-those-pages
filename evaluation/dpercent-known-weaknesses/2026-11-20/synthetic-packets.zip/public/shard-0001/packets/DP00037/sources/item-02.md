----- Forwarded message -----
Message-ID: NOTE-30037
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
