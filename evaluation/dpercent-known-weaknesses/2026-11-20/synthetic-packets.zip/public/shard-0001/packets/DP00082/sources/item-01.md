Message-ID: NOTE-30082
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
