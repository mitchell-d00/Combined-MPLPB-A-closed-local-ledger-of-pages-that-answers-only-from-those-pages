Message-ID: NOTE-30082-NEXT
Subject: Depot notice

The porter said this corrects NOTE-30082: nine crates.
