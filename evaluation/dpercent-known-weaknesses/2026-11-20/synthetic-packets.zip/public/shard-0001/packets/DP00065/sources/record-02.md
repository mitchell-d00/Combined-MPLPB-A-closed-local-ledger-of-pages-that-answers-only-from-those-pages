Record-ID: ARCH-10065
Dispatch Date: 1848-03-02
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Different documentary body: amendment to an unrelated claim.
