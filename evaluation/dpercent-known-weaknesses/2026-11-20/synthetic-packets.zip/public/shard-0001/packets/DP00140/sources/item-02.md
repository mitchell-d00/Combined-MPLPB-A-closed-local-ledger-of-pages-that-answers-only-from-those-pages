Message-ID: NOTE-30140-NEXT
Subject: Depot notice

If approved, this notice corrects NOTE-30140: nine crates.
