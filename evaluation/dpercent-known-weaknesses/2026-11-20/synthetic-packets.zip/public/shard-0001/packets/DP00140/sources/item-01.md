Message-ID: NOTE-30140
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
