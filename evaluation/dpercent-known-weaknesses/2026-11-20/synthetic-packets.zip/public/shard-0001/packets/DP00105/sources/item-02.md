Message-ID: NOTE-30105-NEXT
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
