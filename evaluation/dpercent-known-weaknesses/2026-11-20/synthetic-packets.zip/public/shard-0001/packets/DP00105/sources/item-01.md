Message-ID: NOTE-30105
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
