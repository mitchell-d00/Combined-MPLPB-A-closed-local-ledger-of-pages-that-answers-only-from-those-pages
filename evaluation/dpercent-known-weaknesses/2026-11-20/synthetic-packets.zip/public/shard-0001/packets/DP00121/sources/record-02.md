IRIS BECK TO NOEL ASH. September 29, 1846
Dear colleague,

This record was written on September 29, 1846. I recorded an idea about the copper survey report.
