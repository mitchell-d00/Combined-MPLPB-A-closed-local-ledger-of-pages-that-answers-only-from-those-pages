Message-ID: NOTE-30045-NEXT
Subject: Depot notice

This notice corrects NOTE-30045: nine crates.
