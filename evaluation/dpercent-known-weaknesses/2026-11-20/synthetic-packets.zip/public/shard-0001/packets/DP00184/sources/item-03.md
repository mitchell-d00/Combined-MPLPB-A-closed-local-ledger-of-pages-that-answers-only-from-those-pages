# Documentation
Example only; not another communication.
~~~text
Message-ID: NOTE-30184
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
~~~
