Message-ID: NOTE-30029-NEXT
Subject: Depot notice

This notice corrects LOST-900: nine crates.
