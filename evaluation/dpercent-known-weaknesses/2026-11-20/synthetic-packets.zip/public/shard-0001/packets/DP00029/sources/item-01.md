Message-ID: NOTE-30029
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
