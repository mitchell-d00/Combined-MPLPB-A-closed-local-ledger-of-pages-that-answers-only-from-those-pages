Message-ID: NOTE-30132-NEXT
Subject: Depot notice

This notice corrects NOTE-30132: nine crates.
