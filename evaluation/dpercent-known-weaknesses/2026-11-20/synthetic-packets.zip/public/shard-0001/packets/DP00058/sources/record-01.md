# Register

Documentation example, not an independent record.
```text
Record-ID: ARCH-10058
Current Status: Pending
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Résumé — 東京.
```
