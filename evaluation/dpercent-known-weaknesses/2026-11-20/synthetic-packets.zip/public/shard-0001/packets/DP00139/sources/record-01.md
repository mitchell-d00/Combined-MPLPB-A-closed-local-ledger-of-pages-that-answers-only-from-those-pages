From: Ivo Hart
To: Edda Marén
Date written: March 05, 1849
Subject: Archive notice
Message-ID: MAIL-101391

Ivo Hart described an
inspection of the east depot.
