From: Ivo Hart
To: Edda Marén
Date written: March 05, 1849
Subject: Archive notice
Message-ID: MAIL-101392

Edda Marén described an
inspection of the west depot.
