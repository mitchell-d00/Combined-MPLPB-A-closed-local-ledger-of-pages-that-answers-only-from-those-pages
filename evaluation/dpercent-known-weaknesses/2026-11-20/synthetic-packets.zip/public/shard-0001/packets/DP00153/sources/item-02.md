Message-ID: NOTE-30153-NEXT
Subject: Depot notice

This notice corrects NOTE-30153: nine crates.
