----- Forwarded message -----
Message-ID: NOTE-30179
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
