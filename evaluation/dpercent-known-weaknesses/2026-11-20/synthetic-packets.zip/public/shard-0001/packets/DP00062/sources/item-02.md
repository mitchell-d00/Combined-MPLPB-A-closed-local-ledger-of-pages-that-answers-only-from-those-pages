Message-ID: NOTE-30062-NEXT
Subject: Depot notice

This notice corrects NOTE-30062: nine crates.
