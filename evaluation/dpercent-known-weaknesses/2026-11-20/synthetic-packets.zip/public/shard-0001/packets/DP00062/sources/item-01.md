Message-ID: NOTE-30062
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
