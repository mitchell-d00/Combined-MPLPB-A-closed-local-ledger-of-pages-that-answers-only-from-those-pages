Record-ID: ARCH-10109 Custody Location: East vault Other Label: untouched Subject: Archive notice  Clerk wrote this entry. Entry copied by Edda Marén.
