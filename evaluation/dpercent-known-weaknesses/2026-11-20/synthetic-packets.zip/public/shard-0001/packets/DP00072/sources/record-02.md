MIRA VALE TO IVO HART. July 07, 1848
Dear colleague,

This record was written on July 07, 1848. I recorded an
idea about the canal register.
