MIRA VALE TO IVO HART. July 04, 1848
Dear colleague,

This record was written on July 04, 1848. I recorded an
idea about the canal register.
