Message-ID: NOTE-30142-NEXT
Subject: Depot notice

This notice corrects LOST-900: nine crates.
