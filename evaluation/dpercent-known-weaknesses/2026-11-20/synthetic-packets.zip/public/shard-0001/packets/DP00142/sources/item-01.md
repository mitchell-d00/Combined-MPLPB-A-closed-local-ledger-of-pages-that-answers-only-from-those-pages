Message-ID: NOTE-30142
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
