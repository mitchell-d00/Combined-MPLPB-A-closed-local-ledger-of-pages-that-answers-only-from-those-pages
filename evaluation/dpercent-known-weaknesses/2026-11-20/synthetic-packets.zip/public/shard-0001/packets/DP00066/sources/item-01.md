Record-ID: NOTE-30066
General Location: East vault

Zoë copied the note — 東京.
