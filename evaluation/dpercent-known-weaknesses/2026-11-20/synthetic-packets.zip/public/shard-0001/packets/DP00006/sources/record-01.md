Subject: Archive notice
Documentation example, not an independent record.
```text
Record-ID: ARCH-10006
Current Status: Pending
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Résumé — 東京.
```
