Message-ID: NOTE-30033-NEXT
Subject: Depot notice

The porter said this corrects NOTE-30033: nine crates.
