Message-ID: NOTE-30033
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
