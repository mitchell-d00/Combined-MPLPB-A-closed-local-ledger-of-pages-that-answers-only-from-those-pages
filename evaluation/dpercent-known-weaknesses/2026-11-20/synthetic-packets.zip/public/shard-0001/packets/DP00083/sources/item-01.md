Record-ID: NOTE-30083
General Location: East vault

Clerk copied this entry.
