IVO HART TO OWEN PIKE. December 22, 1841
Dear colleague,

Ivo Hart asked Owen Pike to
send the alder memorandum.
