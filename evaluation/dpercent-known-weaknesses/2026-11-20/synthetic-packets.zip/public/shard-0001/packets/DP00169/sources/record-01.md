# Archival transcript

Written October 28, 1849.

Mira Vale wrote the canal register.
