Message-ID: NOTE-30064-NEXT
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
