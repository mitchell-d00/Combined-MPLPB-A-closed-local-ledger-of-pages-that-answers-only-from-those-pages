Message-ID: NOTE-30064
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
