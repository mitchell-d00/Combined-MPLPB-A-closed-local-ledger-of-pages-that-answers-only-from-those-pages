Message-ID: NOTE-30130
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
