Message-ID: NOTE-30144
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
