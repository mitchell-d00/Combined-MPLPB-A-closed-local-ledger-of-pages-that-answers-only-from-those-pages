Message-ID: NOTE-30144-NEXT
Subject: Depot notice

This notice corrects NOTE-30144: nine crates.
