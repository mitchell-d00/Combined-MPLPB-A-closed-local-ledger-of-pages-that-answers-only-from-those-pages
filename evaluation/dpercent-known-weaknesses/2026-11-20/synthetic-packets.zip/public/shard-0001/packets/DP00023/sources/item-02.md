Message-ID: NOTE-30023-NEXT
Subject: Depot notice

This notice corrects NOTE-30023: nine crates.
