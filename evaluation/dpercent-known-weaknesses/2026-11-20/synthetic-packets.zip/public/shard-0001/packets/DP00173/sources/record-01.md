From: Edda Marén
To: Nora Wells
Date written: September 24, 1841
Subject: Archive notice
Message-ID: MAIL-10173

On September 24, 1841, Edda
Marén recorded an idea about
the harbor report.
