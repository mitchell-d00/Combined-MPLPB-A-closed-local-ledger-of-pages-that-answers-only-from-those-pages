Record-ID: ARCH-10004
Custody Location: East vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Résumé — 東京.
