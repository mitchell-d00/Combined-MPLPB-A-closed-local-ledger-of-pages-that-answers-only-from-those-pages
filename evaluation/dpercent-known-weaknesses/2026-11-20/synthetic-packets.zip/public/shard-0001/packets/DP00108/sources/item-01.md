Message-ID: NOTE-30108
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
