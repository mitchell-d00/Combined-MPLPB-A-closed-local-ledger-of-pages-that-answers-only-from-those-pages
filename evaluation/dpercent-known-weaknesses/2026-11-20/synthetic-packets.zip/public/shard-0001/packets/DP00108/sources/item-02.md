Message-ID: NOTE-30108-NEXT
Subject: Depot notice

This notice corrects NOTE-30108: nine crates.
