Message-ID: NOTE-30127
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
