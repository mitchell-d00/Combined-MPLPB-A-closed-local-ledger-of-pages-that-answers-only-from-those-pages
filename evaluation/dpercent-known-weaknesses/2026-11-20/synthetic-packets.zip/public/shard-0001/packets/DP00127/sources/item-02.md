Message-ID: NOTE-30127-NEXT
Subject: Depot notice

See NOTE-30127!
