Record-ID: ARCH-10018
Custody Location: East vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Entry copied by Edda Marén.
