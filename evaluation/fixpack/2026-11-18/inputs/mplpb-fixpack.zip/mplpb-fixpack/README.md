# MPLPB fix pack: strict first, graceful fallback, classing

For **Combined MPLPB** (`mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages`), based on commit `bbf6690` (PR #52 merge, 2026-11-18).

**Start with `CODEX_INSTRUCTIONS.md`.** It is written for Codex (or any engineer) and covers invariants, PR order, commands and when to stop.

## What it does

1. **Answers strictly when MPLPB can.** Unchanged strict pipeline; only its `supported_answer` is labelled OFFICIAL.
2. **Fails gracefully when it can't.** Says why in plain words using MPLPB's own diagnostics and gate reasons, tries supported question forms (clearly labelled as reformulations), then gives an UNOFFICIAL answer with citations, scope warnings and visible correction candidates.
3. **Helps class material so strict MPLPB can read it.** Turns a raw data dump into page drafts (literal copies, one field per paragraph, provenance), lists every judgment as a decision for a person, and builds a validated new or appended ledger.
4. **Fixes the sorter** as a separate v2 engine, leaving v1 and its frozen studies untouched.
5. **Fixes a strict-answer defect.** MPLPB certified a wrong field value when a page had a header block (see `docs/FINDINGS.md`, F1).

## Contents

| Path | What |
|---|---|
| `CODEX_INSTRUCTIONS.md` | The task: invariants, five PRs, follow-ups, commands, stop conditions |
| `patches/0001…0005` | `git am`-ready patches against `bbf6690`, one per PR |
| `code/` | The new and changed files, for reading without git |
| `docs/FINDINGS.md` | 15 findings with reproductions, plus how each PR #52 report item is handled |
| `docs/DESIGN.md` | Flow, labels, automation boundary |
| `docs/SORTER_V2.md`, `docs/ANSWER_ROUTER.md`, `docs/CLASSING.md` | Drop-in docs for the repo |
| `docs/EVALUATION_PLAN.md` | The independent evaluation that is still needed |
| `examples/` | Demo dump, scripted reviewer choices, `walkthrough.sh`, recorded review/receipt/transcript |
| `verification/` | Test runs and the full-suite log from this build |

## Quick start

```sh
git checkout -b fixpack bbf6690
git am /path/to/mplpb-fixpack/patches/*.patch
python -m unittest tests.test_sorter tests.test_sorter_v2 tests.test_classing tests.test_answer_router
bash /path/to/mplpb-fixpack/examples/walkthrough.sh
```

## What this does not claim

No accuracy, precision, recall or human-cost numbers: the tests use small fictional fixtures. Unofficial answers are lexical and extractive. Sorter v2 is still word-matching, not understanding. Mitchell's PR #52 report lists the same open problems (22-question coverage, unverified relationships, no independent evaluation); `docs/EVALUATION_PLAN.md` proposes how to measure them.
