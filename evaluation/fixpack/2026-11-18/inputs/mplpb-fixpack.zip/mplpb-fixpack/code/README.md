Readable copies of the files the patches add or change (fresh checkout of bbf6690 + patches).
`mplpb_answers/pipeline.py` and `relation_graph.py` are full files; the actual change is small (see patches/0001).
`sorter_v1_to_v2.diff` shows exactly how sorter_v2.py differs from the frozen v1 sorter.
