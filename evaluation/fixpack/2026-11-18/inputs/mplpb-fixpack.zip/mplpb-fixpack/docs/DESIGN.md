# Design: strict first, fail gracefully, class toward strict

```
                 question
                    │
                    ▼
     ┌──────── strict MPLPB (answer_query, unchanged) ────────┐
     │ supported_answer?                                       │
     │   yes ──► OFFICIAL  (answer_supported = true)           │
     │   no  ──► explain: diagnostic category + gate reasons   │
     │           + ledger catalogue (successors, withdrawn,    │
     │             stacked fields, readable fields)            │
     └─────────────────────────────────────────────────────────┘
                    │
                    ▼
     rewrites: "What is the <field> for record <ID>?"
     (fields the question names/hints; field-scoped successor
      asked for its corrected field) ── each run strictly ──►
        supported? ──► OFFICIAL FOR A REFORMULATED QUESTION
                       (both questions shown + caution)
                    │ none
                    ▼
     UNOFFICIAL answer: BM25 over eligible ledger paragraphs
     + dump statements (sorter v2), record-anchored, qualified
     passages halved, withdrawn flagged, correction candidates
     shown, optional reader(question, cited passages)
     answer_supported = false, label always shown
                    │
                    ▼
     classing help: what would make this strict-answerable
                    │
                    ▼
     classing propose ──► review.json (drafts + decisions)
          ▲                     │  person: accept/reject, choose,
          │                     │  add literal fields, ratify
          │                     ▼
     dump (pinned by     classing build ──► rehearse on copy
     sorter graph hash)      validate ──► write ledger ──► receipt
```

## Three output labels, never mixed

| Label | Source of truth | `answer_supported` |
|---|---|---|
| OFFICIAL | strict pipeline `supported_answer` on the user's question | true |
| OFFICIAL FOR A REFORMULATED QUESTION | strict `supported_answer` on a router-proposed question | true, *for that question*; caution shown |
| UNOFFICIAL | ranked passages; optional reader | false |

## Why the strict pipeline is not given hints

PR #52's sorter-first experiment fed sorter hints into the strict passage budget and lost a complete answer (H05). The router keeps the two worlds separate: strict MPLPB sees only the ledger, the fallback sees everything, and the only bridge from fallback to strict is **classing**, a human-reviewed write into the ledger through the native writer.

## Why classing produces "one field per paragraph"

The strict exact-field route (`What is the <field> for record <ID>?`) is the most general deterministic route MPLPB has, and it reads `Label: value` paragraphs. Raw sources stack fields in header blocks, which the ledger flattens into one line (F1). So the single most valuable automation is to turn every header line into its own paragraph, literally.

## Automation boundary

| Automated (literal, reversible) | Human (judgment, changes serving) |
|---|---|
| page per occurrence, ID, title, unique scope | accept / reject each draft |
| header lines → field paragraphs | add a field from body text (must quote verbatim) |
| provenance fields (file, SHA-256, bytes) | apply a correction: supersede or field-scoped, and which field |
| decisions listed with options and evidence | duplicate IDs: keep both / second supersedes / reject |
| auto-accept of clean drafts (flag) | withdraw a source marked retired |
| rehearsal, validation, receipt | declare source authorship; ratify (named person) |

Serving consequences follow MPLPB's own profiles: machine pages (depth 1) serve under `internal` and `lab`; `external` needs depth 0 (ratified) **and** declared authorship.
