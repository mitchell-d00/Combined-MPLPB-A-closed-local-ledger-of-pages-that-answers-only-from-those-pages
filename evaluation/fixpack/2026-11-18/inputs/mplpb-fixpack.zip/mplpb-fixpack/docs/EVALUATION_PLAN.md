# Evaluation plan (not run)

Nothing in this pack measures accuracy. The tests prove behaviour on small fictional fixtures. Mitchell's PR #52 report lists the same gap: precision, recall, false-link rates and human intervention costs are unknown, and independent evaluation has not run. This plan is designed to close that gap without touching the frozen corpus.

## Questions to answer

1. **Does classing raise official answers without lowering any?** Run the frozen 22 questions against (a) the existing native originals, and (b) the same originals plus a ledger built by classing from the processed documents, with every decision made by someone who has not seen the questions. Report per question: unchanged, newly official, newly official via rewrite, lost. Any loss is a release blocker.
2. **Are official-via-rewrite answers what the user meant?** For every rewrite hit, a blinded reviewer judges: same question / narrower / different. "Different" rate must be reported, and any "different" case is a bug (see invariant 7).
3. **Unofficial answer quality.** On held-out questions with known answers, measure: answer present in cited passages (recall@3), composed sentence correct, and *harmful*: the composed sentence is contradicted by a correction candidate that was shown, versus one that was missed.
4. **Sorter v2 link accuracy.** Sample 200 review edges from v1 and v2 on unseen dumps. Two annotators label each edge true/false relationship. Report precision per edge kind, plus false negatives found by annotators reading the documents. Include Mitchell's disconnected-statements control set.
5. **Human cost.** Classing receipts plus review files give: drafts, auto-accepted, decisions per 100 pages, decisions changed from recommendation, minutes per decision (time it). This is the first direct measure of "human intervention cost".

## Rules

- Questions, answer keys and annotations are frozen and hashed before any run; no generated answer key enters the corpus.
- Fictional fixtures stay in `tests/fixtures/`; authentic material is never edited.
- Report every run, including failures, with commit pins and budgets, as the repository already does.
