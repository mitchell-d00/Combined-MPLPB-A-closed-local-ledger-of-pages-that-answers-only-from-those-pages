# Findings: defects and weaknesses, with reproductions

All checked against `bbf6690` (PR #52 merge), Python 3.13, standard library only. Each item names the test that now covers it.

## Severity 1 — wrong answer certified as supported

### F1. Stacked header fields: strict MPLPB certifies a wrong value

- **Where:** `mplpb_combined/record.py::plain_to_html` + `mplpb_answers/relation_graph.py::declared_fields`.
- **What happens:** a page body with a header block (`Sender: …` / `Recipient: …` / `Cargo: …` on consecutive lines) is rendered as one `<p>` with the lines joined by spaces. Asked "What is the sender for record SHIP-7?", strict MPLPB returns `supported_answer` with cited value `Boston flour office Recipient: Albany depot Cargo: forty barrels of flour Date sent: 1850-05-12`. Asked for the cargo or recipient, it refuses (`exact_field_missing`), even though both are on the page.
- **Why it matters:** this is the one class of output MPLPB promises is safe. It reaches anyone who writes a page with `write --body` from an email, memo or form, which is exactly the data-dump use case.
- **Fix (PR 1):** refuse with `stacked_field_paragraph`; classing writes one field per paragraph so the field route works.
- **Tests:** `StackedFieldSafety` (3 tests) in `tests/test_answer_router.py`.

## Severity 2 — sorter (v1) proposes or loses links incorrectly

All stay "review only" in v1, so none is a certified wrong answer, but each misleads the person reviewing.

| ID | Input | v1 result | Test |
|---|---|---|---|
| F2 | `Correction to SHIP-7.` (also `SHIP-7:`) | target `SHIP-7.` → "missing"; real link lost, and PR #52's Candidate Relater shows **0 links** for it | `TerminalPunctuation` |
| F3 | `The porter said this note corrects SHIP-7 in full.` | **possible_correction** proposed from reported speech | `ReportedSpeech` |
| F4 | `Ref. Letter No. 41 is hereby corrected: ten bales, not twelve.` | target invented as `Letter`; statement marked as a *negated* correction because of "not twelve" | `RecognizedTargets`, `Negation` |
| F5 | `See you at the depot.` | reference with target `you` | `RecognizedTargets` |
| F6 | `SHIP-7 is superseded by this notice.` | no link (passive voice) | `PassiveDirection` |
| F7 | `Correction to SHIP-7: the barrels will be recounted.` | whole paragraph "conditional" because of "will" in a later clause; link suppressed | `ClauseScope` |
| F8 | `Correction to SHIP-7. The depot is now called "Troy Yard".` | whole paragraph "quoted" because of an unrelated quote | `ClauseScope` |
| F9 | `It is not untrue that this note corrects SHIP-7.` | treated as a plain negation | `Negation` |
| F10 | `The earlier Boston flour note had the count wrong; it should read thirty-eight.` | nothing at all | `DescriptiveReferences` |

Note on F2/F3: in my first pass F3 looked safe on v1, but only because F2 had turned the target into `SHIP-7.`. Fixing punctuation alone would have exposed F3. That is why v2 fixes them together.

## Severity 3 — coverage and usability

- **F11.** Strict MPLPB answers a fixed set of question forms (`frames.py`, `relation_graph.exact_request`, literal/practical/policy/operational/procedure/documentary grammars). Most natural questions ("Who sent SHIP-7?", "How many barrels…?") are refused as `unsupported_question_grammar` with no guidance. **Router** explains, lists the forms, and tries field rewrites.
- **F12.** External profile withholds every page whose `source-authorship` is unknown, and the user sees only `exact_field_missing`. **Router** surfaces the gate's reason.
- **F13.** After a field-scoped correction, asking the old record for the corrected field is refused with no pointer to the successor. **Router** names the successor and asks it.
- **F14.** `ledger.ratify()` mints a new document ID. Questions that name the original ID stop working after ratification, and a page already superseded for one field cannot be ratified. **Classing** ratifies at write time with `ratified_by`.
- **F15.** There is no path from a raw dump to a strict-readable ledger that keeps literalness and human decisions explicit. **Classing.**

## From Mitchell's PR #52 runtime report (2026-11-18)

Quoted status from `evaluation/candidate-review-workspace/2026-11-18-runtime/REPORT.md`, and what this pack does about each:

| Report item | This pack |
|---|---|
| 22 questions: 2 complete, 1 partial, 3 conflict, 16 abstain | Not re-scored here. Router keeps strict results unchanged and adds labelled unofficial answers; PR 7 is the honest re-run (see `EVALUATION_PLAN.md`). |
| Sorter-first hints displaced H05's evidence (2 → 1 complete) | Invariant 2: strict MPLPB never receives dump material. Tested. |
| v1 three-word overlap rule produced unwanted links | R8 uses 4-word phrases or ≥3 shared content words incl. a rare one; negative control test added. |
| 49 phrase-review suggestions are candidates, not connections | Same posture: all v2/router/classing suggestions are review-only; classing makes them explicit decisions with no default. |
| Event identity, chronology, causation unproven | Unchanged. Nothing here claims reconstruction. |
| Independent evaluation NOT RUN | Still not run. `EVALUATION_PLAN.md` proposes one; classing receipts give a first human-cost measure. |
