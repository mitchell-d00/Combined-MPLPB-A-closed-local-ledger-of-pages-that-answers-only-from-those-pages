# Answer router

Last reviewed: 2026-11-18. Proposed addition. Strict answering is unchanged; the router wraps it.

```sh
python -m mplpb_work.answer_router ask "Who sent SHIP-7?" --ledger LEDGER --dump RAW
python -m mplpb_work.answer_router ask "..." --ledger LEDGER --profile external --json
```

1. **Strict.** `mplpb_answers.pipeline.answer_query(ledger, question, profile)` with no hints. A `supported_answer` is returned as **OFFICIAL**.
2. **Explain.** The strict diagnostic category in plain words, plus facts from the ledger: the provenance gate's exclusion reasons for named records, field-scoped successors, withdrawn pages, which fields a record has and which are stacked (unreadable). The supported question forms are listed. A refusal is not evidence that the answer is absent.
3. **Rewrite.** Up to five `What is the <field> for record <ID>?` questions for fields the question names or hints at; a field-scoped successor is asked for the field it corrects. Each is run strictly. A hit is **OFFICIAL FOR A REFORMULATED QUESTION**, shown with both questions and a caution.
4. **Unofficial.** Ranked passages from eligible ledger pages and the raw dump (sorter v2), restricted to records the question names, with per-passage warnings (quoted, conditional, reported, negated, withdrawn) and correction candidates aimed at the same records. Labelled `UNOFFICIAL — not supported by MPLPB`. `answer_supported` is false.
5. **Classing help.** The next concrete step: which dump files are not in the ledger, which pages need re-classing, which decision would resolve a conflict.

`route(question, ledger, dump, profile, try_rewrites, reader)` returns the same structure as `--json`. `reader` is an optional callable `(question, passages) -> str` that may compose prose from the cited passages only; it is off by default and cannot change any support flag.

Limits: lexical ranking only; the extractive answer is one sentence or field line; rewrites cover the field route only.
