# Codex instructions: strict-first answering, graceful fallback and classing for Combined MPLPB

**Repository:** `mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages`
**Base commit:** `bbf6690` (merge of PR #52, 2026-11-18)
**This pack:** `patches/` (apply in order), `code/` (same files, readable), `examples/`, `docs/`

Read this whole file before changing anything. Then read the repository's own `AGENTS.md` and `HANDOFF.md`. **They govern how you deliver.** Where this file and `AGENTS.md` disagree about process, follow `AGENTS.md`. Where they disagree about behaviour, stop and ask.

---

## 0. Goal, in one paragraph

Make MPLPB usable on messy real data without weakening it. A question goes to **strict MPLPB first**. If strict MPLPB cannot certify an answer, the system **says why in plain words**, **tries supported question forms** (labelled as reformulations), and then gives a clearly **UNOFFICIAL** answer with citations and warnings. It then **helps the user "class" their material** (turn raw dumps into pages strict MPLPB can read), automating everything that is a literal copy and leaving every judgment to a named person. Nothing unofficial ever becomes official by being repeated, ranked or summarised.

## 1. Invariants you must not break

Treat each line as a test you must keep green. If a change would violate one, stop and report instead of working around it.

1. **`answer_supported` is true only for a strict `supported_answer`.** The router's `official` block is the only place it appears as true. Unofficial, rewritten-question caveats and classing output always say false.
2. **Strict MPLPB never sees dump material.** Do not pass sorter output, dump passages or unofficial text into `answer_query` (no `source_hints`, no extra pages). PR #52's report records that sorter hints displaced H05's required evidence (2 complete answers fell to 1). Test: `test_strict_pipeline_never_receives_dump_hints`.
3. **`mplpb_work/sorter.py` (v1) stays byte-identical.** Every v1 graph pins `sha256(sorter.py)` as `implementation_sha256`, and `verify` refuses on drift. That includes PR #52's frozen sorter-first studies. Pin at `bbf6690`: `0e8eb56604ba34f3…`. Test: `test_v1_engine_bytes_are_unchanged`. All sorter fixes go in `sorter_v2.py`.
4. **Literal only.** Classing copies field values byte-for-byte from source files. A reviewer-added field needs a `quote` that occurs verbatim in the source and contains the `value`. The build re-reads the bytes and refuses otherwise.
5. **No silent serving changes.** Supersession, field-scoped corrections, duplicate IDs and declared retirement are *decisions*. With no choice, nothing is applied. Blocking decisions stop their drafts.
6. **Machine pages stay machine pages.** Classing writes `origin=machine` (depth 1). Only a person named via `--ratify-by`, on drafts they marked `"ratify": true`, lowers depth to 0. Never default a ratifier, never use a tool name as one, and never guess `source_authorship`.
7. **A rewrite is never presented as an answer to the user's wording.** It is `official_via_rewrite`, carries the rewritten question and a caution, and may only use a field the question's own wording points at. Test: `test_rewrite_never_switches_to_an_unrelated_field` (this was a real bug: "Who sent SHIP-7?" once returned the cargo).
8. **Refusal is not absence.** Every explanation keeps `"A refusal is not evidence that the answer is absent."`
9. **Review suggestions stay review-only.** Descriptive-reference candidates and phrase overlaps never become links or default choices. PR #52's v1 workspace rule (three-word overlap) produced 164 wording links and a disconnected-statements control reproduced an unwanted link; keep the four-word/rare-term threshold and the negative control `test_disconnected_statements_get_no_candidates`.

## 2. What is in the pack

| PR | Patch | Files | What it does |
|---|---|---|---|
| 1 | `0001-strict-refuse-stacked-field-paragraphs.patch` | `mplpb_answers/relation_graph.py`, `mplpb_answers/pipeline.py` | **Safety fix.** Strict MPLPB certified a wrong value (see §3). Now refuses with `stacked_field_paragraph`. |
| 2 | `0002-sorter-v2-versioned-engine.patch` | `mplpb_work/sorter_v2.py`, `tests/test_sorter_v2.py` | New sorter engine with rules R1–R8; v1 untouched. |
| 3 | `0003-answer-router.patch` | `mplpb_work/answer_router.py` | Strict → explain → rewrite → unofficial → classing help. |
| 4 | `0004-classing-assistant.patch` | `mplpb_work/classing.py`, `tests/test_classing.py`, `tests/fixtures/classing_demo/` | Dump → review file → reviewed, validated ledger. |
| 5 | `0005-router-tests.patch` | `tests/test_answer_router.py` | Router and stacked-field regression tests. |

Apply with `git am patches/*.patch` on a branch from `bbf6690` (or the current `main` if it still contains `bbf6690`; resolve conflicts by keeping both behaviours, never by deleting a test).

**Open one PR per row, in order.** PR 1 is independent and urgent. PRs 3–5 depend on 2. Each PR must follow the `AGENTS.md` delivery steps (update `handoff/update.json` with the user's wording, run `python tools/build_handoff.py` then `--check`, follow `docs/ZIP_FIRST_RELEASE_TESTING.md`), and must report which checks actually ran.

## 3. PR 1 — strict MPLPB certified a wrong field value (fix first)

**Reproduce on `bbf6690`:**

```python
from mplpb_combined.ledger import write
from mplpb_answers.pipeline import answer_query
write('/tmp/l', doc_id='SHIP-7', title='Shipment', scope='SHIP-7 shipment', origin='human',
      body='Sender: Boston flour office\nRecipient: Albany depot\nCargo: forty barrels\n\nForty barrels left Boston.')
c = answer_query('/tmp/l', 'What is the sender for record SHIP-7?').contract
print(c['kind'], c['claims'][0]['citations'][0]['value'])
# supported_answer  Boston flour office Recipient: Albany depot Cargo: forty barrels
```

**Cause:** `mplpb_combined/record.py::plain_to_html` joins the lines of one paragraph with spaces, so an email-style header block is served as one line. `relation_graph.declared_fields` then reads `Sender:` to end of line. Any page written through the normal `write --body` path with a header block is affected.

**Fix in the patch:** `declared_fields` flags a value that contains a further `Label: ` (`STACKED_LABEL`), and `_answer_query` refuses with code `stacked_field_paragraph` and a `DIAGNOSTICS` next step. Refusing matches MPLPB's existing posture; do **not** "fix" this by splitting the line, because the boundary is genuinely unknown after rendering. Values with ordinary colons (`Ratio: 3:1 sand`) still answer (test included).

**Do also:**
- Search the frozen evaluations for any returned field answer whose cited `value` contains `": "` and report them. Do not edit frozen results; list them in the PR body.
- `code_pins()` in the answer contract will change. Call that out in the PR and in `handoff/update.json`.
- Optional follow-up (separate PR, ask first): make `plain_to_html` preserve line breaks for lines matching a field pattern. That changes page hashes for new pages only; it must not touch existing pages.

## 4. PR 2 — `sorter_v2.py`

A separate versioned engine (`offline-candidate-sorter-v2`) with the same CLI (`sort`, `verify`, `peruse`, `export-retired`), the same graph contract and assessment flags, plus `local_scope` on every feature and `rules` in the envelope. It accepts a v1 graph as `--prior` (historical snapshot only). v1 and v2 refuse to verify each other's graphs.

| Rule | v1 behaviour (bbf6690) | v2 behaviour | Test class |
|---|---|---|---|
| R1 | `Correction to SHIP-7.` → target `SHIP-7.` → "missing" | sentence punctuation never ends an ID or target | `TerminalPunctuation` |
| R2 | `Letter No. 41` not an identifier | numbered designations (document-type word required) are IDs; a designation line in the leading header block declares the record | `NumberedDesignations` |
| R3 | `Ref. Letter No. 41` → target `Letter`; `see you` → target `you` | target must be ID, designation, `<message-id>` or URL; otherwise no reference (or `unrecognized_target_form` review for correction wording) | `RecognizedTargets` |
| R4 | `SHIP-7 is superseded by this notice` → no link | passive with self agent links; third-party or unstated agent → review only | `PassiveDirection` |
| R5 | any `will`/`if`/quote anywhere in the paragraph qualifies every feature | qualification judged per clause (`local_scope`); statement `scope` keeps the v1 value | `ClauseScope` |
| R6 | `ten bales, not twelve` read as negating the correction; `not untrue` read as negation | negation must govern the cue within its clause; double negation → `negation_scope_unresolved` | `Negation` |
| R7 | `The porter said this note corrects SHIP-7 in full` → **possible_correction** | reported speech is its own qualified scope | `ReportedSpeech` |
| R8 | "the earlier note" → nothing | `descriptive_reference_review` with up to 5 candidates sharing a 4-word phrase or ≥3 content words incl. a rare one; none selected | `DescriptiveReferences` |

On Mitchell's own `tests/fixtures/sorter`, v1 and v2 produce the **same 14 review edges** (`test_original_fixture_reviews_match_v1`); the only new node is "Revised" in a subject line.

**Your tasks in PR 2:**
1. Apply, run `python -m unittest tests.test_sorter tests.test_sorter_v2`.
2. Add `docs/SORTER_V2.md` (adapt `docs/SORTER_V2.md` from this pack) and link it from `docs/PREPROCESSING_SORTER.md` with one line: "Rules v2 is a separate engine; v1 is frozen."
3. **Do not** switch `sorter_suggestions.py` or `candidate_workspace.py` to v2 in this PR. They call `core.verify_graph` and check the v1 schema. Wiring them is PR 6 (§8).
4. Known v2 limits to state in the doc: reported speech after the cue (`…corrects SHIP-7, the clerk said`) is not caught; one numbered designation per file header; English cue lists only.

## 5. PR 3 — `answer_router.py`

`python -m mplpb_work.answer_router ask "QUESTION" --ledger L [--dump D] [--profile internal|lab|external] [--no-rewrites] [--json]`

Exit 0 for `official` / `official_via_rewrite`, 1 otherwise, 2 on error. Output statuses:

| status | meaning |
|---|---|
| `official` | strict `supported_answer` for the user's exact question |
| `official_via_rewrite` | strict `supported_answer` for a router-proposed question; shows both questions and a caution |
| `unofficial` | best cited passages, labelled `UNOFFICIAL — not supported by MPLPB…`, with per-passage warnings and correction candidates |
| `no_answer` | nothing relevant anywhere; explanation and classing help still returned |

What the explanation draws on: the strict diagnostic category (`REASONS`), the provenance gate's own exclusion reasons (e.g. `source authorship unknown; external delivery withheld`), the ledger catalogue (field-scoped successors, withdrawn pages, stacked fields), and the supported question forms.

Rewrites: only `What is the <field> for record <ID>?`, only for fields the question names or hints at (`FIELD_HINTS`), and a field-scoped successor is asked for its corrected field. Every rewrite is run through strict MPLPB; the router never decides support itself.

Unofficial answers: BM25 (existing `mplpb_combined.baselines.LexicalIndex`) over eligible ledger paragraphs and dump statements. If the question names a record, only passages tied to it are used. Qualified passages are halved, not hidden. Dump files already classed into the ledger are labelled with their page ID; withdrawn sources are flagged. An optional `reader(question, passages) -> str` hook may compose prose **from the cited passages only**; keep it off by default and never let it set `answer_supported`.

**Your tasks in PR 3:** apply; add `docs/ANSWER_ROUTER.md` (from this pack); add a `route` subcommand to the native CLI only if `AGENTS.md`/maintainer agree (ask). Do not touch the browser UI in this PR.

## 6. PR 4 — `classing.py`

```
python -m mplpb_work.classing propose DUMP [--ledger L] [--prefix DUMP] [--auto-accept-clean] --output review.json
python -m mplpb_work.classing status review.json
python -m mplpb_work.classing build review.json --dump DUMP --ledger NEW_LEDGER [--append] [--ratify-by "Name"] [--receipt receipt.json]
```

What it automates (always literal):
- One draft page per source occurrence, ID from `Message-ID`/`Document-ID`/`Record-ID`/numbered designation, else a stable generated ID; unsafe IDs (e.g. `<a@b>`) get a generated ID and keep the original as a field.
- **Every `Label: value` line of the leading header block** becomes its own paragraph (`Cargo:`, `Invoice total:`, anything). This is what lets the strict field route answer; it is the fix for "only the first header field is readable". A lone prose line with a colon is not a header (`A diary entry: …` stays body).
- Provenance paragraphs: `Classing source file`, `Classing source SHA-256`, `Classing source bytes`.
- Unique scope `"<ID>: <title>"`, so ownership has one owner per page.
- Decisions from sorter v2 edges: `correction`, `partial_correction` (recommends `field_correction`), `duplicate_id` (blocking), `declared_status` (retired/superseded/withdrawn), `reference_review` (unresolved/descriptive; candidates listed, never chosen).
- `--auto-accept-clean` accepts only drafts with a declared, safe, unique ID and no blocker.

What it never does: infer a value, pick a correction target, choose `corrects_field`, ratify, declare authorship, or write to an existing ledger without `--append`. Builds rehearse in a temp copy, validate with `Ledger.findings()`, and only then write (new ledgers are moved into place atomically).

Ratification is recorded with `write(..., ratified_by=NAME)` at write time. Do not switch to `ledger.ratify()`: it mints a new ID (breaking "for record SHIP-7" questions) and cannot ratify a page already superseded for one field.

**Your tasks in PR 4:** apply; add `docs/CLASSING.md` (from this pack); keep the demo fixture under `tests/fixtures/classing_demo/` (fictional, never in the authentic corpus).

## 7. PR 5 — router tests

Apply and run. They build the demo ledger through classing, so they also exercise PR 4 end to end.

## 8. Follow-up PRs (do not start without the maintainer's go-ahead)

- **PR 6: wire v2 into PR #52 tools.** `sorter_suggestions.py` and `candidate_workspace.py` call `core.verify_graph` and test `schema == offline-candidate-sorter-v1`. Add a schema dispatch (`engine_for(graph)` returning `sorter` or `sorter_v2`), keep v1 the default, and add `--sorter-rules v2`. These modules may pin their own source in frozen results; check before editing, and preserve every frozen study's replay.
- **PR 7: re-run the sorter-first study with v2.** Same 22 questions, same budgets, same pins. Report changes per question. The v1 study found sorter-first hints *reduced* complete answers 2 → 1; the router design avoids that by construction (invariant 2), so the honest v2 study is "does classing + router raise official answers without lowering any", not "do hints help".
- **PR 8: independent evaluation.** See `docs/EVALUATION_PLAN.md`. Nothing in this pack establishes precision, recall, false-link rate or human cost.

## 9. Commands you must run and report

```sh
python -m unittest tests.test_sorter tests.test_sorter_v2 tests.test_classing tests.test_answer_router
python -m pytest -q tests            # full suite; report counts and duration
python -m mplpb_combined validate examples-or-test-ledger
bash examples/walkthrough.sh          # from this pack; compare with examples/router_transcript.txt
```

Report exactly what ran, what passed, what was skipped and why. Never write "passes" for a check you did not run.

## 10. When to stop and ask

- A test in §1 would need changing.
- Applying a patch conflicts with code changed after `bbf6690` in a way that is not a pure merge.
- Anything would rewrite a frozen evaluation, its pins, or `sorter.py`.
- A design question (CLI exposure, default profile for unofficial answers, wiring into the browser UI).
