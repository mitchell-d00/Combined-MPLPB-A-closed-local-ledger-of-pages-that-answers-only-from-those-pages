# Archival transcript

Written October 04, 1844.

Nora Wells wrote the orchard inventory.
