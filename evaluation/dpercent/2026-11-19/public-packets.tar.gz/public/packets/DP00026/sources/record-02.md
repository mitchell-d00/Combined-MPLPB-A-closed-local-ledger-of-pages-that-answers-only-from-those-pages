# Archival transcript

Written October 04, 1844.

Arun Moss wrote the orchard inventory.
