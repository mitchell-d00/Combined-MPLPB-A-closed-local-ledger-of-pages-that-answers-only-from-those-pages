# Archival transcript

Written August 28, 1842.

The harbor report was written by Nora Wells.
