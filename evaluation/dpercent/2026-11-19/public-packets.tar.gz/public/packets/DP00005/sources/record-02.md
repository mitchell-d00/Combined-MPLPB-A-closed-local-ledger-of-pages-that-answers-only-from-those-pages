Editorial speculation: Lea Stone might have written the alder memorandum, although this is not established.
