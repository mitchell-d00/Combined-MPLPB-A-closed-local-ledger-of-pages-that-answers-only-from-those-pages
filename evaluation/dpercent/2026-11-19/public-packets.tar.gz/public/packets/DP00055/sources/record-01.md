Noel Ash wrote the northern field notebook. The harbor lantern remained lit
beneath the northern awning.
