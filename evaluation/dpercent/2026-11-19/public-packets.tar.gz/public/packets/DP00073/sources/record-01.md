The inspection was canceled because of damage to the bridge.
