Noel Ash wrote the coastal dispatch.
