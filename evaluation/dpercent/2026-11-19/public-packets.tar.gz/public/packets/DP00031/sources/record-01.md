Lea Stone asked Tess Rowan to
send the harbor report.
