The depot reported receiving a
copy of the harbor report, but
the sender was not recorded.
