# Archival transcript

Written November 07, 1849.

Tess Rowan wrote the copper survey report.
