# Archival transcript

Written November 07, 1849.

Editorial speculation: Owen Pike might have written the copper survey report, although this is not established.
