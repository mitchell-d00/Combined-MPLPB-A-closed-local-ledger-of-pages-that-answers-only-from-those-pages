From: Noel Ash
To: Edda Marén
Date written: January 01, 1849
Subject: Archive notice
Message-ID: MAIL-10056

Noel Ash wrote the coastal dispatch.
