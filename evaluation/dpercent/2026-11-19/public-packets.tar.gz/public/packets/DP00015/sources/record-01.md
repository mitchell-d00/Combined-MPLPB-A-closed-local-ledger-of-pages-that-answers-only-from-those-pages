IRIS BECK TO LEA STONE. March 08, 1845
Dear colleague,

This record was written on March 08, 1845. I recorded an
idea about the copper survey report.
