LEA STONE TO IRIS BECK. May 03, 1843
Dear colleague,

The lamp went out before the
departure bell rang.
