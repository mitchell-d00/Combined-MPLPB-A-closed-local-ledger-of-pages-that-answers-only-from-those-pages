The copper survey report was
written by Tess Rowan.
