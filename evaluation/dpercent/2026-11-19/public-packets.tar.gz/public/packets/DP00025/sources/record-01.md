From: Mina Cole
To: Edda Marén
Date written: January 12, 1847
Subject: Archive notice
Message-ID: MAIL-10025

On January 09, 1847, Mina Cole sent the coastal dispatch. This record was written on January 12, 1847.
