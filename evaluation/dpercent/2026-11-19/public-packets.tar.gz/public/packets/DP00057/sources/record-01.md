Edda Marén planned to send the coastal dispatch.
