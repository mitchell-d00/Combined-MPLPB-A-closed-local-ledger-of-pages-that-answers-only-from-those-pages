# Archival transcript

Written November 17, 1842.

May Reed wrote the coastal dispatch.
