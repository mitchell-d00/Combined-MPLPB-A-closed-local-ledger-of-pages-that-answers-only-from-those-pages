From: Ivo Hart
To: Nora Wells
Date written: June 28, 1846
Subject: Archive notice
Message-ID: MAIL-10087

Ivo Hart asked Nora Wells to send the museum catalogue.
