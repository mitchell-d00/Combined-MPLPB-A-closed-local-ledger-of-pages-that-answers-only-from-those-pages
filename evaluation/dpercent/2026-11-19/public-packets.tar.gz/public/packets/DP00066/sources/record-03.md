Documentation example, not another communication.
```text
Message-ID: MAIL-10066
Owen Pike wrote the alder memorandum.
```
