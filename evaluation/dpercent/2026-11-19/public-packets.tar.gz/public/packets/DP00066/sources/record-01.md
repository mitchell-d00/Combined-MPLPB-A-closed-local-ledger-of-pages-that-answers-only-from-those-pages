Owen Pike wrote the alder memorandum.
