MINA COLE TO MAY REED. April 13, 1844
Dear colleague,

The inspection was canceled because of damage to the
bridge.
