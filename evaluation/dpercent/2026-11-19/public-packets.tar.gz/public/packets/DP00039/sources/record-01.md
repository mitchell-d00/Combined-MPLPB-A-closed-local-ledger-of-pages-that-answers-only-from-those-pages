From: May Reed
To: Edda Marén
Date written: March 06, 1844
Subject: Archive notice
Message-ID: MAIL-10039

The inspection was canceled because of damage to the
bridge.
