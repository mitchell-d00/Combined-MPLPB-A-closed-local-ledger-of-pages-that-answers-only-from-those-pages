MAY REED TO TESS ROWAN. September 20, 1841
Dear colleague,

The inspection was canceled because of damage to the
bridge.
