From: Mina Cole
To: Iris Beck
Date written: November 26, 1844
Subject: Archive notice
Message-ID: MAIL-10079

Mina Cole wrote the copper survey report.
