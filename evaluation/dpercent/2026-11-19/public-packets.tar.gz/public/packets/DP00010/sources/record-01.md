# Archival transcript

Written May 17, 1846.

May Reed wrote the coastal dispatch.
