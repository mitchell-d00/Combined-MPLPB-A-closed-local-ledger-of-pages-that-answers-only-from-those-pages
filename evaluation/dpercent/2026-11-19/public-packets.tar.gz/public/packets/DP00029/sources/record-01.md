From: Lea Stone
To: Arun Moss
Date written: May 28, 1842
Subject: Archive notice
Message-ID: MAIL-10029

The lamp went out before the
departure bell rang.
