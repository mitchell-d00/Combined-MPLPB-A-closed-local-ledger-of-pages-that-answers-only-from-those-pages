EDDA MARÉN TO IRIS BECK. October 03, 1845
Dear colleague,

On September 30, 1845, Edda
Marén sent the coastal
dispatch. This record was
written on October 03, 1845.
