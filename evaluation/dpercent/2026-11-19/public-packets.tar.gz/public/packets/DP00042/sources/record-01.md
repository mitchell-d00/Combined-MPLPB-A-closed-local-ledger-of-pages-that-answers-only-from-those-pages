Ivo Hart met Owen Pike. They discussed the harbor report. He sent it that
evening.
