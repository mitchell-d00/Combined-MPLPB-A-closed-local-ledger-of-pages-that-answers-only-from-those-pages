EDDA MARÉN TO NOEL ASH. October 16, 1842
Dear colleague,

Edda Marén did not send the
harbor report.
