OWEN PIKE TO EDDA MARÉN. July 29, 1849
Dear colleague,

Owen Pike wrote the canal
register. The harbor lantern
remained lit beneath the
northern awning.
