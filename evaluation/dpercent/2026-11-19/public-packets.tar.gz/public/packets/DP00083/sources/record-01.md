# Archival transcript

Written April 04, 1844.

Owen Pike wrote the northern field notebook.
