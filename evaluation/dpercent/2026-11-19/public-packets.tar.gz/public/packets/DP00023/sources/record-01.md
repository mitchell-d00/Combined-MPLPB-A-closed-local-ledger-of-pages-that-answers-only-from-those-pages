From: Lea Stone
To: May Reed
Date written: March 29, 1841
Subject: Archive notice
Message-ID: MAIL-10023

May Reed claimed that Lea Stone sent the orchard inventory; the register contains no independent receipt.
