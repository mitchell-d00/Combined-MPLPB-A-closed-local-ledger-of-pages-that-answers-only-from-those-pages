# Archival transcript

Written June 20, 1843.

The lamp went out before the
departure bell rang.
