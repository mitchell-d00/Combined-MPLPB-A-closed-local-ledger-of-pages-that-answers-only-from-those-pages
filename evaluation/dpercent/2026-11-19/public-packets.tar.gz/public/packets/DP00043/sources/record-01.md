# Archival transcript

Written January 31, 1843.

Tess Rowan did not send the museum catalogue.
