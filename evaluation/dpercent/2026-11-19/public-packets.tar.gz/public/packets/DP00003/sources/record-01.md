Tess Rowan wrote the canal register.
