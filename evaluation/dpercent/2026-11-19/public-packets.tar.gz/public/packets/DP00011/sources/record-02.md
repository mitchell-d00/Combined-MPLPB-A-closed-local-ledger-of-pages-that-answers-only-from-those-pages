IRIS BECK TO ARUN MOSS. February 18, 1845
Dear colleague,

In my letter of February 15, 1845, the count should read nine crates. The
destination remains the east depot.
