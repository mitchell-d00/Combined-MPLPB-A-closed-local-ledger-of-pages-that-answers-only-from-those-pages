IRIS BECK TO ARUN MOSS. February 15, 1845
Dear colleague,

This letter was written on February 15, 1845. The consignment contains six
crates for the east depot.
