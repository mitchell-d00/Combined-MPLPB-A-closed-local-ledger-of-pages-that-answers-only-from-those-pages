On February 09, 1840, Ivo Hart sent the copper survey report. This record was written on February 12, 1840.
