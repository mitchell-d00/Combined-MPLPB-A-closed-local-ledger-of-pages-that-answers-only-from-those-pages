MIRA VALE TO ARUN MOSS. March 31, 1848
Dear colleague,

In response to that request of March 28, 1848, I, Mira Vale, sent the harbor
report to the east depot.
