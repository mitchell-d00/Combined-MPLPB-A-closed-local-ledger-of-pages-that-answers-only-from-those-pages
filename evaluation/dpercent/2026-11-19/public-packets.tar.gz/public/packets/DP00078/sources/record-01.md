ARUN MOSS TO MIRA VALE. March 31, 1848
Dear colleague,

On March 28, 1848, Arun Moss asked Mira Vale to send the harbor report to the
east depot.
