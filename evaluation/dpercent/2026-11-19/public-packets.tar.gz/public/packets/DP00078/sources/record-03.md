ARUN MOSS TO MIRA VALE. March 31, 1848
Dear colleague,

The east depot reported receiving the harbor report sent by Mira Vale in
response to the request of March 28, 1848.
