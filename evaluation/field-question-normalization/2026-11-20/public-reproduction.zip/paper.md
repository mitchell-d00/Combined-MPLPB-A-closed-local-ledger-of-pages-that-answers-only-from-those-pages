# Guarded Retrieval, Paraphrase Blindness, and Evidence-Grounded Answering

*Independent evaluation of Mitchell D. McPhetridge’s Combined MPLPB (Multi-Platform Linked Public Building) — an October 2026 source-bounded test of the strict local answer pipeline*

**19 November 2026 — Research preprint.**

**Publication and reproduction folder:** https://drive.google.com/drive/folders/1i_n34wkDoHEky-5p7-pmu4Xs2IPblli0

## Abstract

This paper independently tests the strict local answer pipeline of Combined MPLPB (Multi-Platform Linked Public Building), software developed by Mitchell D. McPhetridge (Mitch). Canonical exact-field probes were supported in **150/150** trials, while five paired paraphrase forms were supported in **0/750** trials. Four negative controls were correctly rejected in **50/50** trials each. The test used fifty fully anonymous, synthetic source cards and a pinned strict Combined MPLPB release. The original October source ZIP was verified by hash and audited for aggregate graph structure, then retained privately. This contrast distinguishes safeguard quality from usable retrieval and motivates source-grounded semantic query normalization.

## Results

| Condition | Count | Rate |
|---|---:|---:|
| Exact-field canonical requests supported | 150/150 | 100% |
| Same requests, five paraphrases supported | 0/750 | 0% |
| Nonexistent records rejected | 50/50 | 100% |
| Absent fields rejected | 50/50 | 100% |
| External profile on machine-origin page rejected | 50/50 | 100% |
| Unsupported identity inferences rejected | 50/50 | 100% |

## Source scope

Private October source: 8,684,603 bytes, SHA-256 `8a4b9a6411ad773811ba97505bee6131f7e63ffd86322c734af793ab3e1f9b6c`. The inherited ledger had **3,671 rows**, although its declared count was **2,057**. A separate historical receipt reported **4,113 cumulative edges**; its exact ledger correspondence remains open.

## Method

**Software under test and creator:** Mitchell D. McPhetridge (Mitch), developer of Combined MPLPB (Multi-Platform Linked Public Building). This research evaluates the pinned strict CLI pipeline in his project. Original software: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages.

Fifty independently addressed synthetic records carried the fields `Current Status`, `Relation Type`, and `To Object`. Each field was queried once with the canonical strict-template question and five alternative formulations that retained the same record identifier and semantic target. The outcome counted the engine’s native `answer_supported` Boolean. Four refusal/control questions were also run for each record. Tested version: Combined MPLPB commit `bbf6690d69b32d16969cc10e5ce9d380427ead40` and native strict `answer_query`.

## Interpretation

Reliable refusal for unsupported fields protects source integrity. Refusal for supported fields phrased in normal language instead prevents practical recovery of available evidence. Both properties require independent measurement. The sharp 100% versus 0% contrast highlights a need for semantic normalization, retrieval candidate generation, provenance checking, and field-level answer verification. It supports a narrowed claim about the strict local engine and the sampled synthetically generated questions.

## Reproducibility and privacy

The folder contains the editable and print versions of the paper, fully synthetic test records and queries, the tested program’s pinned upstream source reference, runnable method-equivalent test driver, and machine results. Private case correspondence, personal identifiers, attachments and source bodies are retained under the owner's restricted archive. Reproduction requires no private case data.

## Reproduction references

- Folder: https://drive.google.com/drive/folders/1i_n34wkDoHEky-5p7-pmu4Xs2IPblli0
- Software developer: Mitchell D. McPhetridge (Mitch)
- Software: Combined MPLPB (Multi-Platform Linked Public Building)
- Upstream repository: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages
- Commit: `bbf6690d69b32d16969cc10e5ce9d380427ead40`
