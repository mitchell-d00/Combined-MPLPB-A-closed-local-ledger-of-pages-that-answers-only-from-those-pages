# Independent Evaluation of Mitchell D. McPhetridge’s Combined MPLPB

Software: Combined MPLPB (Multi-Platform Linked Public Building), developed by Mitchell D. McPhetridge (Mitch). The study independently evaluates its strict local answer pipeline.

Publication package: https://drive.google.com/drive/folders/1i_n34wkDoHEky-5p7-pmu4Xs2IPblli0

## Contents

- `paper.pdf` and `paper.docx`: preprint and editable manuscript.
- `results/measured_results.json`: observed source integrity, query support, and negative-control aggregates.
- `fixtures.csv`, `fixtures/REC-*.html`: 50 entirely synthetic anonymous test cards, as human-readable logical fixture projections.
- `test_questions.csv`: all 900 answerable field questions (150 exact, 750 paraphrases).
- `reproduce.py`: runnable, method-equivalent public test driver that builds genuine Combined MPLPB pages through its own ledger writer and queries its strict pipeline.
- `SOURCE_PROVENANCE.md`: archive hashes and protected-source boundaries.
- `MANIFEST_SHA256.txt`: per-file integrity checks for the publication ZIP contents.

## Run the same strict-engine test

Pinned Combined MPLPB repository (Mitchell D. McPhetridge): https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages
Commit: `bbf6690d69b32d16969cc10e5ce9d380427ead40`

Using a local Python environment (Python 3.10+):

```bash
git clone https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages combined
cd combined
git checkout bbf6690d69b32d16969cc10e5ce9d380427ead40
PYTHONPATH=. python3 /path/to/reproduce.py --output /path/to/new-results
```

The output will include one real engine-native page per isolated synthetic record and `results.json`. Compare its totals with `results/measured_results.json`. The upstream source remains under its own license/terms. This package contains the fixture logic and test evidence.

## Privacy and evidence

All distributed fixtures and test questions are synthetic. The private October archive was independently verified byte-for-byte against the Drive source and used for structural metadata counts. Its source documents, messages, attachments, names, contact information, account numbers, and document bodies remain with their restricted originals.

The report identifies 3,671 observed rows in an inherited graph object whose embedded declared count is 2,057. A separate 4,113-edge historical receipt is retained as a reported total until the exact corresponding ledger can be inspected. Those populations are recorded separately.

## Interpreting the results

The 150/150 numerator records the native engine's `answer_supported=true` status for canonical questions. All 750 paired, semantically equivalent questions returned unsupported. Four negative controls were rejected in all 50 cases each. These measurements characterize the pinned strict CLI with isolated synthetic records. They do not evaluate every MPLPB mode or the historical truth of private case claims.
