# Source integrity and privacy scope

The private October 2026 source ZIP was independently read from Google Drive and matched against the existing authorized Amplify copy by SHA-256.

- Source size: **8,684,603 bytes**
- Full ZIP SHA-256: `8a4b9a6411ad773811ba97505bee6131f7e63ffd86322c734af793ab3e1f9b6c`
- ZIP members: **233**
- Inherited edge ledger member: `17_EDGE_LEDGER.json`
- Edge ledger SHA-256: `fbde20ba93a63eccd1624ea6415736def18bcd872d02ea71bc5b2eb044ccf6d9`
- Observed inherited edge rows: **3,671**
- Embedded edge count declaration: **2,057** (inconsistent with actual row count)
- Separate historical figure: **4,113 cumulative edges**; source receipt asserted, corresponding ledger still unresolved.
- Original case sources: retained under owner-controlled access.

Distribution consists of generated source cards, questions, code, aggregated observations, paper, and checksums. All public records use fictitious entity and field values. The private archive itself is preserved at the original location.

Original upstream software by Mitchell D. McPhetridge (Mitch): Combined MPLPB (Multi-Platform Linked Public Building).
Pinned implementation: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages/tree/bbf6690d69b32d16969cc10e5ce9d380427ead40
Publication folder: https://drive.google.com/drive/folders/1i_n34wkDoHEky-5p7-pmu4Xs2IPblli0
