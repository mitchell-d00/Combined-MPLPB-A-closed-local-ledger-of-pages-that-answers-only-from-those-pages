#!/usr/bin/env python3
"""Reproduce strict MPLPB lexical answerability tests on safe anonymous cards.
Requires the pinned Combined MPLPB source tree on PYTHONPATH.
No original private case archive is required.
"""
import argparse,collections,html,json,pathlib,random
from mplpb_answers.pipeline import answer_query
from mplpb_combined.ledger import write
from mplpb_combined.reader import PROFILES

TEMPLATES=[
 'What is the {field} for record {id}?',
 'Tell me the {field} listed on record {id}.',
 'For record {id}, which {field} is explicitly stated?',
 'Looking only at {id}, identify the {field} recorded there.',
 "Could you give me {id}'s {field}?",
 'Please find {id} and report its {field}.',
]

def ask(root,q,**kwargs):
    try:
        r=answer_query(root,q,**kwargs).contract
        return {'supported':bool(r['answer_supported']),'kind':r['kind'],
                'code':r['diagnostic']['code'],'claims':[v.get('text') for v in r.get('claims',[])]}
    except Exception as e:return {'error':type(e).__name__}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',default='reproduced_results')
    ap.add_argument('--count',type=int,default=50)
    args=ap.parse_args()
    out=pathlib.Path(args.output);out.mkdir(parents=True,exist_ok=True)
    gen=random.Random(20261119);cnt=collections.Counter();examples=[]
    for i in range(1,args.count+1):
        rid='REC-%04d'%i
        values={'Current Status':'STATE-'+gen.choice('ABC'),
                'Relation Type':'REL-'+gen.choice('ABC'),
                'To Object':'OBJ-%04d'%gen.randint(1,90)}
        root=out/'fixtures'/rid;root.mkdir(parents=True,exist_ok=True)
        body='Record-ID: '+rid+'\n'+'\n'.join(k+': '+v for k,v in values.items())
        write(root,doc_id='SYN-'+rid,title='Synthetic anonymous fixture',
              scope='generated test-only content; original archive separate',
              body_html='<pre>'+html.escape(body)+'</pre>',origin='machine')
        for field in values:
            for t,fmt in enumerate(TEMPLATES):
                q=fmt.format(id=rid,field=field.lower())
                r=ask(root,q)
                cnt['form%d_tested'%t]+=1
                cnt['form%d_supported'%t]+=int(r.get('supported',False))
                cnt['form%d_errors'%t]+=int('error' in r)
                if i==1:
                    examples.append({'question':q,'supported':r.get('supported',False),
                                     'kind':r.get('kind'),'diagnostic':r.get('code')})
        checks=[
           ('nonexistent','What is the current status for record NOT-HERE-%04d?'%i,{}),
           ('missing_field','What is the court disposition for record '+rid+'?',{}),
           ('external','What is the current status for record '+rid+'?',{'profile':PROFILES['external']}),
           ('identity','Are the owner and recipient definitely the same person for record '+rid+'?',{}),
        ]
        for tag,q,opts in checks:
            r=ask(root,q,**opts)
            cnt[tag+'_tested']+=1
            cnt[tag+'_rejected']+=int(not r.get('supported',False) and 'error' not in r)
    output={'counts':dict(cnt),'examples':examples,
            'exact_supported':cnt['form0_supported'],'exact_tested':cnt['form0_tested'],
            'paraphrase_supported':sum(cnt['form%d_supported'%t] for t in range(1,6)),
            'paraphrase_tested':sum(cnt['form%d_tested'%t] for t in range(1,6))}
    (out/'results.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k not in ('counts','examples')}))
if __name__=='__main__':main()
