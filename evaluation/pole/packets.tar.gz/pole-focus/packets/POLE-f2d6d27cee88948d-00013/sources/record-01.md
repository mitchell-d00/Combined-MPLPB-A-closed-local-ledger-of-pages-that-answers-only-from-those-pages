Record-ID: ARCH-10013
Custody Location: East vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Résumé — 東京.
