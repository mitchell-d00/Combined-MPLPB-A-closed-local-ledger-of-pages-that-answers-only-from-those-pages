Message-ID: NOTE-30032
Subject: Depot notice

Twelve crates arrived. Émile read the entry.

Message-ID: NOTE-30032-NEXT
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
