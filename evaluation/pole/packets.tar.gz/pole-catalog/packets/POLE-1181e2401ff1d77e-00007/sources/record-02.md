This record was written on
September 20, 1844. I recorded
an idea about the northern
field notebook.
