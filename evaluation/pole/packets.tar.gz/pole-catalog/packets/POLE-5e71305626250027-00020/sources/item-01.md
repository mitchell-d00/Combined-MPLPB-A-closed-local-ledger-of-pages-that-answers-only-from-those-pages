Record-ID: NOTE-30020
Deposit Location: East vault

Zoë copied the note — 東京.
