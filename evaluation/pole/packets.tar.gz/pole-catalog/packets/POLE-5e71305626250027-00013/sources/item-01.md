Record-ID: NOTE-30013
Approval Time: 14:20

Zoë copied the note — 東京.
