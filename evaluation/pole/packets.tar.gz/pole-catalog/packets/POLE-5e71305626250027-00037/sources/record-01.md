From: Edda Marén
To: Mira Vale
Date written: May 05, 1849
Subject: Archive notice
Message-ID: MAIL-10037

Edda Marén wrote the northern field notebook.
