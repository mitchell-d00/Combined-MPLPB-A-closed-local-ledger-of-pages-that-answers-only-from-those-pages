Message-ID: NOTE-30031-NEXT
Subject: Depot notice

This notice corrects NOTE-30031: nine crates.
