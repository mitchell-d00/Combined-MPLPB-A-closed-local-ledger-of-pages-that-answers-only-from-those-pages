Message-ID: NOTE-30031
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
