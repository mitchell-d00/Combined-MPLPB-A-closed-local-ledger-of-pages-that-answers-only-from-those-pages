From: Lea Stone
To: May Reed
Date written: April 25, 1843
Subject: Archive notice
Message-ID: MAIL-10022

I have told Ivo Hart to send you a copy of the coastal
dispatch by post (if possible).
