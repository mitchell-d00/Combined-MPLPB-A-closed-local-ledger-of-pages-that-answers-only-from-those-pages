Message-ID: NOTE-30036
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
