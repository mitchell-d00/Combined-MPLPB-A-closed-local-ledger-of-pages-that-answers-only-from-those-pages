Message-ID: NOTE-30002
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
