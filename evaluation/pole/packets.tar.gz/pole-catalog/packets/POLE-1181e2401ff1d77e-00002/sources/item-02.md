Message-ID: NOTE-30002-NEXT
Subject: Depot notice

This notice corrects NOTE-30002 only in quantity; the date remains unchanged.
