Message-ID: NOTE-30035-NEXT
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
