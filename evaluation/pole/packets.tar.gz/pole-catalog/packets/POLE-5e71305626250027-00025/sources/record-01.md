IRIS BECK TO MIRA VALE. November 04, 1845
Dear colleague,

Iris Beck wrote the coastal dispatch.
