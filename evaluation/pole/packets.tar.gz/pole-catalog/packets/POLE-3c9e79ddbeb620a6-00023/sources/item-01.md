Message-ID: NOTE-30023
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
