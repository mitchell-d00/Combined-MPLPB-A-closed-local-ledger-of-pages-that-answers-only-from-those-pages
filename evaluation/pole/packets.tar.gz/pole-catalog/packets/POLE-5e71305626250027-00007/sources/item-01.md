Message-ID: NOTE-30007
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
