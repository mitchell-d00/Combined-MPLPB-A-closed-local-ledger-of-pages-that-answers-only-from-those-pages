Message-ID: NOTE-30010
Subject: Depot notice

Nine crates arrived. Clerk copied this entry.
