Message-ID: NOTE-30010
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
