From: Iris Beck
To: Nora Wells
Date written: April 06, 1846
Subject: Archive notice
Message-ID: MAIL-10013

On April 06, 1846, Iris Beck recorded an idea about the coastal dispatch.
