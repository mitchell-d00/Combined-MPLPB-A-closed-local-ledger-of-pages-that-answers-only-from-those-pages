MIRA VALE TO MINA COLE. December 28, 1842
Dear colleague,

Mira Vale wrote the museum catalogue.
