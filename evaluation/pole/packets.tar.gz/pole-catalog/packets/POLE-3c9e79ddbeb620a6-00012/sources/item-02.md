Message-ID: NOTE-30012-NEXT
Subject: Depot notice

NOTE-30012 is hereby corrected by this notice: nine crates.
