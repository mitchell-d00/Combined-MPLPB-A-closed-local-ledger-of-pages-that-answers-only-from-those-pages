Message-ID: NOTE-30012
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
