Record-ID: NOTE-30034
General Location: East vault

Clerk copied this entry.
