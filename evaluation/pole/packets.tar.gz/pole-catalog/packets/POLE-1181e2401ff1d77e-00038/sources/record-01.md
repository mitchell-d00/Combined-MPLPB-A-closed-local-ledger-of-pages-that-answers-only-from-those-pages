IVO HART TO IRIS BECK. September 18, 1849
Dear colleague,

My earlier letter lists twelve
crates for the east depot.
