IVO HART TO IRIS BECK. September 18, 1849
Dear colleague,

My earlier letter is mistaken;
the count should read fourteen.
