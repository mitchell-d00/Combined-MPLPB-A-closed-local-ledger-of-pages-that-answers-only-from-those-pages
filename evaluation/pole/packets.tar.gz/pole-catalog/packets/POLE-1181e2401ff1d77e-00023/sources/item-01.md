Message-ID: NOTE-30023
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
