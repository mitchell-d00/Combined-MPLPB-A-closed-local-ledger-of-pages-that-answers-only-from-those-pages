Letter No. 41

Twelve crates arrived.
