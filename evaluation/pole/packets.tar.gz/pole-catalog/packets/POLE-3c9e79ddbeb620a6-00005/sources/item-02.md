Letter No. 42

See Letter No. 41.
