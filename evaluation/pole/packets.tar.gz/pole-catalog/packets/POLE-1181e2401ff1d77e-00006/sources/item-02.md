Message-ID: NOTE-30006-NEXT
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
