Message-ID: NOTE-30006
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
