Message-ID: NOTE-30014
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
