Message-ID: NOTE-30014-NEXT
Subject: Depot notice

This notice corrects NOTE-30014: nine crates.
