Message-ID: NOTE-30013-NEXT
Subject: Depot notice

If approved, this notice corrects NOTE-30013: nine crates.
