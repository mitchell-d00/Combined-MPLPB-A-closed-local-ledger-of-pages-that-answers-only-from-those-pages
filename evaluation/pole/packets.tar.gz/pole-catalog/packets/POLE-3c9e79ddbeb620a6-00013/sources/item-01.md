Message-ID: NOTE-30013
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
