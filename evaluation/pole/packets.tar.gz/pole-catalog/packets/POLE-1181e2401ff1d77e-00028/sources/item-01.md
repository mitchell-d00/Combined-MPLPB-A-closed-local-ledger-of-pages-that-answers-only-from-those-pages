Message-ID: NOTE-30028
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
