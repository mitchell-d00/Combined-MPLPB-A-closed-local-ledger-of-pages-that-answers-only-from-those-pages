Message-ID: NOTE-30028
Subject: Depot notice

Nine crates arrived. Émile read the entry.
