Message-ID: NOTE-30001
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
