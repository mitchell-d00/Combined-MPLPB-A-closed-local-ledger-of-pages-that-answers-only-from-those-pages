Message-ID: NOTE-30001-NEXT
Subject: Depot notice

Six crates arrived. Émile read the entry.
