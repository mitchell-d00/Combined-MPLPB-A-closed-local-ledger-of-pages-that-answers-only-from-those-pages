From: Nora Wells
To: Ivo Hart
Date written: January 14, 1842
Subject: Archive notice
Message-ID: MAIL-10016

The depot reported receiving a copy of the harbor report,
but the sender was not recorded.
