From: Nora Wells
To: Ivo Hart
Date written: January 14, 1842
Subject: Archive notice
Message-ID: MAIL-10016

Nora Wells asked Ivo Hart to send the harbor report.
