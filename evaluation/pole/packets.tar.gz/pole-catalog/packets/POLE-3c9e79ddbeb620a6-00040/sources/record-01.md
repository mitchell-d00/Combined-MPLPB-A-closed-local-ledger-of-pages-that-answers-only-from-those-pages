# Register

Documentation example, not an independent record.
~~~text
Record-ID: ARCH-10040
Current Status: Pending
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Clerk wrote this entry.
~~~
