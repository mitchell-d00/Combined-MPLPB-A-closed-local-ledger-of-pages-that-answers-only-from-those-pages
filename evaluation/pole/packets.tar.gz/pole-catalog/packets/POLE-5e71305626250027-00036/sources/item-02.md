Message-ID: NOTE-30036-NEXT
Subject: Depot notice

Six crates arrived. Émile read the entry.
