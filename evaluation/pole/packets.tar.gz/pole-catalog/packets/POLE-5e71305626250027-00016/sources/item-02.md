Message-ID: NOTE-30016-NEXT
Subject: Depot notice

Six crates arrived. Zoë copied the note — 東京.
