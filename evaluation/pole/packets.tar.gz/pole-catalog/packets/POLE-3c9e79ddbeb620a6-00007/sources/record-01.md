Record-ID: ARCH-10007
Custody Location: East vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Entry copied by Edda Marén.
