Message-ID: NOTE-30028
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
