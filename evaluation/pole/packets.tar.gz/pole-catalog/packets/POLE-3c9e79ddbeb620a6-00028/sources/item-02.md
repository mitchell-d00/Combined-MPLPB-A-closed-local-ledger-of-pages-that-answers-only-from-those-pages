Message-ID: NOTE-30028-NEXT
Subject: Depot notice

The porter said this corrects NOTE-30028: nine crates.
