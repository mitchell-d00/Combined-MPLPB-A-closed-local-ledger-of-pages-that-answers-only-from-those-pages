Message-ID: NOTE-30015
Subject: Depot notice

Twelve crates arrived. Clerk copied this entry.
