From: Mira Vale
To: May Reed
Date written: April 04, 1846
Subject: Archive notice
Message-ID: MAIL-10024

Mira Vale wrote the harbor
report.
