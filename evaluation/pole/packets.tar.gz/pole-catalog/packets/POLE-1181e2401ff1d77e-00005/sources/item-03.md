# Documentation
Example only; not another communication.
```text
Message-ID: NOTE-30005
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
```
