Record-ID: NOTE-30011
Deposit Location: East vault

Clerk copied this entry.
