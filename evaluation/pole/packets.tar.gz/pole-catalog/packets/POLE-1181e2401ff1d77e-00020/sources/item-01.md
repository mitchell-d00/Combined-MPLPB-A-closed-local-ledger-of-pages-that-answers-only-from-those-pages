Message-ID: NOTE-30020
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
