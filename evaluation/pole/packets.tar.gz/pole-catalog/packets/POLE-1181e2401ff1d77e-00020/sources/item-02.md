Message-ID: NOTE-30020-NEXT
Subject: Depot notice

This notice corrects NOTE-30020: nine crates.
