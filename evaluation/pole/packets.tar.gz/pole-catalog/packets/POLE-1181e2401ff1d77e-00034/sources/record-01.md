From: Nora Wells
To: Tess Rowan
Date written: September 03, 1844
Subject: Archive notice
Message-ID: MAIL-10034

This letter was written on
September 03, 1844. The
consignment contains twelve
crates for the east depot.
