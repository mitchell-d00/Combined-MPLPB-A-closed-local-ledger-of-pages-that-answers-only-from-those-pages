From: Nora Wells
To: Tess Rowan
Date written: September 06, 1844
Subject: Archive notice
Message-ID: MAIL-10034

In my letter of September 03,
1844, the count should read
fourteen crates. The
destination remains the east
depot.
