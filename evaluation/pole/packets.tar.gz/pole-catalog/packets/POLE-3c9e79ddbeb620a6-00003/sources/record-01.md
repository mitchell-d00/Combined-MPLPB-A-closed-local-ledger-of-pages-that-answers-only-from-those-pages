# Archival transcript

Written March 30, 1849.

Unless the permit is denied, Tess Rowan may send the northern field notebook.
