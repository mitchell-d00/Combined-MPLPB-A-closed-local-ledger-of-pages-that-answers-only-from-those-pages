# Archival transcript

Written October 28, 1841.

May Reed asked Tess Rowan to send the copper survey report.
