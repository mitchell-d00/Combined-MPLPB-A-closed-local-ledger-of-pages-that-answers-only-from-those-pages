# Archival transcript

Written October 28, 1841.

The depot reported receiving a copy of the copper survey report, but the sender
was not recorded.
