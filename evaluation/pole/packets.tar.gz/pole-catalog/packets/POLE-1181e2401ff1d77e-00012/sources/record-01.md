From: Nora Wells
To: Edda Marén
Date written: June 06, 1840
Subject: Archive notice
Message-ID: MAIL-10012

On June 03, 1840, Nora Wells asked Edda Marén to send the alder memorandum to
the east depot.
