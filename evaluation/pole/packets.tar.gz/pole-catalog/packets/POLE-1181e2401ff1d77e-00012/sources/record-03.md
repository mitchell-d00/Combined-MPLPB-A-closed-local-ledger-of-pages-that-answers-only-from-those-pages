From: Nora Wells
To: Edda Marén
Date written: June 06, 1840
Subject: Archive notice
Message-ID: MAIL-10012

The east depot reported receiving the alder memorandum sent by Edda Marén in
response to the request of June 03, 1840.
