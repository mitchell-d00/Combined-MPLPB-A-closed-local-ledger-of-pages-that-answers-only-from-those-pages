From: Edda Marén
To: Nora Wells
Date written: June 06, 1840
Subject: Archive notice
Message-ID: MAIL-10012

In response to that request of June 03, 1840, I, Edda Marén, sent the alder
memorandum to the east depot.
