Message-ID: NOTE-30038-NEXT
Subject: Depot notice

This notice corrects NOTE-30038: nine crates.
