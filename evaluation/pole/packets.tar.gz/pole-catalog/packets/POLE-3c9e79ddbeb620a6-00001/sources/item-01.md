Message-ID: NOTE-30001
Subject: Depot notice

Twelve crates arrived. Zoë copied the note — 東京.
