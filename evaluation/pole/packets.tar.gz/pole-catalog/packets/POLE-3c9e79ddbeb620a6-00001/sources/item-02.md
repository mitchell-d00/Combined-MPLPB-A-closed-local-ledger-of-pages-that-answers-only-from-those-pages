Message-ID: NOTE-30001-NEXT
Subject: Depot notice

> This notice corrects NOTE-30001: nine crates.
