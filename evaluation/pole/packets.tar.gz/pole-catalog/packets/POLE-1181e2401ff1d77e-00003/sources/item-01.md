Message-ID: NOTE-30003
Subject: Depot notice

Twelve crates arrived. Émile read the entry.

Message-ID: NOTE-30003-NEXT
Subject: Depot notice

Twelve crates arrived. Émile read the entry.
