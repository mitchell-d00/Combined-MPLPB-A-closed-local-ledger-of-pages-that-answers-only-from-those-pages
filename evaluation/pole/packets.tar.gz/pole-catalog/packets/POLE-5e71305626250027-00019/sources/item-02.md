Message-ID: NOTE-30019-NEXT
Subject: Depot notice

This notice corrects NOTE-30019: nine crates.
