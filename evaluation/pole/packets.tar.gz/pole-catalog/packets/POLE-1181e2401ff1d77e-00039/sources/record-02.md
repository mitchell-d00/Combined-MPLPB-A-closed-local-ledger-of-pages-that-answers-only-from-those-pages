# Archival transcript

Written March 02, 1841.

In response to that request of February 27, 1841, I, Arun
Moss, sent the orchard inventory to the east depot.
