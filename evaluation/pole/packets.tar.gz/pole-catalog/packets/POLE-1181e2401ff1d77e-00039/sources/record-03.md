# Archival transcript

Written March 02, 1841.

The east depot reported receiving the orchard inventory
sent by Arun Moss in response to the request of February
27, 1841.
