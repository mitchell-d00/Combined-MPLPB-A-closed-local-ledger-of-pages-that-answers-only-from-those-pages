# Archival transcript

Written March 02, 1841.

On February 27, 1841, Nora Wells asked Arun Moss to send
the orchard inventory to the east depot.
