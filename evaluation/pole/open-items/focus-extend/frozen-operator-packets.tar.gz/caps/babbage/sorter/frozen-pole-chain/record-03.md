From: Edda Marén
To: Ivo Hart
Date written: March 22, 1846
Subject: Archive notice
Message-ID: MAIL-10008

The east depot reported receiving the canal register sent by Ivo Hart in response to the request of March 19, 1846.
