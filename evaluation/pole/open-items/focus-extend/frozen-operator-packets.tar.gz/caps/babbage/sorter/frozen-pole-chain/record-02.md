From: Ivo Hart
To: Edda Marén
Date written: March 22, 1846
Subject: Archive notice
Message-ID: MAIL-10008

In response to that request of March 19, 1846, I, Ivo Hart, sent the canal register to the east depot.
