From: Edda Marén
To: Ivo Hart
Date written: March 22, 1846
Subject: Archive notice
Message-ID: MAIL-10008

On March 19, 1846, Edda Marén asked Ivo Hart to send the canal register to the east depot.
