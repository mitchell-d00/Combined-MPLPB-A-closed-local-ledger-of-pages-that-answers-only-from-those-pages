TESS ROWAN TO EDDA MARÉN. November 18, 1844
Dear colleague,

Edda Marén said, "Tess Rowan wrote the museum catalogue."
