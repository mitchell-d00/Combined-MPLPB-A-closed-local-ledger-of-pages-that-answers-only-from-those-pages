# Archival transcript

Written May 21, 1842.

Arun Moss met Ivo Hart. They discussed the harbor report. He sent it that
evening.
