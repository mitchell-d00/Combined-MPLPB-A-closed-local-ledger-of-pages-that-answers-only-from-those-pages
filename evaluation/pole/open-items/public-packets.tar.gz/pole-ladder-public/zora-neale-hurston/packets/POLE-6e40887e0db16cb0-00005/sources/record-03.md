The east depot reported receiving the northern field notebook sent by Ivo Hart
in response to the request of December 05, 1841.
