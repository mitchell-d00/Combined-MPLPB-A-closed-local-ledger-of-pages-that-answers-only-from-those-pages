From: Noel Ash
To: Tess Rowan
Date written: July 15, 1846
Subject: Archive notice
Message-ID: MAIL-10007

The depot reported receiving a copy of the alder
memorandum, but the sender was not recorded.
