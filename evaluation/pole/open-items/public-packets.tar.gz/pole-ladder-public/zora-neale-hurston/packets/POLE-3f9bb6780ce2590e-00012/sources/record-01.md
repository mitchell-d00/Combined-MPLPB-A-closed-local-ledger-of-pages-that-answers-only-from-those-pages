# Archival transcript

Written November 27, 1847.

The lamp went out before the
departure bell rang.
