Mira Vale reported that Lea Stone wrote the alder memorandum.
