LEA STONE TO MAY REED. May 06, 1841
Dear colleague,

Unless the permit is denied, Lea Stone may send the harbor report.
