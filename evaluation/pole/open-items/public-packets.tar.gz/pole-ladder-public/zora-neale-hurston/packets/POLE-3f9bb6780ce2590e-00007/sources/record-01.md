NOEL ASH TO IRIS BECK. August 24, 1848
Dear colleague,

If the permit arrives, Noel Ash will send the northern field notebook.
