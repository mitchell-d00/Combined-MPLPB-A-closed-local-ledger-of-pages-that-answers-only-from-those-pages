LEA STONE TO IRIS BECK. September 11, 1843
Dear colleague,

In response to that request of September 08, 1843, I, Lea Stone, sent the alder memorandum to the east depot.
