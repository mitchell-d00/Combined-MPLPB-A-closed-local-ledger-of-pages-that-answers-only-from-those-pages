IRIS BECK TO LEA STONE. September 11, 1843
Dear colleague,

On September 08, 1843, Iris Beck asked Lea Stone to send the alder memorandum to the east depot.
