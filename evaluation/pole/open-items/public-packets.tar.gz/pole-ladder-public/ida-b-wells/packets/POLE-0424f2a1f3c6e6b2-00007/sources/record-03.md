IRIS BECK TO LEA STONE. September 11, 1843
Dear colleague,

The east depot reported receiving the alder memorandum sent by Lea Stone in response to the request of September 08, 1843.
