# Archival transcript

Written January 19, 1847.

According to May Reed, Iris Beck wrote the coastal
dispatch.
