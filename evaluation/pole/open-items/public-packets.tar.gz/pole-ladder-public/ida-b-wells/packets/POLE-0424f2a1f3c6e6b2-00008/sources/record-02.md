ARUN MOSS TO TESS ROWAN. March 28, 1845
Dear colleague,

The depot reported receiving a copy of the alder
memorandum, but the sender was not recorded.
