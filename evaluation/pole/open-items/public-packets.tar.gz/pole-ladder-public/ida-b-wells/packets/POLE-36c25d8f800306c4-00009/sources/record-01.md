# Archival transcript

Written October 10, 1841.

On October 07, 1841, Arun Moss
sent the orchard inventory.
This record was written on
October 10, 1841.
