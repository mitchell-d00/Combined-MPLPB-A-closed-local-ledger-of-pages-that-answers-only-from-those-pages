# Archival transcript

Written December 30, 1848.

The lamp went out before the departure bell rang.
