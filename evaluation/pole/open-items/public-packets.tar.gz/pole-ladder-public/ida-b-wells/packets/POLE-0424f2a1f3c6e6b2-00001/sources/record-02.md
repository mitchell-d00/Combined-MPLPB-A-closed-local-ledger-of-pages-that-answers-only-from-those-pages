From: Mira Vale
To: Arun Moss
Date written: July 07, 1848
Subject: Archive notice
Message-ID: MAIL-10001

The notice describes seventeen crates for the east depot.
