NOEL ASH TO LEA STONE. January 22, 1848
Dear colleague,

Noel Ash asked Lea Stone to send the harbor report.
