NOEL ASH TO LEA STONE. January 22, 1848
Dear colleague,

The depot reported receiving a copy of the harbor report,
but the sender was not recorded.
