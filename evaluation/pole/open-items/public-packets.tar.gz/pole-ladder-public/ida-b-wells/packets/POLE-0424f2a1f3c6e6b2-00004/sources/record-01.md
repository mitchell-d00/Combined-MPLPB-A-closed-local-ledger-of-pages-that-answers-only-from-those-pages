On May 24, 1846, Mina Cole asked Ivo Hart to send the museum catalogue to the
east depot.
