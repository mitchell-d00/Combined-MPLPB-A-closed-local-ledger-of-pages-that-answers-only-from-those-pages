The east depot reported receiving the museum catalogue sent by Ivo Hart in
response to the request of May 24, 1846.
