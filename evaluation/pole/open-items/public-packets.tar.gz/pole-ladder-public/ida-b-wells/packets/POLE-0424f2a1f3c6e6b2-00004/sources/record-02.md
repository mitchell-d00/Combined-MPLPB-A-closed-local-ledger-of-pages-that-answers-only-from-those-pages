In response to that request of May 24, 1846, I, Ivo Hart, sent the museum
catalogue to the east depot.
