import concurrent.futures,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root/'candidate';out=root/'audit-evidence/candidate/live-final';out.mkdir(exist_ok=True)
rows=[json.loads(l) for l in (repo/'evaluation/live-conversation/input.jsonl').read_text().splitlines()]
users=list(dict.fromkeys(r['user'] for r in rows))
def run(i):
 selected=users[i*5:(i+1)*5];source=out/f'input-{i}.jsonl'
 source.write_text(''.join(json.dumps(r)+'\n' for r in rows if r['user'] in selected))
 cmd=['node','tools/live_conversation_wasm.mjs',str(root/'audit-runtime/pyodide'),'dist/index.html',str(source),str(out/f'run-{i}')]
 t=time.monotonic()
 with (out/f'run-{i}.log').open('w') as log:p=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 result=dict(shard=i,users=selected,command=cmd,exit_code=p.returncode,seconds=time.monotonic()-t)
 (out/f'execution-{i}.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:results=list(pool.map(run,range(5)))
(out/'executions.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in results))
