# Repository handoff

Last reviewed: 2026-11-26.

Read AGENTS.md before the next update. This is development coordination, not source-ledger evidence.

Base commit: `2622813aba9ee1f1880693eeb71ae015cb3da999` (ancestry, not the final self-containing commit).
Source inventory SHA-256: `e0d6421581ea0e6e077daf1be666777d20c0a45a51a16ad215cc19803bf1a48f`.

## Betty report for Al

Run the Betty implementation step first, then the Al review step in a separate chat. Both inspect the repository and the public API manifest, confirm their step, then read the last Betty report on the newest PR by creation time. A specific PR link selects that PR. The maintainer pastes Al’s response and direction to Betty, who tests and updates that PR. Resume from the last applied state after a pause.

### Latest user update instructions

Betty — begin the next Bunyip round. Broader ordinary-language understanding remains the primary goal.

1. Recover current state and fix HANDOFF.md
Read AGENTS.md, the latest PR report, HANDOFF.md and Test Index. Verify current main; Al last checked merge 2622813aba9ee1f1880693eeb71ae015cb3da999, containing PR #105.
Al found stale current-status language in HANDOFF.md: it still describes the CI output-path repair as awaiting push/checks/merge and deployment as NOT_RUN. The newer PR report records successful merge and deployed verification.
Synchronize those current-status and next-step sections with the actual receipts. Preserve historical failures and earlier statements in their dated records. Use the existing handoff-generation/check commands. Keep human onboarding and independent evaluations NOT_RUN where applicable.

2. Freeze the next development set locally
Continue Bunyip under a new versioned round. Reuse D% execution/scoring, Dice Bag custody/replay and D20 matched conditions. Do not create another harness.
Target the shared language mechanisms behind the remaining misses:
• Medial attribution: “Who, according to the source, owns…?”
• Classification: “Under what category is…?” and “How would you classify…?”
• Time questions: “At which time does…open?”
• Instruction questions omitting the task’s object: “Which task did [actor] give [recipient]?”
Include several sentence structures and different everyday domains. Vary source structure as well as vocabulary. Add competing, missing, retired-source, wrong-actor, negation and conditional controls. Do not filter out difficult generated positives.

3. Repair reusable interpretation rules
Prefer a shared question representation that preserves the requested relation, arguments, attribution, polarity, modality, time role and additional obligations.
A normalized question proposes an interpretation; it supplies no evidence. Native admission must still verify eligible source witnesses.
For object-free instruction questions, require a uniquely supported actor/recipient/task binding. Preserve ambiguity when multiple tasks fit.
Include yes/no classification contrasts where relevant:
• Explicit positive evidence can support “yes.”
• Explicit negative evidence can support “no.”
• An unmentioned classification remains unresolved.
Do not solve these cases through entity-specific branches or by dropping qualifications.

4. Verify development gains and preservation
Compare unchanged inputs against released main and the candidate. Audit every recovered claim and citation.
Report unique question wordings, unique source–question inputs and repeated executions separately. Canonical rewrites, synonym lookup and revealed-proof diagnostics do not count as answers to the original question.
Keep Bunyip BB unchanged as external regression evidence. Preserve earlier Cryptid results and original strict-key failures. Classify contract failures, coverage gaps, feature requests and infrastructure failures separately.

5. Measure fresh transfer
Freeze the candidate before opening a fresh packet. Hold back whole wording structures and combinations, not merely new names or seeds.
Run the frozen candidate once on that packet, retaining all outputs and failures. Disclose preparation/scoring custody accurately. Once exposed, use its misses as development material and require another fresh packet for later transfer claims.

6. Finish and release
Update the Bunyip report, Test Index, archive and HANDOFF.md. Lead with verified gains, preservation results and remaining coverage gaps.
Mitchell’s authorization remains: local work first, then publish and merge verified incremental gains through normal required checks, followed by deployment verification. Existing coverage misses alone do not require perfection. Investigate lost valid support or unsupported additions before release. Do not bypass required checks or request the same authorization again.
After deployment, ensure HANDOFF.md’s current status agrees with the final PR report.

Include the outside-reported Dungeons and Dragons ownership ambiguity as a development case.

Freeze contrasting cases:
1. One page explicitly supports the proposition; another merely has a matching title.
2. Two eligible pages make conflicting assertions.
3. Two pages describe different entities with similar names.
4. Supporting text exists only in an ineligible source.

Locate the blocking stage before changing behavior. Test whether evidence-aware routing can recover the first case while preserving conflict, identity and eligibility boundaries.

Keep the original routing result. If the repair changes ownership policy, version and test that policy explicitly. Score source support separately from routing ambiguity, and test new structures on fresh transfer material.

Betty — append these frozen contrasts before implementing the routing repair:

• Explicit negation plus a matching-title decoy: never return “yes.”
• Claim in title/scope only: withhold body-supported answering.
• Two agreeing body statements: preserve existing ownership rules. Cite both only where those rules already permit multiple witnesses; otherwise retain ambiguity.
• Cross-page implication: “D&D is an RPG” plus “an RPG is a game” must not establish “D&D is a game” through this repair.

Freeze the yes/no contract before implementation:
• Yes requires an explicit eligible positive witness.
• No requires an explicit eligible negative witness.
• Missing, conflicting or ambiguous evidence remains unresolved.
• Specify structured polarity, readable output and required quotations/citations so a quoted negation cannot accidentally score as “yes.”

Freeze the fresh transfer packet, key, generator revision and hashes before changing reader code. Keep it unopened until candidate freeze, and disclose actual custody limits. Changed names alone do not establish structural transfer.

Handle the museum refusal copy separately. Derive the message from the actual diagnostic state; zero displayed supporting sources does not necessarily mean zero eligible corpus passages. Preserve the decision while correcting misleading wording.

Record routing gains, polarity correctness, ownership-policy outcomes and UI-copy changes separately.

### Implemented scope

- Released reader status reconciled: PR105 checked head2431d35 merged as main2622813; required checks and deployed verification PASS. See evaluation/cryptid/bunyip/round2/released-state.json. This is a completed release receipt, not a claim that round2 has passed.
- Round2 isolated branch from verified main; unchanged D% execution/scoring, Dice Bag custody and D20 matched controls. Development frozen before native changes; baseline complete. No round2 reader patch or language gain yet.

### Validation recorded

- Current main and PR105 checked head have identical tree78ffea54e3ad0e35ac1dd27f6db16c32a8ec23dc. Final PR report confirms11 exact-head checks, normal merge, Pages45785270373 and live fingerprints/quickstart PASS.
- Historical pre-reconciliation HANDOFF/update bytes retained in evaluation/cryptid/bunyip/round2/history/pr105-pre-reconciliation.tar.xz. Earlier failed candidates, strict-key scores and failures remain unchanged.
- Round2 generator froze444 cases across three everyday domains and two genuinely different raw-text layouts; all generated positives retained. Initial script launch failed ModuleNotFoundError before reader execution; module-invocation retry uses required Bubblewrap.
- Round2 baseline444/444completed/scored:21/78positive answers,360/366withholds,57misses,six competing-time control failures;0worker failures/unscored/quotation failures. One prelaunch failure remains separate.78unique question strings,396unique source-question-state inputs,48repeated memberships. Required positive discovery78/78. Native runtime unchanged.
- Appended54routing and18polarity cases execute under unchanged D% runner/scorer and metadata/read-only diagnostic adapter;4parity contracts exact. Routing10/16positive,38/38withholds; polarity4/6positive,12/12withholds; zero unsupported completions/execution failures. Six routing yes/no misses stop at entity conjunction guard. Existing native evidence already resolves six lexical ambiguities: zero new routing gain. Original strict and corrected diagnostic assessments retained.
- 36fresh structural routing cases/key/generator sealed before native work;NOT_RUN/unopened after generation except byte hashing/archival. All821 files byte-verified and durably retained outside Git in /workspace/cryptid-custody/bunyip-r02-routing-retained.tar.xz SHA91dc743647921582e67d18809890a6d04c2d7c14f4d07bd1578ad197597ca00e. Same-operator visible templates; no independence claim.
- Authoritative appended namespaces distinguish54ROUTE-D,18POLAR and36held ROUTE-T cases:108unique current IDs. Frozen polarity registry inherited a route prefix; retain it and publish an explicit inventory alias, changing no inputs/key/score. Superseded authoringv1 is retained and NOT_RUN, not extra evidence.

### Limitations and blocked checks

- Round2 has no candidate, fresh transfer result or release acceptance yet. Baseline has six competing-time control failures to investigate before release. Software preservation and fresh transfer remain NOT_RUN.
- Storage gate BLOCKED: workspace has less than400KiB free. Auto-review rejected deleting a full frozen source ZIP after lossless verification because specific archive storage change was not explicitly authorized. Archive untouched; no bypass. All444 raw baseline outputs, original scores, input packet and key are now durably retained in hash-verified compressed containers. Space still blocks candidate/commit/archive work.
- Human onboarding and independent historical/semantic adjudication, independent preparation/blinding, outside-custodian scoring and native OOCC remain NOT_RUN. Same-operator authored testing is not independent accuracy.
- Prospective yes/no contract fails six of18ordinary-entity controls: four missing structured/readable polarity and two negative-admission misses. Museum-copy protocol frozen separately; UI NOT_RUN. Existing ownership policy unchanged; no new routing or UI gain claimed. Safe cleanup reclaimed only verified-untracked import caches; frozen ZIP storage rejection remains pending.

### Next steps

- Resolve storage without losing original archives, packets, keys or outputs. Baseline raw container is durably retained. Diagnose the57 positive misses and six competing-time control failures before patching shared rules.
- Then repair shared relation/argument interpretation, audit every gain and citation, rerun preservation/BB, freeze committed ZIP before fresh structures, and publish only through passing required gates. Existing release authorization persists.

## Use this ZIP in your repository

Extract the full ZIP, including dotfiles, into a clean directory. Review its files and run `python tools/build_handoff.py --check`. Copy the source into your existing checkout while preserving its `.git` directory and personal saves. Review the diff, commit on a branch, and push normally. Do not replace your Git history with a new repository. The included Actions workflows then run their configured checks; a local ZIP is not deployment verification.

For the next change, update `handoff/update.json` from the latest instruction, stage intended files, run `python tools/build_handoff.py`, verify with `--check`, and include the generated handoff in the delivery.
