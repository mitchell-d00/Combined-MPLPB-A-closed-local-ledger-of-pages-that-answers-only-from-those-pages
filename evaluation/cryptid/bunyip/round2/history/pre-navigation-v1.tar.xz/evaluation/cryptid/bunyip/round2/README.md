# Bunyip round 2: whole-question relation and argument binding

Last reviewed: 2026-11-26.

**Current local state: C3 repair implemented; acceptance BLOCKED by host process exhaustion. No round-two release or fresh-transfer result.**
The unchanged baseline completed21/78 positives and360/366 withholds, with57
positive misses and six unsupported competing-time answers. C1 and C2 recovered
those primary targets but failed new contrasting controls and were rejected.
C3 focused37 tests pass; broad checks remain incomplete. See the
[current working-state handoff](../../../../HANDOFF.md#betty-report-for-al).

The baseline sections below retain their original results; they are not the
current candidate's acceptance result. Original strict-key failures remain
separate from later source-checked assessments and prospective output contracts.
Released main is `2622813aba9ee1f1880693eeb71ae015cb3da999`, containing PR105.
Its eleven exact-head checks, protected merge and deployed verification passed;
[release reconciliation](released-state.json) records the receipts. The exact
old handoff is preserved in [dated history](history/pr105-pre-reconciliation.tar.xz).

## Current decisions and continuation

The repair carries relevant unresolved evidence to final admission rather than
treating failed interpretation as absence of competing evidence. It must also
preserve answers when unreadable material is irrelevant. Ownership policy and
native budgets remain unchanged. C1's two reported-field unsupported completions
and C2's four mixed-binding unsupported completions remain failures and exposed
development controls; neither candidate opened transfer.

Canonical [roles and acceptance](../../../../docs/TEAMBUILDING.md#al-and-betty-work-steps)
and [artifact/working-state recovery](../../../../docs/TEAMBUILDING.md#recover-artifact-state-and-working-state)
govern continuation. [Documentation clarification receipt](role-clarification-v1.json)
links the prior handoff snapshot. Completed attempts and the interrupted C3
attempt are durably retained in versioned local custody archives listed in
HANDOFF; historical source archives remain untouched.

Both held packets (36 routing and64 cross-family cases) were sealed before reader
changes and remain unopened/unrun. Preparation, implementation and scoring are
same-operator. Freeze a committed candidate ZIP after preservation checks before
opening either designated packet. Publication remains authorized only through
passing acceptance and required normal release gates.

Approximately32285 adopted zombie processes were observed; new process/thread
launches fail EAGAIN. The PID1 diagnostic probe was denied and not executed.
This is an infrastructure/approval failure, not a reader refusal. Required
isolation must not be bypassed. Inspect retained C3 logs and rerun affected checks
after process capacity is safely restored.

## Frozen development

[Frozen inputs/key](frozen-development-inputs.tar.xz), [version/seal receipt](freeze.json), and [baseline summary](baseline-summary.json) retain the original experiment.

444 cases use the unchanged D% worker, runner and scoring, Dice Bag seals/replay,
and D20 unique/competing/missing/retired conditions. Three everyday domains cover
medial source attribution, category/time wording and object-free task questions.
Actual adjacent-line and paragraph source bytes differ. Wrong arguments, negation,
conditions, additional obligations, task ambiguity and classification yes/no/
unmentioned contrasts remain in the matrix. Nothing is filtered by reader result.

The generator is [tools/bunyip_round2_packets.py](../../../../tools/bunyip_round2_packets.py).
Original questions are scored; canonical probes are diagnostics, never recoveries.
Same operator prepared and scores development; no independence is claimed.
At baseline freeze, fresh wording structures were NOT_PREPARED. Subsequently,
36 routing and64 cross-family cases were sealed before native edits; neither
packet has been opened for evaluation.

## Baseline execution accounting and storage receipt

The initial script invocation failed before any worker with ModuleNotFoundError;
the retained retry uses `python -m tools.dpercent`. Required Bubblewrap is enabled;
no unsandboxed fallback is allowed. All444 baseline workers completed/scored with zero worker failures; one separate prelaunch failure executed no readers. There are78 unique question strings,396 unique source-question-state inputs and48 repeated memberships. Full positive discovery is78/78; interpretation/proof misses remain. The six false flags involve competing opening times and require source/proof investigation. Keys, inputs and all raw baseline outputs are durably retained: [baseline container](baseline-retained.tar.xz), [hashes and denial receipt](retention.json). Every896 original output/score/log file was byte-verified. The workspace has less than400KiB free.

At that baseline stage, auto-review rejected replacing a full frozen archive with a verified lossless
encoding: specific storage modification had not been authorized. That action was
NOT_EXECUTED; the original archive is untouched. This is infrastructure, not a
reader failure. Full candidate/preservation/transfer/release remain pending. The original feature breakdown omits72 typed-instruction rows; overall/by-family totals include all444. No scorer amendment or relabelling was made.

## Reproduction

```sh
python -m tools.bunyip_round2_packets --out /tmp/bunyip-r02-public --custody /tmp/bunyip-r02-key
MPLPB_REQUIRE_SANDBOX=1 python -m tools.dpercent run --packets /tmp/bunyip-r02-public --out /tmp/bunyip-r02-baseline --implementation .
python -m tools.dpercent_expanded score --packets /tmp/bunyip-r02-public --custodian /tmp/bunyip-r02-key --run /tmp/bunyip-r02-baseline --output /tmp/bunyip-r02-score.json
```

Keep original strict-key failures and all earlier Cryptid packets unchanged.
Bunyip BB is separate consumed external regression evidence, not unseen transfer.
Human onboarding, independent historical/semantic adjudication, independent
preparation/blinding, outside-custodian scoring and native OOCC remain NOT_RUN.

## Appended routing, polarity and museum-copy baseline

[Routing seals, baseline results and retention](routing-freeze.json) preserve the
Outside-reported ownership lead as synthetic contrasts; the original Outside
packet was not supplied, so this is not an exact replay. Development54completed:
10/16positives,38/38withholds, six interpretation misses, zero unsupported
completions. Six lexical ambiguities already resolve through native body checks;
there is no new routing gain. The conjunction inside Dungeons and Dragons is
rejected by the ordinary-question entity guard before yes/no proof.

A separate18-case polarity control set completes4/6positives and12/12withholds.
The prospective [yes/no contract](routing-yes-no-contract-v1.json) fails6/18:
four existing positive answers lack explicit structured polarity/readable Yes
output; two explicit negatives remain withheld. Original scores stay unchanged.
This is a new contract/coverage target, not a retroactive released promise.

Conflict, similar-entity identity, ineligible support, title/scope-only claims,
quoted negation, cross-page implication and existing agreeing-owner ambiguity
remain protected. Four metadata-adapter parity executions preserve exact original
answer contracts. The unchanged D% runner/scorer were reused; at that baseline,
no native or ownership policy had changed. A36-case structurally different packet/key/generator is sealed,
NOT_RUN and unopened after generation apart from byte hashing/archival. Visible
same-operator templates are not independent preparation or blinding.

[The museum-copy protocol](museum-copy-protocol.json) is separate. At baseline it was NOT_RUN;
subsequent software CLI/JavaScript checks are distinct from human execution.
It distinguishes displayed supporting sources from eligible corpus passages and
requires decision-preserving, diagnostic-driven wording. A local UI-copy change
now exists; candidate/deployed verification remains pending.
All original/amended inputs, keys, raw results and failed assessments are retained
in the hashed local custody archive named in the receipt; held keys stay outside
the candidate source ZIP. Candidate/source archive publication remains pending.
