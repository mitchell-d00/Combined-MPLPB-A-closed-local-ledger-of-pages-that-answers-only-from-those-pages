# Public field-alias development holdout

This package contains only fictional synthetic sources, unchanged questions,
expected outcomes, every d100 draw and hash seals. No developer private historical
or personal records are needed. Keys are public for reproducibility, but the
unchanged D% Linux sandbox mounts neither keys nor generator into engine execution.

This is developer-authored known-method stress evidence, not independently
validated semantics or a context-blind test. Sources/vocabulary and two question
structures differ from earlier frozen benchmarks. The implementation author knew
the generator design. Genuine independent assessment remains NOT RUN.

Use Python3.12, Linux bubblewrap with namespaces permitted, and a full Git checkout
of Combined MPLPB. No paid APIs, model server or new Python dependencies are needed.
The tested typed-role implementation is 2427d80e777b9cc76e071b2529e91a14b9bdb991. From its source checkout:

    PYTHONPATH=. python /path/to/package/replay.py --implementation . --output /tmp/new-alias-replay

Use a new output directory. Default exit0 means no execution/unsupported-positive
errors, not perfect recall. Add --require-perfect to make missed answerable cases
fail too. Inspect every result.json, source receipt, quote/offset and source hash;
score.json retains all misses, partials, conflicts and failures.

public/seal.json pins all public input bytes and hashes expected/key.json and
expected/dice.json. The key is opened only by post-run scoring. required_field_quotes
apply to positive cases only; negative expectations concern support refusal and
must be adjudicated against their actual question/source/policy. Do not treat
unused negative-case field targets as expected affirmative answers. Each case
includes actual source bytes and its profile/budget. The worker preserves both
canonical source receipts and original-byte hashes, plus read-only integrity guards.

The original baseline isbe6a556 (runtime9b5ff0c); do not attribute later results to
main's older revision. Re-run each pinned implementation into a separate directory.
Original benchmarks outside this package remain immutable. Report supported
field matches, refusals, incorrect support, ambiguous/conflicting outputs, unscored
semantics and costs separately. A matching source statement is not historical truth.

Expected outcomes are authored test obligations, not independent human verdicts.
A third party can challenge these labels using the complete provided sources and
retain disagreement/adjudication; no invented reviewers or review scores exist.

The additional prospective/ chart was prepared after the final engine freeze.
It contains150 new records/questions (40 positive obligations and110 refusals),
new field vocabulary and two new unsupported surface forms. No engine change
was made after viewing its execution. It is still developer-authored and not
independent/context-blind. Select it with --study prospective; its sources,
expected outcomes, producer and seals are separate from the initial240 cases.
The final typed-role candidate is unchanged between these two studies.
