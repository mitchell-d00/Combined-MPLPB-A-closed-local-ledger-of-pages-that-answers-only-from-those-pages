"""Public synthetic replay; expected outcomes are read only after execution."""
import argparse,json
from pathlib import Path
from tools.dpercent import run
from tools.dpercent_expanded import score

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--implementation',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--require-perfect',action='store_true')
    p.add_argument('--study',choices=['initial','prospective'],default='initial')
    a=p.parse_args();root=Path(__file__).resolve().parent
    if a.study=='prospective':root=root/'prospective'
    a.output.mkdir(parents=True,exist_ok=False)
    run(root/'public',a.output/'execution',implementation=a.implementation)
    result=score(root/'public',root/'expected',a.output/'execution',a.output/'score.json')
    m=result['metrics'];print(json.dumps(m,indent=2))
    error=m['execution_failures'] or m['false_alarms'] or m['outcomes'].get('incorrect_supported_answer',0)
    return int(bool(error) or (a.require_perfect and not m['complete_decision_match']))
if __name__=='__main__':raise SystemExit(main())
