From: Tess Rowan
To: Edda Marén
Date written: May 12, 1842
Subject: Archive notice
Message-ID: MAIL-10067

This record was written on May 12, 1842. I recorded an idea about the northern field notebook.
