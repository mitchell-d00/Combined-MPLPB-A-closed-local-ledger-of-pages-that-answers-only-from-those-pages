From: Tess Rowan
To: May Reed
Date written: February 02, 1841
Subject: Archive notice
Message-ID: MAIL-10128

I have told Lea Stone to send you a copy of the alder memorandum by post (if
possible).
