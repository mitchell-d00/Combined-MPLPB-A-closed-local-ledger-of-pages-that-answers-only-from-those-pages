From: Nora Wells
To: Tess Rowan
Date written: September 10, 1843
Subject: Archive notice
Message-ID: MAIL-10049

I have told Mina Cole to send
you a copy of the orchard
inventory by post (if
possible).
