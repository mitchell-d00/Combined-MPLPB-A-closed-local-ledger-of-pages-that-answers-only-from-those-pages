ARUN MOSS TO MINA COLE. December 14, 1845
Dear colleague,

Unless the permit is denied, Arun Moss may send the alder
memorandum.
