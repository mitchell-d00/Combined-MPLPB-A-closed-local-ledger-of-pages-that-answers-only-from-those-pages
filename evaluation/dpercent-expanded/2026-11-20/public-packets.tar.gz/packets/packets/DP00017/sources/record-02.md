From: Noel Ash
To: Ivo Hart
Date written: November 15, 1843
Subject: Archive notice
Message-ID: MAIL-100172

Ivo Hart described an inspection of the west depot.
