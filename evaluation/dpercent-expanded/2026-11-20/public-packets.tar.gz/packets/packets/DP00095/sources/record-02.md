Record-ID: ARCH-10095-OTHER
Dispatch Date: 1848-03-05
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Entry copied by Edda Marén.
