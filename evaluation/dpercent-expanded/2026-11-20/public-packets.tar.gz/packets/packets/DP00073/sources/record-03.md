# Archival transcript

Written June 30, 1849.

My earlier letter is mistaken; the count should read nine.
