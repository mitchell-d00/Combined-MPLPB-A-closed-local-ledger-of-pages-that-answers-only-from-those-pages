# Archival transcript

Written June 30, 1849.

My earlier letter lists six crates for the east depot.
