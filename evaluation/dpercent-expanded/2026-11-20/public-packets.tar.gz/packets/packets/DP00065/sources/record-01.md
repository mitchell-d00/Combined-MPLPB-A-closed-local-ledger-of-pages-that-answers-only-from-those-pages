From: Noel Ash
To: May Reed
Date written: April 23, 1844
Subject: Archive notice
Message-ID: MAIL-10065

I have told Iris Beck to send
you a copy of the northern
field notebook by post (if
possible).
