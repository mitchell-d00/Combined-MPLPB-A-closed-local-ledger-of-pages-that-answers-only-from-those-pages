From: Tess Rowan
To: Mina Cole
Date written: February 26, 1844
Subject: Archive notice
Message-ID: MAIL-100582

Mina Cole described an inspection of the west depot.
