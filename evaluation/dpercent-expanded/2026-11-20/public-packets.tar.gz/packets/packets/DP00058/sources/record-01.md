From: Tess Rowan
To: Mina Cole
Date written: February 26, 1844
Subject: Archive notice
Message-ID: MAIL-100581

Tess Rowan described an inspection of the east depot.
