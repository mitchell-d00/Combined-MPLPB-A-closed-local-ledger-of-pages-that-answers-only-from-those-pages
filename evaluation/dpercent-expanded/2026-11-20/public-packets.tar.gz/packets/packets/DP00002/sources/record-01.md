EDDA MARÉN TO ARUN MOSS. December 15, 1846
Dear colleague,

The lamp went out before the departure bell rang.
