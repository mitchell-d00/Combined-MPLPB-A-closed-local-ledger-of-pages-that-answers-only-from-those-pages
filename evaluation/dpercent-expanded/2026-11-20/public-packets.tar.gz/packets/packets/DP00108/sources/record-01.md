NOEL ASH TO MINA COLE. May 29, 1841
Dear colleague,

My earlier letter lists six crates for the east depot.
