NOEL ASH TO MINA COLE. May 29, 1841
Dear colleague,

My earlier letter is mistaken; the count should read nine.
