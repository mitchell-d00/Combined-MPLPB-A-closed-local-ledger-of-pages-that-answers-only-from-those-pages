Nora Wells wrote the coastal dispatch.
