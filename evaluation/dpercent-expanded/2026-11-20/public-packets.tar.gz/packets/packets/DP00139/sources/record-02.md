Editorial speculation: May Reed might have written the coastal dispatch, although this is not established.
