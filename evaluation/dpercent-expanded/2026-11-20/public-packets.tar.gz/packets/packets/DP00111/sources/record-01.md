From: Ivo Hart
To: Iris Beck
Date written: August 12, 1842
Subject: Archive notice
Message-ID: MAIL-10111

Ivo Hart wrote the copper survey report.
