Record-ID: ARCH-10044-OTHER
Custody Location: West vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Entry copied by Edda Marén.
