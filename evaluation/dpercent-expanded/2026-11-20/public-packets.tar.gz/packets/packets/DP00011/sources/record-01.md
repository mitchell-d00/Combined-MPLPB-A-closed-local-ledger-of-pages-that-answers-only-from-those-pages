From: Nora Wells
To: Arun Moss
Date written: September 01, 1842
Subject: Archive notice
Message-ID: MAIL-10011

Arun Moss claimed that Nora Wells sent the museum catalogue; the register contains no independent receipt.
