From: Noel Ash
To: Mina Cole
Date written: February 27, 1840
Subject: Archive notice
Message-ID: MAIL-10150

This record was written on February 27, 1840. I recorded an idea about the
northern field notebook.
