From: Noel Ash
To: Mina Cole
Date written: March 01, 1840
Subject: Archive notice
Message-ID: MAIL-10150

This record was written on March 01, 1840. I recorded an idea about the
northern field notebook.
