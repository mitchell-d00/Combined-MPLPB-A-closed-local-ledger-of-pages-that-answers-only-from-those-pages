# Archival transcript

Written September 17, 1843.

The depot reported receiving a copy of the orchard
inventory, but the sender was not recorded.
