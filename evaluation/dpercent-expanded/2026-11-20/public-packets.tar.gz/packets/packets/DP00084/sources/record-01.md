# Archival transcript

Written September 17, 1843.

Edda Marén asked Tess Rowan to send the orchard
inventory.
