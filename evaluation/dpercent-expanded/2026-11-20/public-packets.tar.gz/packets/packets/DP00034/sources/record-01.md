# Archival transcript

Written July 09, 1847.

Mina Cole wrote the coastal dispatch.
