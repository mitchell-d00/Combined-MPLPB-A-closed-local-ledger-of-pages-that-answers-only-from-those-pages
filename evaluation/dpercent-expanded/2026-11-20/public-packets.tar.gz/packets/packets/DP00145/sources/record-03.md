# Archival transcript

Written February 13, 1846.

My earlier letter is mistaken; the count should read
nine.
