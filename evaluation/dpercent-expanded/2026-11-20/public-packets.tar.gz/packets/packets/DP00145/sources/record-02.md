# Archival transcript

Written February 13, 1846.

My earlier letter lists six crates for the west depot.
