From: Tess Rowan
To: Mina Cole
Date written: September 13, 1843
Subject: Archive notice
Message-ID: MAIL-100072

Mina Cole described an inspection of the west depot.
