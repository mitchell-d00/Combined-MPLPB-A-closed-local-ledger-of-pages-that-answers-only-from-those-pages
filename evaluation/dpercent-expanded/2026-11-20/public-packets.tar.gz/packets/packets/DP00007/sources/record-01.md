From: Tess Rowan
To: Mina Cole
Date written: September 13, 1843
Subject: Archive notice
Message-ID: MAIL-100071

Tess Rowan described an inspection of the east depot.
