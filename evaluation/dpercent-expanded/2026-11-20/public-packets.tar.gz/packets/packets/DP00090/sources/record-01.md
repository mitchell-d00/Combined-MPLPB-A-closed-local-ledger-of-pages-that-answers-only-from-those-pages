From: Lea Stone
To: Mina Cole
Date written: July 11, 1849
Subject: Archive notice
Message-ID: MAIL-10090

Lea Stone wrote the harbor
report.
