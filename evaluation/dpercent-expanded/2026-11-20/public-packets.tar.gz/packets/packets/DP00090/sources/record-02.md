From: Lea Stone
To: Mina Cole
Date written: July 11, 1849
Subject: Archive notice
Message-ID: MAIL-10090

Editorial speculation: Mina
Cole might have written the
harbor report, although this is
not established.
