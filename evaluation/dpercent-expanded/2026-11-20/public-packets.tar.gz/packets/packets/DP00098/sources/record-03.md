Documentation example, not
another communication.
```text
Message-ID: MAIL-10098
Noel Ash wrote the coastal
dispatch.
```
