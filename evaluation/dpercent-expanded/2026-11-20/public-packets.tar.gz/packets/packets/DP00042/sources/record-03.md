From: May Reed
To: Iris Beck
Date written: April 24, 1847
Subject: Archive notice
Message-ID: MAIL-10042

My earlier letter is mistaken; the count should read fourteen.
