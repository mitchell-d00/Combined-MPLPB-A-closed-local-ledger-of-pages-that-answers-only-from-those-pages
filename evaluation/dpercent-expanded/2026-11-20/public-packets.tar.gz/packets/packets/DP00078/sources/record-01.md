# Archival transcript

Written August 19, 1842.

Arun Moss would send the northern field notebook only if
the permit arrived.
