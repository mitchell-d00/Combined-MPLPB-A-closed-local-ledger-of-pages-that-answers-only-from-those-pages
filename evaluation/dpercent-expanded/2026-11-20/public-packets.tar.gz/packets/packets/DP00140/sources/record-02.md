Record-ID: ARCH-10140
Custody Location: West vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Résumé — 東京.
