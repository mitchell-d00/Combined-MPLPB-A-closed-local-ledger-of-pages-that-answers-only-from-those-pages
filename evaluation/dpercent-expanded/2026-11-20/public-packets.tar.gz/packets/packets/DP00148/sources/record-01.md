Record-ID: ARCH-10148
Custody Location: East vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Clerk wrote this entry.
