From: Noel Ash
To: Tess Rowan
Date written: October 11, 1848
Subject: Archive notice
Message-ID: MAIL-10092

Noel Ash would send the museum catalogue only if the permit arrived.
