From: Arun Moss
To: Iris Beck
Date written: June 03, 1841
Subject: Archive notice
Message-ID: MAIL-10106

Arun Moss did not write the copper survey report.
