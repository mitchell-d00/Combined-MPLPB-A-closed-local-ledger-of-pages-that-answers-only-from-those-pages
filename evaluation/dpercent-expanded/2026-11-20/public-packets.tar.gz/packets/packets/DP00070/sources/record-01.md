Mira Vale wrote the alder memorandum.
