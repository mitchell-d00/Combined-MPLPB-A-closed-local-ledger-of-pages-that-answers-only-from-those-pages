Record-ID: ARCH-10104
Custody Location: East vault
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Clerk wrote this entry.
