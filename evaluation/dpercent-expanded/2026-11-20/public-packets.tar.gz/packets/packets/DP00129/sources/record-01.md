IRIS BECK TO TESS ROWAN. December 26, 1845
Dear colleague,

Iris Beck planned to send the
harbor report.
