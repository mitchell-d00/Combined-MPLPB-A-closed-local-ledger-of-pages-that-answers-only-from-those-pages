Record-ID: ARCH-10120
Dispatch Date: 1848-03-02
Other Label: untouched
Subject: Archive notice

Clerk wrote this entry. Entry copied by Edda Marén.
