From: Nora Wells
To: Mina Cole
Date written: July 15, 1843
Subject: Archive notice
Message-ID: MAIL-10123

Nora Wells wrote the copper
survey report.
