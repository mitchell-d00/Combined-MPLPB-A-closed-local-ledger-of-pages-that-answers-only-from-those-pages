# Archival transcript

Written April 16, 1847.

Nora Wells wrote the orchard inventory.
