From: Tess Rowan
To: Arun Moss
Date written: May 28, 1840
Subject: Archive notice
Message-ID: MAIL-10125

The notice describes twelve
crates for the east depot.
