OWEN PIKE TO MIRA VALE. November 27, 1846
Dear colleague,

On November 27, 1846, Owen Pike
recorded an idea about the
harbor report.
