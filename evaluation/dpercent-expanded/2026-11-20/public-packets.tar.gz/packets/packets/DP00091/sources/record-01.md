LEA STONE TO NOEL ASH. August 29, 1843
Dear colleague,

My earlier letter lists twenty crates for the east depot.
