LEA STONE TO NOEL ASH. August 29, 1843
Dear colleague,

My earlier letter is mistaken; the count should read
seventeen.
