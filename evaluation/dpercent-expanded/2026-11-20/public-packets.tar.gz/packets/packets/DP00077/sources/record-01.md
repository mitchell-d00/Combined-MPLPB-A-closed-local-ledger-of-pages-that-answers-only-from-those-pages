ARUN MOSS TO NORA WELLS. May 23, 1848
Dear colleague,

Arun Moss hoped to send the
northern field notebook.
