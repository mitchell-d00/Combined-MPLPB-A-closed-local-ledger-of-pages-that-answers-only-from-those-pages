Mina Cole wrote the museum catalogue.
