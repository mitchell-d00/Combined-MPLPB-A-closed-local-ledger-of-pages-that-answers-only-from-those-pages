# Public topic pointer

Diplomacy

https://en.wikipedia.org/wiki/Diplomacy

This link supplies a topic for a fictional record exercise.
