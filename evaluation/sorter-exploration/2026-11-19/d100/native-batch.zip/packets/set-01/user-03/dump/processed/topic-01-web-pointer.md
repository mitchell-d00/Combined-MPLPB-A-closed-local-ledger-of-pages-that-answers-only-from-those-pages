# Public topic pointer

Printing

https://en.wikipedia.org/wiki/Printing

This link supplies a topic for a fictional record exercise.
