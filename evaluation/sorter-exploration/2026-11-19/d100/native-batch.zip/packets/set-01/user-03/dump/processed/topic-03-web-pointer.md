# Public topic pointer

Obesity

https://en.wikipedia.org/wiki/Obesity

This link supplies a topic for a fictional record exercise.
