# Public topic pointer

Animation

https://en.wikipedia.org/wiki/Animation

This link supplies a topic for a fictional record exercise.
