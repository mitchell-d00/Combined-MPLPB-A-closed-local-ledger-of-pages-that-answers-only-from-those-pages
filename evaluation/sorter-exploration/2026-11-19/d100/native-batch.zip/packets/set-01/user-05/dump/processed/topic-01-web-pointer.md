# Public topic pointer

Intelligence

https://en.wikipedia.org/wiki/Intelligence

This link supplies a topic for a fictional record exercise.
