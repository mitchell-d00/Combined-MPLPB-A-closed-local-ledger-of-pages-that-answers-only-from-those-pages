# Public topic pointer

Ali

https://en.wikipedia.org/wiki/Ali

This link supplies a topic for a fictional record exercise.
