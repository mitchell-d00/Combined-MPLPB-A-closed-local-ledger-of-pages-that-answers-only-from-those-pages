# Public topic pointer

Political science

https://en.wikipedia.org/wiki/Political_science

This link supplies a topic for a fictional record exercise.
