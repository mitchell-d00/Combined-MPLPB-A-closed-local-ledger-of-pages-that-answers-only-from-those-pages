# Public topic pointer

Village

https://en.wikipedia.org/wiki/Village

This link supplies a topic for a fictional record exercise.
