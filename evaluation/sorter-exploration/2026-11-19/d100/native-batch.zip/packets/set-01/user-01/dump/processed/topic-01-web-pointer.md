# Public topic pointer

Vitamin

https://en.wikipedia.org/wiki/Vitamin

This link supplies a topic for a fictional record exercise.
