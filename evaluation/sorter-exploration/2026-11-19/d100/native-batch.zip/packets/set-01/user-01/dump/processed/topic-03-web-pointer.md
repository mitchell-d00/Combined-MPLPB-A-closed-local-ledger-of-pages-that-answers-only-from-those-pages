# Public topic pointer

Cheese

https://en.wikipedia.org/wiki/Cheese

This link supplies a topic for a fictional record exercise.
