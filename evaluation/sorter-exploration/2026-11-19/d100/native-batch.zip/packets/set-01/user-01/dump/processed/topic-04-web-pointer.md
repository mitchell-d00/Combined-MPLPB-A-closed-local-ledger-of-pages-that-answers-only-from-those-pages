# Public topic pointer

Retail

https://en.wikipedia.org/wiki/Retail

This link supplies a topic for a fictional record exercise.
