# Public topic pointer

Three-dimensional space

https://en.wikipedia.org/wiki/Three-dimensional_space

This link supplies a topic for a fictional record exercise.
