# Public topic pointer

Robot

https://en.wikipedia.org/wiki/Robot

This link supplies a topic for a fictional record exercise.
