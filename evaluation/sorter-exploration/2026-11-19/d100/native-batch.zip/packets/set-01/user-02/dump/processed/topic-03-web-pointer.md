# Public topic pointer

Soul

https://en.wikipedia.org/wiki/Soul

This link supplies a topic for a fictional record exercise.
