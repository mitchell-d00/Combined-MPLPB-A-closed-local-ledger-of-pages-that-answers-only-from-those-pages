# Public topic pointer

History of religion

https://en.wikipedia.org/wiki/History_of_religion

This link supplies a topic for a fictional record exercise.
