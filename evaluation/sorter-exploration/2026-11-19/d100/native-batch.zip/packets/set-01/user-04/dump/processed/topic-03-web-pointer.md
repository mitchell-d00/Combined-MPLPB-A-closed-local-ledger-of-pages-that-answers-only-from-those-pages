# Public topic pointer

History of Europe

https://en.wikipedia.org/wiki/History_of_Europe

This link supplies a topic for a fictional record exercise.
