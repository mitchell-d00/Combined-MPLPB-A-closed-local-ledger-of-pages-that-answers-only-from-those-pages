# Public topic pointer

Continent

https://en.wikipedia.org/wiki/Continent

This link supplies a topic for a fictional record exercise.
