# Public topic pointer

Murasaki Shikibu

https://en.wikipedia.org/wiki/Murasaki_Shikibu

This link supplies a topic for a fictional record exercise.
