# Public topic pointer

Nitrogen

https://en.wikipedia.org/wiki/Nitrogen

This link supplies a topic for a fictional record exercise.
