# Public topic pointer

Iron Age

https://en.wikipedia.org/wiki/Iron_Age

This link supplies a topic for a fictional record exercise.
