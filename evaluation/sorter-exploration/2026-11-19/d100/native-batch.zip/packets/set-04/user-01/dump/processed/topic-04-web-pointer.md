# Public topic pointer

Algorithm

https://en.wikipedia.org/wiki/Algorithm

This link supplies a topic for a fictional record exercise.
