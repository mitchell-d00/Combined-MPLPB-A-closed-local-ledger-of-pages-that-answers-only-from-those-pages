# Public topic pointer

Cairo

https://en.wikipedia.org/wiki/Cairo

This link supplies a topic for a fictional record exercise.
