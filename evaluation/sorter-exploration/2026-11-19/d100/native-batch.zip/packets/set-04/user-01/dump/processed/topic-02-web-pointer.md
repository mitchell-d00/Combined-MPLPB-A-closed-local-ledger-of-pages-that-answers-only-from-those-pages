# Public topic pointer

Crusades

https://en.wikipedia.org/wiki/Crusades

This link supplies a topic for a fictional record exercise.
