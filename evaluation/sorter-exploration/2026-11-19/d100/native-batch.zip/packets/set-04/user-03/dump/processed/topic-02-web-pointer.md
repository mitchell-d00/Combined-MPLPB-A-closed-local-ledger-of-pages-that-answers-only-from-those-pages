# Public topic pointer

Rock music

https://en.wikipedia.org/wiki/Rock_music

This link supplies a topic for a fictional record exercise.
