# Public topic pointer

Dam

https://en.wikipedia.org/wiki/Dam

This link supplies a topic for a fictional record exercise.
