# Public topic pointer

Natural gas

https://en.wikipedia.org/wiki/Natural_gas

This link supplies a topic for a fictional record exercise.
