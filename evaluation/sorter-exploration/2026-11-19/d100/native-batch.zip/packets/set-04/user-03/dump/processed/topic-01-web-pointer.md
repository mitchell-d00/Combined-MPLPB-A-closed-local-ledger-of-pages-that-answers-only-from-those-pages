# Public topic pointer

Non-fiction

https://en.wikipedia.org/wiki/Non-fiction

This link supplies a topic for a fictional record exercise.
