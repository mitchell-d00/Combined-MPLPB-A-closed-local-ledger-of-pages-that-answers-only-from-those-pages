# Public topic pointer

French Revolution

https://en.wikipedia.org/wiki/French_Revolution

This link supplies a topic for a fictional record exercise.
