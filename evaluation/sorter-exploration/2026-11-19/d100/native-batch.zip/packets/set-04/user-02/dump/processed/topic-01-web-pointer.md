# Public topic pointer

Cardiovascular disease

https://en.wikipedia.org/wiki/Cardiovascular_disease

This link supplies a topic for a fictional record exercise.
