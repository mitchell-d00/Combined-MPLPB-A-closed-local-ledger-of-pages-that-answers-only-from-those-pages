# Public topic pointer

Holy Roman Empire

https://en.wikipedia.org/wiki/Holy_Roman_Empire

This link supplies a topic for a fictional record exercise.
