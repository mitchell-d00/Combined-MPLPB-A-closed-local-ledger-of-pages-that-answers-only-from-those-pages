# Public topic pointer

Fertilizer

https://en.wikipedia.org/wiki/Fertilizer

This link supplies a topic for a fictional record exercise.
