# Public topic pointer

Rhythm

https://en.wikipedia.org/wiki/Rhythm

This link supplies a topic for a fictional record exercise.
