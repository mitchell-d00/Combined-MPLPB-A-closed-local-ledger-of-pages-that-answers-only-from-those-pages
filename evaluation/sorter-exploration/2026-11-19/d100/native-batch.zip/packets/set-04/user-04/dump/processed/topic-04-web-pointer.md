# Public topic pointer

Sugar

https://en.wikipedia.org/wiki/Sugar

This link supplies a topic for a fictional record exercise.
