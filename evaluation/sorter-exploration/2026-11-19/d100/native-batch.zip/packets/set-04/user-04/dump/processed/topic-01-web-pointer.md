# Public topic pointer

Michael Faraday

https://en.wikipedia.org/wiki/Michael_Faraday

This link supplies a topic for a fictional record exercise.
