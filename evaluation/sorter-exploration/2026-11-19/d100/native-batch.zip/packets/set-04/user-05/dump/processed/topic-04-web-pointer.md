# Public topic pointer

New York City

https://en.wikipedia.org/wiki/New_York_City

This link supplies a topic for a fictional record exercise.
