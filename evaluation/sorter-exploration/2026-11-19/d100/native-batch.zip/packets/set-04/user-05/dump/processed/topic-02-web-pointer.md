# Public topic pointer

Maize

https://en.wikipedia.org/wiki/Maize

This link supplies a topic for a fictional record exercise.
