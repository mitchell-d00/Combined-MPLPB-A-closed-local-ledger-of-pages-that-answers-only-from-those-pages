# Public topic pointer

Shinto

https://en.wikipedia.org/wiki/Shinto

This link supplies a topic for a fictional record exercise.
