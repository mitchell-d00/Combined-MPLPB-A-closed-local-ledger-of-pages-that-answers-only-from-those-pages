# Public topic pointer

Narrative

https://en.wikipedia.org/wiki/Narrative

This link supplies a topic for a fictional record exercise.
