# Public topic pointer

Calligraphy

https://en.wikipedia.org/wiki/Calligraphy

This link supplies a topic for a fictional record exercise.
