# Public topic pointer

Gender

https://en.wikipedia.org/wiki/Gender

This link supplies a topic for a fictional record exercise.
