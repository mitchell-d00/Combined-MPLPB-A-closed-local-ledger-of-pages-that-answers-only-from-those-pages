# Public topic pointer

Vincent van Gogh

https://en.wikipedia.org/wiki/Vincent_van_Gogh

This link supplies a topic for a fictional record exercise.
