# Public topic pointer

Julius Caesar

https://en.wikipedia.org/wiki/Julius_Caesar

This link supplies a topic for a fictional record exercise.
