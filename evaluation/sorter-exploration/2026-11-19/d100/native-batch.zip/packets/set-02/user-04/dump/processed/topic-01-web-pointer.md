# Public topic pointer

Infinity

https://en.wikipedia.org/wiki/Infinity

This link supplies a topic for a fictional record exercise.
