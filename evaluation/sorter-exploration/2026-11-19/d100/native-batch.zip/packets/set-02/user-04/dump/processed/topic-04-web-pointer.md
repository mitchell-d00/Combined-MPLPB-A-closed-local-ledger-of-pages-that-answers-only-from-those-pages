# Public topic pointer

Belief

https://en.wikipedia.org/wiki/Belief

This link supplies a topic for a fictional record exercise.
