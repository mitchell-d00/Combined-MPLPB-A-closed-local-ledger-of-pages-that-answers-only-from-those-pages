# Public topic pointer

Angle

https://en.wikipedia.org/wiki/Angle

This link supplies a topic for a fictional record exercise.
