# Public topic pointer

Mexico City

https://en.wikipedia.org/wiki/Mexico_City

This link supplies a topic for a fictional record exercise.
