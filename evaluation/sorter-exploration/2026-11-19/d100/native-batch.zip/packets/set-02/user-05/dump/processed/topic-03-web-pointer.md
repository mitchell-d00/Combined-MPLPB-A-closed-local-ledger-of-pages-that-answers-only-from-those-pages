# Public topic pointer

Word

https://en.wikipedia.org/wiki/Word

This link supplies a topic for a fictional record exercise.
