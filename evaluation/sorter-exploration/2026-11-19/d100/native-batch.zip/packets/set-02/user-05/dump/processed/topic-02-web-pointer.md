# Public topic pointer

Prime number

https://en.wikipedia.org/wiki/Prime_number

This link supplies a topic for a fictional record exercise.
