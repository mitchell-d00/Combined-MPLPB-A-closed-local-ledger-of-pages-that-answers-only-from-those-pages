# Public topic pointer

Weapon

https://en.wikipedia.org/wiki/Weapon

This link supplies a topic for a fictional record exercise.
