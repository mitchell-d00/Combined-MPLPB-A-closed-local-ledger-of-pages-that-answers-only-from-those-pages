# Public topic pointer

Cancer

https://en.wikipedia.org/wiki/Cancer

This link supplies a topic for a fictional record exercise.
