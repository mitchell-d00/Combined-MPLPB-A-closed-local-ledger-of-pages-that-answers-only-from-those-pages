# Public topic pointer

Glass

https://en.wikipedia.org/wiki/Glass

This link supplies a topic for a fictional record exercise.
