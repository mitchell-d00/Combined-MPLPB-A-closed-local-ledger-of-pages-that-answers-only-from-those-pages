# Public topic pointer

Islam

https://en.wikipedia.org/wiki/Islam

This link supplies a topic for a fictional record exercise.
