# Public topic pointer

Addiction

https://en.wikipedia.org/wiki/Addiction

This link supplies a topic for a fictional record exercise.
