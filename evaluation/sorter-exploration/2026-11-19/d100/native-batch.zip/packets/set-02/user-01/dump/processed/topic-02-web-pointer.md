# Public topic pointer

Abstract art

https://en.wikipedia.org/wiki/Abstract_art

This link supplies a topic for a fictional record exercise.
