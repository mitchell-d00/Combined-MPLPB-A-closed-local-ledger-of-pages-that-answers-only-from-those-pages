# Public topic pointer

Love

https://en.wikipedia.org/wiki/Love

This link supplies a topic for a fictional record exercise.
