# Public topic pointer

Polygon

https://en.wikipedia.org/wiki/Polygon

This link supplies a topic for a fictional record exercise.
