# Public topic pointer

Sanitation

https://en.wikipedia.org/wiki/Sanitation

This link supplies a topic for a fictional record exercise.
