# Public topic pointer

Sense

https://en.wikipedia.org/wiki/Sense

This link supplies a topic for a fictional record exercise.
