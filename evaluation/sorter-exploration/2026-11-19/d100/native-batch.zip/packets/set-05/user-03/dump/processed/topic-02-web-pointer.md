# Public topic pointer

Fiction

https://en.wikipedia.org/wiki/Fiction

This link supplies a topic for a fictional record exercise.
