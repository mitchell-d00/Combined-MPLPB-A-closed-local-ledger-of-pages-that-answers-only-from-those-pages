# Public topic pointer

Romanticism

https://en.wikipedia.org/wiki/Romanticism

This link supplies a topic for a fictional record exercise.
