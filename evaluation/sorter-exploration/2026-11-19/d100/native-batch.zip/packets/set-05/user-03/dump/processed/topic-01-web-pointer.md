# Public topic pointer

Vedas

https://en.wikipedia.org/wiki/Vedas

This link supplies a topic for a fictional record exercise.
