# Public topic pointer

Algeria

https://en.wikipedia.org/wiki/Algeria

This link supplies a topic for a fictional record exercise.
