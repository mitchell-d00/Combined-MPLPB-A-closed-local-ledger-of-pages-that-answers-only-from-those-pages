# Public topic pointer

Secularism

https://en.wikipedia.org/wiki/Secularism

This link supplies a topic for a fictional record exercise.
