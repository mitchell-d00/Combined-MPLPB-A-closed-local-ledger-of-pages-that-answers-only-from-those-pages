# Public topic pointer

Masonry

https://en.wikipedia.org/wiki/Masonry

This link supplies a topic for a fictional record exercise.
