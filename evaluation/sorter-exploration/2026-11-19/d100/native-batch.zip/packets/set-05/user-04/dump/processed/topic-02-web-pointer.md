# Public topic pointer

History of North America

https://en.wikipedia.org/wiki/History_of_North_America

This link supplies a topic for a fictional record exercise.
