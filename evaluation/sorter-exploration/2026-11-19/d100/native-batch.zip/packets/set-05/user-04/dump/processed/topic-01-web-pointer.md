# Public topic pointer

Outer space

https://en.wikipedia.org/wiki/Outer_space

This link supplies a topic for a fictional record exercise.
