# Public topic pointer

Oven

https://en.wikipedia.org/wiki/Oven

This link supplies a topic for a fictional record exercise.
