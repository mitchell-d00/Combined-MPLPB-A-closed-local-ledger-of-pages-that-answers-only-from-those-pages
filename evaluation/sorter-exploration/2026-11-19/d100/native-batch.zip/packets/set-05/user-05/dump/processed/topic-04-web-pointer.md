# Public topic pointer

Adolescence

https://en.wikipedia.org/wiki/Adolescence

This link supplies a topic for a fictional record exercise.
