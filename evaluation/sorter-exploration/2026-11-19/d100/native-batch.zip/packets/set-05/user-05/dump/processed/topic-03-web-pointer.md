# Public topic pointer

Dementia

https://en.wikipedia.org/wiki/Dementia

This link supplies a topic for a fictional record exercise.
