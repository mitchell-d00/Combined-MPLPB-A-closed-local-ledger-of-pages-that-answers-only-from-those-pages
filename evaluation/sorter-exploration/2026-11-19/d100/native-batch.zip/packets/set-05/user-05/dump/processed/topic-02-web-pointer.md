# Public topic pointer

Library

https://en.wikipedia.org/wiki/Library

This link supplies a topic for a fictional record exercise.
