# Public topic pointer

Natural selection

https://en.wikipedia.org/wiki/Natural_selection

This link supplies a topic for a fictional record exercise.
