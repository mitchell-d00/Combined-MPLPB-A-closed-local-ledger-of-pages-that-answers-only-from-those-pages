# Public topic pointer

Prayer

https://en.wikipedia.org/wiki/Prayer

This link supplies a topic for a fictional record exercise.
