# Public topic pointer

Mathematical analysis

https://en.wikipedia.org/wiki/Mathematical_analysis

This link supplies a topic for a fictional record exercise.
