# Public topic pointer

Hippocrates

https://en.wikipedia.org/wiki/Hippocrates

This link supplies a topic for a fictional record exercise.
