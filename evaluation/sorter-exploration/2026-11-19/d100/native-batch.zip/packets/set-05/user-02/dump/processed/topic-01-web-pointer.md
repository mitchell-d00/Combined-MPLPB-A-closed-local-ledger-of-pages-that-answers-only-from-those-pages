# Public topic pointer

Big Bang

https://en.wikipedia.org/wiki/Big_Bang

This link supplies a topic for a fictional record exercise.
