# Public topic pointer

Social equality

https://en.wikipedia.org/wiki/Social_equality

This link supplies a topic for a fictional record exercise.
