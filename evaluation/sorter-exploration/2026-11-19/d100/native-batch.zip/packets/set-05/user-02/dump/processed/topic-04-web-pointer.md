# Public topic pointer

Liberalism

https://en.wikipedia.org/wiki/Liberalism

This link supplies a topic for a fictional record exercise.
