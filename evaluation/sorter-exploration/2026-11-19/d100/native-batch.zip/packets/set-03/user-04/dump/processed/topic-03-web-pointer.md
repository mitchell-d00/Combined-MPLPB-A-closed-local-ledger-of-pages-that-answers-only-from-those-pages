# Public topic pointer

Horse

https://en.wikipedia.org/wiki/Horse

This link supplies a topic for a fictional record exercise.
