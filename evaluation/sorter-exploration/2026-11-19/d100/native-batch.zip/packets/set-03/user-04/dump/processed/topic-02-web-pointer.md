# Public topic pointer

Virus

https://en.wikipedia.org/wiki/Virus

This link supplies a topic for a fictional record exercise.
