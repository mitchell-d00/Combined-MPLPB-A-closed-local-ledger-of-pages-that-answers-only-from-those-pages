# Public topic pointer

Mughal Empire

https://en.wikipedia.org/wiki/Mughal_Empire

This link supplies a topic for a fictional record exercise.
