# Public topic pointer

London

https://en.wikipedia.org/wiki/London

This link supplies a topic for a fictional record exercise.
