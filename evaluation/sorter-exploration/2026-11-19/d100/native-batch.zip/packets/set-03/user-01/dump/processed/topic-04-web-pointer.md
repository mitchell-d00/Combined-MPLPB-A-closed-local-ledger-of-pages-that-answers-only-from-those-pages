# Public topic pointer

Chinese folk religion

https://en.wikipedia.org/wiki/Chinese_folk_religion

This link supplies a topic for a fictional record exercise.
