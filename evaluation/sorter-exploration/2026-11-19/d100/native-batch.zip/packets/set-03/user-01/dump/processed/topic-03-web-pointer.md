# Public topic pointer

Jainism

https://en.wikipedia.org/wiki/Jainism

This link supplies a topic for a fictional record exercise.
