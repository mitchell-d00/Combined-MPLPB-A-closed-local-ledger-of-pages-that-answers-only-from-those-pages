# Public topic pointer

Achaemenid Empire

https://en.wikipedia.org/wiki/Achaemenid_Empire

This link supplies a topic for a fictional record exercise.
