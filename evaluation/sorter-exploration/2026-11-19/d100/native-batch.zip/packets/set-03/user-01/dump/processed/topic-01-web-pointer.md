# Public topic pointer

Laozi

https://en.wikipedia.org/wiki/Laozi

This link supplies a topic for a fictional record exercise.
