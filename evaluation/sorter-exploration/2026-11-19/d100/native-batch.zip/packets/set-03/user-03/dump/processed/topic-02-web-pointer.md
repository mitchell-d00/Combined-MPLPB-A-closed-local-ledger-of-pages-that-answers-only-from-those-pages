# Public topic pointer

Crime

https://en.wikipedia.org/wiki/Crime

This link supplies a topic for a fictional record exercise.
