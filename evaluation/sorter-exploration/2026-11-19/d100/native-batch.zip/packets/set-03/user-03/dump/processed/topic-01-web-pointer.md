# Public topic pointer

Adolf Hitler

https://en.wikipedia.org/wiki/Adolf_Hitler

This link supplies a topic for a fictional record exercise.
