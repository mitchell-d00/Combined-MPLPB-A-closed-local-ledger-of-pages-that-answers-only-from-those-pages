# Public topic pointer

Salt

https://en.wikipedia.org/wiki/Salt

This link supplies a topic for a fictional record exercise.
