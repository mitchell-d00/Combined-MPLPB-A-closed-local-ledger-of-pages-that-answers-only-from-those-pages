# Public topic pointer

International System of Units

https://en.wikipedia.org/wiki/International_System_of_Units

This link supplies a topic for a fictional record exercise.
