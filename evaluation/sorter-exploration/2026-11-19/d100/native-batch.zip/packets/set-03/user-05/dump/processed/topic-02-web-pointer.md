# Public topic pointer

Mississippi River

https://en.wikipedia.org/wiki/Mississippi_River

This link supplies a topic for a fictional record exercise.
