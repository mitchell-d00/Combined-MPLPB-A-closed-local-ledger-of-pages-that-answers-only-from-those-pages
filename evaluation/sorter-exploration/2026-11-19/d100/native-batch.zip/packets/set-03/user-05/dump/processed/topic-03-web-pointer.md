# Public topic pointer

Vegetable

https://en.wikipedia.org/wiki/Vegetable

This link supplies a topic for a fictional record exercise.
