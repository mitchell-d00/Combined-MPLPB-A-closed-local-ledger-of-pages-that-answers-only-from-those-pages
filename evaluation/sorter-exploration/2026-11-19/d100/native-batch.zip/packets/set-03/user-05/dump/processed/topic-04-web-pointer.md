# Public topic pointer

Equation

https://en.wikipedia.org/wiki/Equation

This link supplies a topic for a fictional record exercise.
