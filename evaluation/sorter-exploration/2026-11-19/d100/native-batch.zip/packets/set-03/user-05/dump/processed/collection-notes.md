# Working notes

Draft inventory. Items require review before release.