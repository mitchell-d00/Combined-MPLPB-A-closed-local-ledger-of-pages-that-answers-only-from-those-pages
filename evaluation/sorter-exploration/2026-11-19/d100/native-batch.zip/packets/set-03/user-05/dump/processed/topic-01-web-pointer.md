# Public topic pointer

Polynesia

https://en.wikipedia.org/wiki/Polynesia

This link supplies a topic for a fictional record exercise.
