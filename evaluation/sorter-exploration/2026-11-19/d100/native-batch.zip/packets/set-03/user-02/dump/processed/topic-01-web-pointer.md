# Public topic pointer

Sexual orientation

https://en.wikipedia.org/wiki/Sexual_orientation

This link supplies a topic for a fictional record exercise.
