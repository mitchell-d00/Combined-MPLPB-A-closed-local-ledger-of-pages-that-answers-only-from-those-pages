# Public topic pointer

Board game

https://en.wikipedia.org/wiki/Board_game

This link supplies a topic for a fictional record exercise.
