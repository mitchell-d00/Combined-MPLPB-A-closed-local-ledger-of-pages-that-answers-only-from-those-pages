# Public topic pointer

Calculus

https://en.wikipedia.org/wiki/Calculus

This link supplies a topic for a fictional record exercise.
