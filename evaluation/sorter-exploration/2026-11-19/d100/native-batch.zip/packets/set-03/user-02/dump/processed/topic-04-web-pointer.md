# Public topic pointer

Carl Friedrich Gauss

https://en.wikipedia.org/wiki/Carl_Friedrich_Gauss

This link supplies a topic for a fictional record exercise.
